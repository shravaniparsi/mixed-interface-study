"""Per-run token and cost accounting for the configured model providers."""
from dataclasses import dataclass, field
import time


DEFAULT_PRICING: dict[str, dict[str, float | None]] = {
    "gemini-3.1-flash-lite-preview": {
        "input": 0.25,  "output": 1.50,  "cached_input": 0.0625,
    },
    "gemini-2.5-pro": {
        "input": 1.25,  "output": 10.00, "cached_input": 0.3125,
    },
    "deepseek-chat": {
        "input": 0.28,  "output": 0.42,  "cached_input": 0.028,
    },
    "mistral-large-latest": {
        "input": 2.00,  "output": 6.00,  "cached_input": None,
    },
}


@dataclass
class TokenCall:
    phase: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    timestamp: float = field(default_factory=time.time)
    detail: str = ""


class TokenTracker:

    def __init__(self, model: str, pricing: dict | None = None):
        self.model = model
        self.calls: list[TokenCall] = []
        self._pricing = pricing or DEFAULT_PRICING

    def record(self, phase: str, usage: dict | None, detail: str = ""):
        if not usage:
            return
        self.calls.append(TokenCall(
            phase=phase,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
            cached_tokens=usage.get("cached_tokens", 0) or 0,
            detail=detail,
        ))


    def total_prompt_tokens(self) -> int:
        return sum(c.prompt_tokens for c in self.calls)

    def total_completion_tokens(self) -> int:
        return sum(c.completion_tokens for c in self.calls)

    def total_tokens(self) -> int:
        return sum(c.total_tokens for c in self.calls)

    def total_cached_tokens(self) -> int:
        return sum(c.cached_tokens for c in self.calls)

    def call_count(self) -> int:
        return len(self.calls)

    def per_phase(self) -> dict[str, dict]:
        phases: dict[str, dict] = {}
        for c in self.calls:
            p = phases.setdefault(c.phase, {
                "calls": 0, "prompt_tokens": 0,
                "completion_tokens": 0, "total_tokens": 0,
                "cached_tokens": 0,
            })
            p["calls"] += 1
            p["prompt_tokens"] += c.prompt_tokens
            p["completion_tokens"] += c.completion_tokens
            p["total_tokens"] += c.total_tokens
            p["cached_tokens"] += c.cached_tokens
        return phases


    def _resolve_pricing(self) -> dict[str, float | None] | None:
        if self.model in self._pricing:
            return self._pricing[self.model]
        for pattern, price in self._pricing.items():
            if pattern in self.model or self.model in pattern:
                return price
        return None

    def cost_usd(self) -> dict:
        pricing = self._resolve_pricing()
        if not pricing:
            return {
                "input_cost": 0.0, "output_cost": 0.0,
                "total_cost": 0.0, "cached_savings": 0.0,
                "pricing_model": "unknown",
                "pricing_found": False,
            }

        input_rate = pricing["input"] / 1_000_000
        output_rate = pricing["output"] / 1_000_000
        cached_rate = (pricing.get("cached_input") or pricing["input"]) / 1_000_000

        total_prompt = self.total_prompt_tokens()
        total_cached = self.total_cached_tokens()
        non_cached_prompt = total_prompt - total_cached
        total_completion = self.total_completion_tokens()

        input_cost = (non_cached_prompt * input_rate) + (total_cached * cached_rate)
        output_cost = total_completion * output_rate
        cached_savings = total_cached * (input_rate - cached_rate)

        return {
            "input_cost": round(input_cost, 6),
            "output_cost": round(output_cost, 6),
            "total_cost": round(input_cost + output_cost, 6),
            "cached_savings": round(cached_savings, 6),
            "pricing_model": self.model,
            "pricing_found": True,
        }


    def summary(self) -> dict:
        cost = self.cost_usd()
        return {
            "model": self.model,
            "total_calls": self.call_count(),
            "total_prompt_tokens": self.total_prompt_tokens(),
            "total_completion_tokens": self.total_completion_tokens(),
            "total_tokens": self.total_tokens(),
            "total_cached_tokens": self.total_cached_tokens(),
            "per_phase": self.per_phase(),
            "cost_usd": cost,
        }

    def summary_slim(self) -> dict:
        cost = self.cost_usd()
        return {
            "total_calls": self.call_count(),
            "prompt_tokens": self.total_prompt_tokens(),
            "completion_tokens": self.total_completion_tokens(),
            "total_tokens": self.total_tokens(),
            "cached_tokens": self.total_cached_tokens(),
            "cost_input_usd": cost["input_cost"],
            "cost_output_usd": cost["output_cost"],
            "cost_total_usd": cost["total_cost"],
            "pricing_found": cost["pricing_found"],
        }


def extract_usage_gemini(response) -> dict | None:
    meta = getattr(response, "usage_metadata", None)
    if not meta:
        return None
    return {
        "prompt_tokens": getattr(meta, "prompt_token_count", 0) or 0,
        "completion_tokens": getattr(meta, "candidates_token_count", 0) or 0,
        "total_tokens": getattr(meta, "total_token_count", 0) or 0,
        "cached_tokens": getattr(meta, "cached_content_token_count", 0) or 0,
    }


def extract_usage_mistral(response) -> dict | None:
    usage = getattr(response, "usage", None)
    if not usage:
        return None
    return {
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
        "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        "cached_tokens": 0,
    }


def extract_usage_openai(response) -> dict | None:
    usage = getattr(response, "usage", None)
    if not usage:
        return None
    return {
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
        "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        "cached_tokens": getattr(usage, "prompt_cache_hit_tokens", 0) or 0,
    }
