"""Token-budget-aware compression of the context artifacts (documentation, source code, database schema) assembled for each context level."""
import re
import json
import yaml
from dataclasses import dataclass, field


@dataclass
class CompressionStats:
    original_chars: int = 0
    compressed_chars: int = 0
    original_est_tokens: int = 0
    compressed_est_tokens: int = 0
    sections: dict = field(default_factory=dict)

    @property
    def savings_pct(self) -> float:
        if self.original_chars == 0:
            return 0.0
        return round((1 - self.compressed_chars / self.original_chars) * 100, 1)

    @property
    def tokens_saved(self) -> int:
        return self.original_est_tokens - self.compressed_est_tokens

    def summary(self) -> dict:
        return {
            "original_chars": self.original_chars,
            "compressed_chars": self.compressed_chars,
            "original_est_tokens": self.original_est_tokens,
            "compressed_est_tokens": self.compressed_est_tokens,
            "savings_pct": self.savings_pct,
            "tokens_saved": self.tokens_saved,
            "per_section": self.sections,
        }


def compress_openapi(spec_text: str) -> str:
    try:
        spec = json.loads(spec_text)
    except json.JSONDecodeError:
        try:
            spec = yaml.safe_load(spec_text)
        except Exception:
            return spec_text

    paths = spec.get("paths", {})
    for path, methods in paths.items():
        for method, details in methods.items():
            if not isinstance(details, dict):
                continue

            responses = details.get("responses", {})
            responses.pop("422", None)

            details.pop("operationId", None)

            details.pop("tags", None)

            if details.get("description", "").strip() == "":
                details.pop("description", None)

    schemas = spec.get("components", {}).get("schemas", {})
    for remove_key in ("HTTPValidationError", "ValidationError"):
        schemas.pop(remove_key, None)


    result = yaml.dump(spec, allow_unicode=True, sort_keys=False)

    note = (
        "\n[NOTE: All endpoints return 422 for Pydantic validation errors "
        "(missing fields, wrong types, values out of range). "
        "Response format: {\"detail\": [{\"loc\": [...], \"msg\": \"...\", \"type\": \"...\"}]}]\n"
    )

    return note + result


def _estimate_openapi_savings(original: str, compressed: str) -> dict:
    return {
        "original_chars": len(original),
        "compressed_chars": len(compressed),
        "savings_pct": round((1 - len(compressed) / len(original)) * 100, 1)
        if original else 0,
    }


def compress_source_code(code: str) -> str:
    lines = code.split("\n")
    result = []
    in_docstring = False
    docstring_char = None
    blank_count = 0
    skip_imports = {
        "from typing import",
        "from datetime import",
        "from sqlalchemy import",
        "from sqlalchemy.orm import",
        "from pydantic import",
        "from fastapi import",
        "import math",
    }

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped.startswith("# === FILE:"):
            if result and result[-1].strip() != "":
                result.append("")
            result.append(line)
            blank_count = 0
            i += 1
            continue

        if not in_docstring:
            if stripped.startswith('"""') or stripped.startswith("'''"):
                docstring_char = stripped[:3]
                if stripped.count(docstring_char) >= 2 and len(stripped) > 3:
                    i += 1
                    continue
                in_docstring = True
                i += 1
                continue
        else:
            if docstring_char in stripped:
                in_docstring = False
            i += 1
            continue

        if stripped.startswith("#") and not stripped.startswith("# =") and not stripped.startswith("# --"):
            i += 1
            continue

        if any(stripped.startswith(prefix) for prefix in skip_imports):
            i += 1
            continue

        if stripped == "":
            blank_count += 1
            if blank_count <= 1:
                result.append("")
            i += 1
            continue

        blank_count = 0
        result.append(line)
        i += 1

    return "\n".join(result).strip()


def compress_documentation(doc: str) -> str:
    lines = doc.split("\n")
    result = []
    blank_count = 0

    for line in lines:
        stripped = line.strip()

        if stripped == "":
            blank_count += 1
            if blank_count <= 1:
                result.append("")
            continue

        blank_count = 0

        if re.match(r'^[-=*]{3,}$', stripped):
            continue

        if re.match(r'^\|[\s\-|]+\|$', stripped):
            continue

        result.append(line)

    return "\n".join(result).strip()


def compress_db_schema(schema: str) -> str:
    lines = schema.split("\n")
    result = []
    blank_count = 0

    for line in lines:
        stripped = line.strip()

        if stripped.startswith("--"):
            continue

        if stripped == "":
            blank_count += 1
            if blank_count <= 1:
                result.append("")
            continue

        blank_count = 0
        result.append(line)

    return "\n".join(result).strip()


_SECTION_COMPRESSORS = {
    "OPENAPI SPECIFICATION": compress_openapi,
    "TECHNICAL AND BUSINESS DOCUMENTATION": compress_documentation,
    "ENDPOINT SOURCE CODE": compress_source_code,
    "DATABASE SCHEMA": compress_db_schema,
    "EXISTING TESTS (STYLE SAMPLE)": None,
}


def compress_context(context: str, level: str = "L0") -> tuple[str, CompressionStats]:
    stats = CompressionStats(
        original_chars=len(context),
        original_est_tokens=len(context) // 3,
    )

    sections: list[tuple[str, str]] = []
    current_header = "preamble"
    current_lines: list[str] = []

    for line in context.split("\n"):
        m = re.match(r'^---\s+(.+?)\s+---$', line)
        if m:
            if current_lines:
                sections.append((current_header, "\n".join(current_lines)))
            current_header = m.group(1)
            current_lines = []
        else:
            current_lines.append(line)

    if current_lines:
        sections.append((current_header, "\n".join(current_lines)))

    compressed_sections: list[str] = []
    for header, content in sections:
        original_len = len(content)

        compressor = None
        for key, func in _SECTION_COMPRESSORS.items():
            if key in header.upper():
                compressor = func
                break

        if compressor:
            compressed = compressor(content)
        else:
            compressed = content

        compressed_len = len(compressed)

        stats.sections[header] = {
            "original_chars": original_len,
            "compressed_chars": compressed_len,
            "savings_pct": round((1 - compressed_len / original_len) * 100, 1)
            if original_len > 0 else 0,
        }

        if header != "preamble":
            compressed_sections.append(f"--- {header} ---")
        compressed_sections.append(compressed)

    result = "\n".join(compressed_sections)
    stats.compressed_chars = len(result)
    stats.compressed_est_tokens = len(result) // 3

    return result, stats


def print_compression_report(stats: CompressionStats):
    print(f"\n  Context compression:")
    print(f"     Celkem: {stats.original_est_tokens:,} → "
          f"{stats.compressed_est_tokens:,} tokens "
          f"(-{stats.savings_pct}%, -{stats.tokens_saved:,} tokens)")

    for name, s in stats.sections.items():
        if s["savings_pct"] > 0:
            print(f"     {name}: −{s['savings_pct']}% "
                  f"({s['original_chars']:,} → {s['compressed_chars']:,} chars)")
