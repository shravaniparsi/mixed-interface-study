# Vibe Testing pipeline

Experimental pipeline that generates, runs, diagnoses and repairs REST-API
test suites with an LLM under a controlled five-level context taxonomy.

* `main.py` — experiment runner (`python main.py --config configs/<file>.yaml`).
* `pipeline/phase1_context.py` … `phase6_diagnostics.py` — the six pipeline
  phases (context assembly, test planning, code generation, validation against
  the live API, metric computation, failure diagnostics for the repair loop).
* `llm_provider.py` — provider adapters (Anthropic, DeepSeek, Mistral, Gemini,
  Ollama-hosted open-weight models).
* `context_compressor.py` — token-budget-aware context packing.
* `token_tracker.py` — token/cost accounting.
* `configs/` — the exact YAML configurations of all archived experiments
  (balanced context axis, temperature sweeps, open-weight context matrix).
* `.env.template` — environment variables expected for API keys.

Note on language: all framework and analysis code, the prompt templates, and the
experiment configurations are in English. The only Czech-language material is the
target API and its business documentation
(`03_context_artifacts/api1_bookstore/documentation.md`), because the API models a
Czech-domain bookstore; these are preserved verbatim as the exact context that was
supplied to the models. A prompt-language control experiment (English vs Czech
prompting on the same models and API) confirmed that the prompt language does not
materially change the measured test validity.
