"""Phase 1: assemble the context block for a given level (L0-L4) from the OpenAPI specification, business documentation, source code, database schema and reference tests."""
import yaml
import json
import os


def analyze_context(openapi_path: str, doc_path: str = None, level: str = "L0",
                    source_code_path: str = None, db_schema_path: str = None,
                    existing_tests_path: str = None) -> str:
    if not os.path.exists(openapi_path):
        raise FileNotFoundError(f"File {openapi_path} was not found.")

    with open(openapi_path, 'r', encoding='utf-8') as f:
        if openapi_path.endswith(('.yaml', '.yml')):
            data = yaml.safe_load(f)
            openapi_text = json.dumps(data, indent=2)
        elif openapi_path.endswith('.json'):
            openapi_text = f.read()
        else:
            raise ValueError("Unsupported specification format. Use .yaml or .json")

    context = f"--- OPENAPI SPECIFICATION ---\n{openapi_text}\n"

    if level in ("L1", "L2", "L3", "L4"):
        if doc_path and os.path.exists(doc_path):
            with open(doc_path, 'r', encoding='utf-8') as f:
                context += f"\n--- TECHNICAL AND BUSINESS DOCUMENTATION ---\n{f.read()}\n"
        else:
            print(f"  Level {level} requires documentation, but the file was not found: {doc_path}")

    if level in ("L2", "L3", "L4"):
        if source_code_path and os.path.exists(source_code_path):
            with open(source_code_path, 'r', encoding='utf-8') as f:
                context += f"\n--- ENDPOINT SOURCE CODE ---\n{f.read()}\n"
        else:
            print(f"  Level {level} requires source code, but the file was not found: {source_code_path}")

    if level in ("L3", "L4"):
        if db_schema_path and os.path.exists(db_schema_path):
            with open(db_schema_path, 'r', encoding='utf-8') as f:
                context += f"\n--- DATABASE SCHEMA ---\n{f.read()}\n"
        else:
            print(f"  Level {level} requires the DB schema, but the file was not found: {db_schema_path}")

    if level == "L4":
        if existing_tests_path and os.path.exists(existing_tests_path):
            with open(existing_tests_path, 'r', encoding='utf-8') as f:
                context += f"\n--- EXISTING TESTS (STYLE SAMPLE) ---\n{f.read()}\n"
        else:
            print(f"  Level L4 requires reference tests, but the file was not found: {existing_tests_path}")

    return context
