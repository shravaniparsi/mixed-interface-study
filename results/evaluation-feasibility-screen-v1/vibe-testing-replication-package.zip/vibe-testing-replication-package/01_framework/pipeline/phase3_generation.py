"""Phase 3: generate the pytest suite from the plan and context, then run the targeted repair loop (helper-level and isolated repairs, stale-test handling, truncation salvage)."""
import ast
import json
import re
import textwrap
import time

from pipeline.prompt_templates import PromptBuilder

MAX_INDIVIDUAL_REPAIRS = 10


def count_test_functions(code: str) -> int:
    try:
        tree = ast.parse(code)
        return sum(1 for n in ast.walk(tree)
                   if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"))
    except SyntaxError:
        return 0


def _get_test_function_names(code: str) -> list[str]:
    try:
        tree = ast.parse(code)
        funcs = []
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                funcs.append((node.lineno, node.name))
        return [name for _, name in sorted(funcs)]
    except SyntaxError:
        return []


def _get_function_range(code: str, func_name: str):
    try:
        tree = ast.parse(code)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == func_name:
                start = node.lineno - 1
                if node.decorator_list:
                    start = node.decorator_list[0].lineno - 1
                end = node.end_lineno - 1
                return start, end
    except SyntaxError:
        pass
    return None


def _extract_function_code(code: str, func_name: str):
    rng = _get_function_range(code, func_name)
    if not rng:
        return None
    start, end = rng
    lines = code.split('\n')
    return '\n'.join(lines[start:end + 1])


def _replace_function_code(code: str, func_name: str, new_func: str) -> str:
    rng = _get_function_range(code, func_name)
    if not rng:
        return code
    start, end = rng
    lines = code.split('\n')
    new_func = textwrap.dedent(new_func).strip()
    new_lines = lines[:start] + new_func.split('\n') + lines[end + 1:]
    return '\n'.join(new_lines)


def _extract_helpers_code(code: str) -> str:
    test_names = _get_test_function_names(code)
    if not test_names:
        return code
    first_rng = _get_function_range(code, test_names[0])
    if not first_rng:
        return ""
    lines = code.split('\n')
    return '\n'.join(lines[:first_rng[0]]).strip()


def _replace_helpers(code: str, new_helpers: str) -> str:
    test_names = _get_test_function_names(code)
    if not test_names:
        return code
    first_rng = _get_function_range(code, test_names[0])
    if not first_rng:
        return code
    lines = code.split('\n')
    tests_part = '\n'.join(lines[first_rng[0]:])
    return new_helpers.strip() + '\n\n\n' + tests_part


def _remove_last_n_tests(code: str, n: int) -> str:
    test_names = _get_test_function_names(code)
    if n <= 0 or n > len(test_names):
        return code
    to_remove = test_names[-n:]
    for name in reversed(to_remove):
        rng = _get_function_range(code, name)
        if rng:
            start, end = rng
            lines = code.split('\n')
            while end + 1 < len(lines) and lines[end + 1].strip() == '':
                end += 1
            code = '\n'.join(lines[:start] + lines[end + 1:])
    return code


def _get_all_function_names(code: str) -> list[str]:
    try:
        tree = ast.parse(code)
        return [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    except SyntaxError:
        return []


def _get_import_names(code: str) -> set[str]:
    try:
        tree = ast.parse(code)
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    names.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    names.add(node.module)
        return names
    except SyntaxError:
        return set()


def _parse_failing_test_names(pytest_log: str) -> list[str]:
    names = re.findall(r'FAILED\s+\S+::(\w+)', pytest_log)
    return list(dict.fromkeys(names))


def _parse_passing_count(pytest_log: str) -> int:
    match = re.search(r'(\d+)\s+passed', pytest_log)
    return int(match.group(1)) if match else 0


def _extract_error_for_test(pytest_log: str, test_name: str) -> str:
    pattern = (
        rf'_{2,}\s+{re.escape(test_name)}\s+_{2,}'
        rf'(.*?)'
        rf'(?=_{2,}\s+\w+\s+_{2,}|={2,}\s+short test summary|$)'
    )
    match = re.search(pattern, pytest_log, re.DOTALL)
    if match:
        return match.group(1).strip()[-2000:]
    return ""


def _detect_helper_root_cause(pytest_log: str, failing_names: list[str]) -> bool:
    if len(failing_names) < 3:
        return False

    first_errors = []
    for name in failing_names:
        error_block = _extract_error_for_test(pytest_log, name)
        if not error_block:
            continue
        for line in error_block.splitlines():
            stripped = line.strip()
            if stripped.startswith("E "):
                first_errors.append(stripped)
                break

    if len(first_errors) < 3:
        return False

    normalized = [_normalize_error(e) for e in first_errors]
    most_common = max(set(normalized), key=normalized.count)
    ratio = normalized.count(most_common) / len(normalized)
    return ratio >= 0.7


def _normalize_error(error: str) -> str:
    error = re.sub(r'\d+', 'N', error)
    error = re.sub(r'["\'].*?["\']', 'STR', error)
    error = re.sub(r'0x[0-9a-fA-F]+', 'ADDR', error)
    return error.strip()


class _StaleEntry:
    __slots__ = ("isolated_errors", "helper_errors")

    def __init__(self):
        self.isolated_errors: list[str] = []
        self.helper_errors: list[str] = []


class StaleTracker:

    def __init__(self):
        self._entries: dict[str, _StaleEntry] = {}
        self._stale: set[str] = set()

    def update(self, repair_type: str, pytest_log: str,
               failing_names: list[str],
               attempted_names: list[str],
               code_changed: bool = False):
        attempted_set = set(attempted_names)
        is_helper = repair_type in ("helper_root_cause", "helper_fallback")

        for name in failing_names:
            if name not in attempted_set:
                continue
            error = _extract_error_for_test(pytest_log, name)
            norm = _normalize_error(error)
            entry = self._entries.setdefault(name, _StaleEntry())
            if is_helper:
                entry.helper_errors.append(norm)
            else:
                entry.isolated_errors.append(norm)

        passed = set(self._entries.keys()) - set(failing_names)
        for name in passed:
            self._entries.pop(name, None)
            self._stale.discard(name)


        for name, entry in self._entries.items():
            iso_count = len(entry.isolated_errors)
            help_count = len(entry.helper_errors)

            if iso_count >= 1 and help_count >= 1:
                last_isolated = entry.isolated_errors[-1]
                last_helper = entry.helper_errors[-1]

                if last_isolated == last_helper:
                    if name not in self._stale:
                        print(f"      {name} is stale "
                              f"(isolated and helper repairs failed on an identical error)")
                    self._stale.add(name)

    def refresh_with_current_errors(self, pytest_log: str,
                                     failing_names: list[str]) -> list[str]:
        unstaled = []
        for name in list(self._stale):
            if name not in failing_names:
                self._stale.discard(name)
                self._entries.pop(name, None)
                unstaled.append(name)
                continue

            current_error = _extract_error_for_test(pytest_log, name)
            current_norm = _normalize_error(current_error)

            entry = self._entries.get(name)
            if not entry:
                continue

            last_known = set()
            if entry.isolated_errors:
                last_known.add(entry.isolated_errors[-1])
            if entry.helper_errors:
                last_known.add(entry.helper_errors[-1])

            if last_known and current_norm not in last_known:
                self._stale.discard(name)
                entry.isolated_errors.clear()
                entry.helper_errors.clear()
                unstaled.append(name)

        if unstaled:
            print(f"      {len(unstaled)} tests unblocked (error changed): "
                  f"{', '.join(unstaled[:5])}{'...' if len(unstaled) > 5 else ''}")

        return unstaled

    def detect_errors_changed(self, pytest_log: str,
                               failing_names: list[str]) -> bool:
        changed = 0
        total = 0
        for name in failing_names:
            entry = self._entries.get(name)
            if not entry:
                continue

            current_error = _extract_error_for_test(pytest_log, name)
            current_norm = _normalize_error(current_error)

            last_known = None
            if entry.helper_errors:
                last_known = entry.helper_errors[-1]
            elif entry.isolated_errors:
                last_known = entry.isolated_errors[-1]

            if last_known is not None:
                total += 1
                if current_norm != last_known:
                    changed += 1

        if total == 0:
            return False

        ratio = changed / total
        if ratio >= 0.5:
            print(f"      Errors changed for {changed}/{total} tests ({ratio:.0%})")
            return True
        return False

    def get_stale(self) -> list[str]:
        return sorted(self._stale)

    def filter_repairable(self, failing_names: list[str]) -> list[str]:
        return [n for n in failing_names if n not in self._stale]


_BANNED_IMPORTS = {
    "PIL", "pillow", "numpy", "pandas", "matplotlib",
    "scipy", "sklearn", "flask", "django", "fastapi",
    "sqlalchemy", "pydantic", "httpx", "aiohttp",
}

_AUTO_IMPORTS = {
    "datetime.now":       "from datetime import datetime",
    "datetime.utcnow":    "from datetime import datetime",
    "datetime(":          "from datetime import datetime",
    "timezone.utc":       "from datetime import timezone",
    "timedelta(":         "from datetime import timedelta",
    "json.dumps":         "import json",
    "json.loads":         "import json",
    "base64.b64encode":   "import base64",
    "base64.b64decode":   "import base64",
    "os.path":            "import os",
    "os.environ":         "import os",
    "re.search":          "import re",
    "re.match":           "import re",
    "re.findall":         "import re",
    "copy.deepcopy":      "import copy",
    "random.randint":     "import random",
    "random.choice":      "import random",
    "string.ascii":       "import string",
    "math.ceil":          "import math",
    "math.floor":         "import math",
}


def _fix_imports(code: str) -> str:
    lines = code.split('\n')
    changes_made = False

    cleaned_lines = []
    for line in lines:
        stripped = line.strip()

        is_banned = False
        if stripped.startswith("from "):
            module = stripped.split()[1].split(".")[0]
            if module in _BANNED_IMPORTS:
                is_banned = True
        elif stripped.startswith("import "):
            modules = stripped[7:].split(",")
            for m in modules:
                mod_name = m.strip().split()[0].split(".")[0]
                if mod_name in _BANNED_IMPORTS:
                    is_banned = True
                    break

        if is_banned:
            print(f"    [ImportFix] Removed unavailable import: {stripped}")
            changes_made = True
            continue

        cleaned_lines.append(line)

    code_body = '\n'.join(cleaned_lines)
    existing_imports = set()
    for line in cleaned_lines:
        stripped = line.strip()
        if stripped.startswith("import ") or stripped.startswith("from "):
            existing_imports.add(stripped)

    missing_imports = []
    for pattern, import_stmt in _AUTO_IMPORTS.items():
        if pattern in code_body and import_stmt not in existing_imports:
            module_name = import_stmt.split()[-1]

            already_imported = False
            for existing in existing_imports:
                if module_name in existing:
                    already_imported = True
                    break

            if not already_imported:
                missing_imports.append(import_stmt)
                existing_imports.add(import_stmt)

    if missing_imports:
        missing_imports = list(dict.fromkeys(missing_imports))
        print(f"    [ImportFix] Adding missing imports: {missing_imports}")
        changes_made = True

        last_import_idx = -1
        for i, line in enumerate(cleaned_lines):
            stripped = line.strip()
            if stripped.startswith("import ") or stripped.startswith("from "):
                last_import_idx = i

        insert_pos = last_import_idx + 1 if last_import_idx >= 0 else 0
        for imp in reversed(missing_imports):
            cleaned_lines.insert(insert_pos, imp)

    if changes_made:
        result = '\n'.join(cleaned_lines)
        try:
            ast.parse(result)
            return result
        except SyntaxError:
            print(f"    [ImportFix] Import fix caused a syntax error, reverting to the original")
            return code

    return code

def _is_truncated(code: str) -> bool:
    try:
        ast.parse(code)
        return False
    except SyntaxError:
        return True


def _salvage_truncated_code(code: str) -> str:
    lines = code.split('\n')

    last_test_start = None
    for i in range(len(lines) - 1, -1, -1):
        stripped = lines[i].strip()
        if stripped.startswith('def test_'):
            last_test_start = i
            break

    if last_test_start is not None:
        candidate = '\n'.join(lines[:last_test_start]).rstrip()
        if not _is_truncated(candidate) and count_test_functions(candidate) > 0:
            salvaged_count = count_test_functions(candidate)
            print(f"    [Salvage] Truncated code recovered: {salvaged_count} complete tests")
            return candidate

    for cut in range(1, min(200, len(lines))):
        candidate = '\n'.join(lines[:-cut]).rstrip()
        if not _is_truncated(candidate) and count_test_functions(candidate) > 0:
            salvaged_count = count_test_functions(candidate)
            print(f"    [Salvage] Fallback: {salvaged_count} complete tests (trimmed {cut} lines)")
            return candidate

    print(f"    [Salvage] Could not recover the code")
    return code


def generate_test_code(test_plan: dict, context_data: str, llm,
                       prompt_builder: PromptBuilder,
                       base_url: str = "http://localhost:8000") -> str:
    plan_str = json.dumps(test_plan, indent=2, ensure_ascii=False)
    prompt = prompt_builder.generation_prompt(plan_str, context_data, base_url)

    raw = llm.generate_text(prompt)

    clean = raw.strip()
    if clean.startswith("```python"):
        clean = clean[9:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()

    clean = _fix_imports(clean)


    if _is_truncated(clean):
        print(f"    TRUNCATION DETECTED: the code is syntactically invalid (likely the max_tokens limit)")
        original_lines = len(clean.split('\n'))
        clean = _salvage_truncated_code(clean)
        salvaged_lines = len(clean.split('\n'))
        print(f"    [Salvage] {original_lines} -> {salvaged_lines} lines")

    return clean


def validate_test_count(code: str, expected: int, llm=None,
                        prompt_builder: PromptBuilder = None,
                        base_url: str = "http://localhost:8000",
                        context: str = "") -> str:
    if _is_truncated(code):
        print(f"    [Validation] The code is still truncated, attempting salvage...")
        code = _salvage_truncated_code(code)

    actual = count_test_functions(code)

    if actual == 0 and len(code.strip()) > 100:
        print(f"    [Validation] 0 tests detected but the code is not empty "
              f"({len(code)} chars), likely still broken")
        return code

    if actual == expected:
        return code

    if actual > expected:
        excess = actual - expected
        print(f"    [Validation] {actual} tests, truncating to {expected} (-{excess})")
        return _remove_last_n_tests(code, excess)

    if not llm or not prompt_builder:
        print(f"    [Validation] {actual} tests (expected {expected}), LLM unavailable")
        return code

    missing = expected - actual
    print(f"    [Validation] {actual} tests, adding {missing}...")

    helpers = _extract_helpers_code(code)
    existing_names = _get_test_function_names(code)

    fill_prompt = prompt_builder.fill_tests_prompt(
        missing, helpers, existing_names, context, base_url
    )

    try:
        raw = llm.generate_text(fill_prompt)
    except Exception as e:
        print(f"    [Validation] LLM error: {e}")
        return code

    clean = raw.strip()
    if clean.startswith("```python"):
        clean = clean[9:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()

    if not clean:
        return code

    new_code = code.rstrip() + "\n\n\n" + clean

    try:
        ast.parse(new_code)
    except SyntaxError:
        print(f"    [Validation] Added tests have a syntax error, keeping the original")
        return code

    new_actual = count_test_functions(new_code)
    if new_actual > expected:
        excess = new_actual - expected
        new_code = _remove_last_n_tests(new_code, excess)
        new_actual = count_test_functions(new_code)

    print(f"    [Validation] {new_actual} tests (target {expected})")
    return new_code


def _validate_helpers_safe(old_helpers: str, new_helpers: str) -> tuple[bool, str]:
    old_imports = _get_import_names(old_helpers)
    new_imports = _get_import_names(new_helpers)
    missing_imports = old_imports - new_imports
    if missing_imports:
        return False, f"Missing imports: {missing_imports}"

    old_funcs = set(_get_all_function_names(old_helpers))
    new_funcs = set(_get_all_function_names(new_helpers))
    old_helpers_only = {f for f in old_funcs if not f.startswith("test_")}
    new_helpers_only = {f for f in new_funcs if not f.startswith("test_")}
    missing_funcs = old_helpers_only - new_helpers_only
    if missing_funcs:
        return False, f"Missing helper functions: {missing_funcs}"

    return True, "OK"


def _repair_helpers(master_code, pytest_log, helpers, failing_names, llm,
                     prompt_builder: PromptBuilder, base_url: str, context: str):
    sample_errors = []
    for name in failing_names[:3]:
        err = _extract_error_for_test(pytest_log, name)
        if err:
            sample_errors.append(f"Test {name}:\n{err}")

    prompt = prompt_builder.repair_helpers_prompt(
        helpers, sample_errors, len(failing_names), context, base_url
    )

    try:
        raw = llm.generate_text(prompt)
    except Exception as e:
        print(f"    [Repair] LLM error while repairing helpers: {e}")
        return master_code

    clean = raw.strip()
    if clean.startswith("```python"):
        clean = clean[9:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()

    if not clean:
        return master_code

    try:
        ast.parse(clean)
    except SyntaxError:
        print(f"    [Repair] Repaired helpers have a syntax error, keeping the original")
        return master_code

    is_safe, reason = _validate_helpers_safe(helpers, clean)
    if not is_safe:
        print(f"    [Repair] New helpers are not safe: {reason}")
        print(f"    [Repair] Attempting merge: keep the old imports and add the repaired functions")
        clean = _merge_helpers(helpers, clean)
        if not clean:
            print(f"    [Repair] Merge failed, keeping the original helpers")
            return master_code

    result = _replace_helpers(master_code, clean)

    try:
        ast.parse(result)
    except SyntaxError:
        print(f"    [Repair] Resulting file has a syntax error, keeping the original")
        return master_code

    return result


def _merge_helpers(old_helpers: str, new_helpers: str) -> str | None:
    return None


def _do_isolated_repairs(master_code, pytest_log, repairable, helpers, llm,
                          prompt_builder, base_url, context, stale_tests):
    to_repair = repairable[:MAX_INDIVIDUAL_REPAIRS]
    skipped_excess = len(repairable) - len(to_repair)

    if skipped_excess > 0:
        print(f"    [Repair:Isolated] Repairing {len(to_repair)}/{len(repairable)} tests"
              f" in a single prompt ({skipped_excess} deferred)...")
    else:
        print(f"    [Repair:Isolated] Repairing {len(to_repair)} tests in a single prompt...")

    test_entries = []
    for name in to_repair:
        code = _extract_function_code(master_code, name)
        if not code:
            print(f"      {name} not found in the code")
            continue
        error = _extract_error_for_test(pytest_log, name)
        test_entries.append((name, code, error))

    if not test_entries:
        return master_code, 0, to_repair

    prompt = prompt_builder.repair_batch_prompt(
        test_entries, helpers, context, base_url, stale_tests
    )

    try:
        raw = llm.generate_text(prompt)
    except Exception as e:
        print(f"    [Repair:Isolated] LLM error: {str(e)[:120]}")
        return master_code, 0, to_repair

    fixed_functions = _parse_batch_repair_response(raw)
    print(f"    [Repair:Isolated] LLM returned {len(fixed_functions)} repaired functions")

    repaired = 0
    for name, fixed_code in fixed_functions.items():
        if name not in {e[0] for e in test_entries}:
            continue

        new_code = _replace_function_code(master_code, name, fixed_code)
        try:
            ast.parse(new_code)
            master_code = new_code
            repaired += 1
        except SyntaxError:
            print(f"      {name} repair caused a syntax error, skipping")

    print(f"    [Repair:Isolated] Repaired {repaired}/{len(test_entries)}")
    return master_code, repaired, to_repair


def _parse_batch_repair_response(raw: str) -> dict[str, str]:
    clean = raw.strip()
    if clean.startswith("```python"):
        clean = clean[9:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()

    if not clean:
        return {}

    try:
        tree = ast.parse(clean)
    except SyntaxError:
        return _extract_functions_regex(clean)

    functions = {}
    lines = clean.split('\n')
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
            start = node.lineno - 1
            if node.decorator_list:
                start = node.decorator_list[0].lineno - 1
            end = node.end_lineno - 1
            func_code = '\n'.join(lines[start:end + 1])
            functions[node.name] = func_code

    return functions


def _extract_functions_regex(raw: str) -> dict[str, str]:
    functions = {}
    pattern = r'(def (test_\w+)\(.*?\):.*?)(?=\ndef |\Z)'
    for match in re.finditer(pattern, raw, re.DOTALL):
        func_code = match.group(1).rstrip()
        func_name = match.group(2)
        try:
            ast.parse(func_code)
            functions[func_name] = func_code
        except SyntaxError:
            continue
    return functions


def _do_helper_repair(master_code, pytest_log, repairable, helpers, llm,
                       prompt_builder, base_url, context):
    is_root_cause = _detect_helper_root_cause(pytest_log, repairable)

    if is_root_cause:
        print(f"    [Repair:Helper] Root cause detected ({len(repairable)} tests). "
              f"Repairing helpers...")
        repair_type = "helper_root_cause"
    else:
        print(f"    [Repair:Helper] {len(repairable)} tests still failing after isolated repair. "
              f"Trying helpers...")
        repair_type = "helper_fallback"

    new_code = _repair_helpers(
        master_code, pytest_log, helpers, repairable, llm, prompt_builder,
        base_url, context
    )
    return new_code, repair_type


def repair_failing_tests(master_code: str, pytest_log: str,
                         context: str, llm,
                         prompt_builder: PromptBuilder,
                         base_url: str,
                         stale_tracker: StaleTracker | None = None,
                         previous_repair_type: str | None = None,
                         ) -> tuple[str, dict]:
    repair_info = {
        "repair_type": None,
        "repaired_count": 0,
        "stale_skipped": 0,
        "regression_rollback": False,
        "errors_changed": False,
        "code_changed": False,
    }

    failing = _parse_failing_test_names(pytest_log)
    if not failing:
        return master_code, repair_info

    passing_before = _parse_passing_count(pytest_log)

    stale_tests = []
    repairable = failing
    errors_changed = False

    if stale_tracker:
        errors_changed = stale_tracker.detect_errors_changed(pytest_log, failing)
        repair_info["errors_changed"] = errors_changed

        unstaled = stale_tracker.refresh_with_current_errors(pytest_log, failing)

        stale_tests = stale_tracker.get_stale()
        repairable = stale_tracker.filter_repairable(failing)
        repair_info["stale_skipped"] = len(stale_tests)

        if stale_tests:
            print(f"    [Repair] {len(stale_tests)} stale tests skipped: "
                  f"{', '.join(stale_tests[:5])}{'...' if len(stale_tests) > 5 else ''}")

        if not repairable:
            print(f"    [Repair] All failing tests ({len(failing)}) are stale. "
                  f"Further iterations are pointless.")
            repair_info["repair_type"] = "all_stale_early_stop"
            return master_code, repair_info

    helpers = _extract_helpers_code(master_code)
    backup = master_code

    is_prev_helper = previous_repair_type in (
        "helper_root_cause", "helper_fallback",
    )

    if previous_repair_type is None:
        if len(repairable) >= 10:
            print(f"    [Repair] Detected {len(repairable)} failures. Forcing helper repair in the first iteration.")
            use_helper = True
        else:
            use_helper = False
    elif previous_repair_type == "isolated":
        use_helper = True
    elif is_prev_helper and errors_changed:
        print(f"    [Repair] Helper repair made progress (errors changed). "
              f"Retrying helper repair...")
        use_helper = True
    elif is_prev_helper and not errors_changed:
        use_helper = False
    else:
        use_helper = (previous_repair_type == "isolated")

    if use_helper:
        master_code, repair_type = _do_helper_repair(
            master_code, pytest_log, repairable, helpers,
            llm, prompt_builder, base_url, context,
        )
        repair_info["repair_type"] = repair_type
        repair_info["repaired_count"] = len(repairable)

        code_changed = (master_code != backup)
        if stale_tracker:
            stale_tracker.update(
                repair_type, pytest_log, failing,
                attempted_names=repairable,
                code_changed=code_changed,
            )

    else:
        master_code, repaired, attempted = _do_isolated_repairs(
            master_code, pytest_log, repairable, helpers,
            llm, prompt_builder, base_url, context, stale_tests,
        )
        repair_info["repair_type"] = "isolated"
        repair_info["repaired_count"] = repaired

        code_changed = (master_code != backup)
        if stale_tracker:
            stale_tracker.update(
                "isolated", pytest_log, failing,
                attempted_names=attempted,
                code_changed=code_changed,
            )

    before = count_test_functions(backup)
    after = count_test_functions(master_code)
    if before != after:
        print(f"    [Repair] Test count changed ({before} -> {after}), reverting")
        master_code = backup
        repair_info["regression_rollback"] = True

    repair_info["code_changed"] = (master_code != backup)

    return master_code, repair_info
