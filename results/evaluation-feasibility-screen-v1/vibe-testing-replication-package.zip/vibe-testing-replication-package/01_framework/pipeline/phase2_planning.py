"""Phase 2: obtain a JSON test plan from the model and normalize it to the fixed per-suite test budget."""
import json
import re

from pipeline.prompt_templates import PromptBuilder


def _count_plan_tests(plan: dict) -> int:
    return sum(
        len(ep.get("test_cases", []))
        for ep in plan.get("test_plan", [])
    )


def _trim_plan(plan: dict, target: int) -> dict:
    to_remove = _count_plan_tests(plan) - target
    if to_remove <= 0:
        return plan

    for ep in reversed(plan.get("test_plan", [])):
        cases = ep.get("test_cases", [])
        while cases and to_remove > 0:
            cases.pop()
            to_remove -= 1
        if to_remove == 0:
            break

    plan["test_plan"] = [ep for ep in plan["test_plan"] if ep.get("test_cases")]
    return plan


def _filter_reset_tests(plan: dict) -> dict:
    filtered = []
    removed = 0
    for ep in plan.get("test_plan", []):
        endpoint = ep.get("endpoint", "").lower()
        if "/reset" in endpoint:
            removed += len(ep.get("test_cases", []))
            continue

        cases = ep.get("test_cases", [])
        clean_cases = [
            tc for tc in cases
            if "reset" not in tc.get("name", "").lower()
        ]
        removed += len(cases) - len(clean_cases)

        if clean_cases:
            ep["test_cases"] = clean_cases
            filtered.append(ep)

    if removed > 0:
        print(f"  [Plan] Filtered out {removed} reset tests")

    plan["test_plan"] = filtered
    return plan


def _parse_plan_json(raw: str) -> dict:
    clean = raw.strip()
    clean = re.sub(r'^```(?:json)?\s*', '', clean)
    clean = re.sub(r'\s*```$', '', clean)

    try:
        return json.loads(clean)
    except json.JSONDecodeError:
        pass

    match = re.search(
        r'\{\s*"test_plan"\s*:\s*\[.*\]\s*\}',
        clean, re.DOTALL
    )
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    first_brace = clean.find('{')
    last_brace = clean.rfind('}')
    if first_brace != -1 and last_brace > first_brace:
        candidate = clean[first_brace:last_brace + 1]
        try:
            parsed = json.loads(candidate)
            if "test_plan" in parsed:
                return parsed
        except json.JSONDecodeError:
            pass

    print(f"  JSON parse error: no valid JSON found in response ({len(raw)} chars)")
    print(f"  First 200 chars: {raw[:200]}")
    return {"test_plan": []}


def generate_test_plan(context_data: str, llm,
                       prompt_builder: PromptBuilder,
                       test_count: int = 40) -> dict:

    base_prompt = prompt_builder.planning_prompt(context_data, test_count)

    MAX_ATTEMPTS = 4

    plan = {"test_plan": []}
    for attempt in range(1, MAX_ATTEMPTS + 1):
        plan = _filter_reset_tests(plan)
        actual = _count_plan_tests(plan)

        if actual == test_count:
            break

        if actual == 0:
            if attempt > 1:
                print(f"  [Plan] Retry {attempt}: empty plan, regenerating...")
            raw = llm.generate_text(base_prompt)
            plan = _parse_plan_json(raw)

        elif actual < test_count:
            missing = test_count - actual
            print(f"  [Plan] {actual} tests, adding {missing}...")
            fill_prompt = prompt_builder.planning_fill_prompt(
                json.dumps(plan, indent=2, ensure_ascii=False),
                actual, test_count,
            )
            raw = llm.generate_text(fill_prompt)
            new_plan = _parse_plan_json(raw)
            if _count_plan_tests(new_plan) > 0:
                plan = new_plan
        else:
            break

    plan = _filter_reset_tests(plan)
    actual = _count_plan_tests(plan)

    if actual > test_count:
        print(f"  [Plan] {actual} tests, truncating to {test_count}")
        plan = _trim_plan(plan, test_count)
    elif actual < test_count:
        print(f"  [Plan] {actual} tests (target {test_count}) after {MAX_ATTEMPTS} attempts")
    else:
        print(f"  [Plan] Exactly {test_count} tests")

    return plan
