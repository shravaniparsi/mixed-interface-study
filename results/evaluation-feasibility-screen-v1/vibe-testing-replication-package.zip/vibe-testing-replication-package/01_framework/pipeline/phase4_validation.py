"""Phase 4: execute the generated suite against the live API, manage the server lifecycle, reset state between runs and classify infrastructure failures."""
import os
import sys
import re
import time
import subprocess
import requests as req

OUTPUTS_DIR = "outputs"

_managed_servers: dict[str, subprocess.Popen] = {}

_docker_servers: dict[str, dict] = {}

_active_api: dict[str, str] = {}

INFRA_RETRY_MAX = 2
INFRA_RETRY_DELAY = 5

_DEFAULT_API_KEY = "test-api-key"


def _resolve_python(api_cfg: dict) -> str:
    abs_api = os.path.abspath(api_cfg["source_dir"])
    candidates = [
        os.path.join(abs_api, ".venv", "Scripts", "python.exe"),
        os.path.join(abs_api, ".venv", "bin", "python"),
        os.path.join(abs_api, "venv", "Scripts", "python.exe"),
        os.path.join(abs_api, "venv", "bin", "python"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return sys.executable


def _is_server_running(base_url: str) -> bool:
    try:
        r = req.get(f"{base_url}/health", timeout=2)
        return r.status_code in (200, 503)
    except Exception:
        return False


def _start_server_local(api_cfg: dict) -> subprocess.Popen | None:
    python_exe = _resolve_python(api_cfg)
    abs_api = os.path.abspath(api_cfg["source_dir"])
    cmd = api_cfg["server_cmd"]
    wait = api_cfg.get("startup_wait", 3.0)

    print(f"    [Server] Starting locally: {python_exe} {' '.join(cmd)}")
    kwargs = dict(cwd=abs_api, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

    proc = subprocess.Popen([python_exe] + cmd, **kwargs)

    for _ in range(int(wait * 4)):
        if proc.poll() is not None:
            err = proc.stderr.read().decode(errors="replace")
            print(f"    [Server] Failed to start: {err[:200]}")
            return None
        if _is_server_running(api_cfg["base_url"]):
            print(f"    [Server] Running.")
            return proc
        time.sleep(0.5)

    print(f"    [Server] Timeout.")
    proc.kill()
    return None


def _stop_server_local(proc):
    if proc and proc.poll() is None:
        if os.name == "nt":
            proc.kill()
        else:
            proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        print(f"    [Server] Stopped (local).")


def _docker_compose_cmd(api_cfg: dict) -> list[str]:
    compose_file = api_cfg.get("docker_compose_file", "docker-compose.yml")
    return ["docker", "compose", "-f", compose_file]


def _start_server_docker(api_cfg: dict) -> bool:
    abs_api = os.path.abspath(api_cfg["source_dir"])
    base_cmd = _docker_compose_cmd(api_cfg)
    wait = api_cfg.get("startup_wait", 15.0)

    print(f"    [Docker] Starting: docker compose up --build -d")
    result = subprocess.run(
        base_cmd + ["up", "--build", "-d"],
        cwd=abs_api,
        capture_output=True, text=True, timeout=300,
        encoding="utf-8", errors="replace",
    )

    if result.returncode != 0:
        print(f"    [Docker] docker compose up failed:")
        print(f"    {result.stderr[:300]}")
        return False

    print(f"    [Docker] Waiting for the server (max {wait}s)...")
    for _ in range(int(wait * 2)):
        if _is_server_running(api_cfg["base_url"]):
            print(f"    [Docker] Server running.")
            return True
        time.sleep(0.5)

    print(f"    [Docker] Timeout: the server is not responding.")
    logs = subprocess.run(
        base_cmd + ["logs", "--tail", "30"],
        cwd=abs_api, capture_output=True, text=True,
        encoding="utf-8", errors="replace",
    )
    print(f"    [Docker] Logy:\n{logs.stdout[-500:]}")
    return False


def _stop_server_docker(api_cfg: dict):
    abs_api = os.path.abspath(api_cfg["source_dir"])
    base_cmd = _docker_compose_cmd(api_cfg)

    print(f"    [Docker] Stopping container ({api_cfg['name']})...")
    subprocess.run(
        base_cmd + ["down", "--volumes", "--remove-orphans"],
        cwd=abs_api,
        capture_output=True, text=True, timeout=60,
        encoding="utf-8", errors="replace",
    )
    print(f"    [Docker] Stopped.")


def _restart_server_docker(api_cfg: dict) -> bool:
    abs_api = os.path.abspath(api_cfg["source_dir"])
    base_cmd = _docker_compose_cmd(api_cfg)

    print(f"    [Docker] Restarting container...")
    subprocess.run(
        base_cmd + ["down", "--volumes"],
        cwd=abs_api, capture_output=True, text=True, timeout=60,
        encoding="utf-8", errors="replace",
    )
    time.sleep(1)
    return _start_server_docker(api_cfg)


def _is_docker_mode(api_cfg: dict) -> bool:
    return api_cfg.get("docker", False)


def _ensure_correct_api(api_cfg: dict):
    base_url = api_cfg["base_url"]
    api_name = api_cfg["name"]
    is_docker = _is_docker_mode(api_cfg)

    current_api = _active_api.get(base_url)

    if current_api == api_name and _is_server_running(base_url):
        return

    if current_api and current_api != api_name:
        print(f"    [Server] '{current_api}' is running on {base_url}, but '{api_name}' is needed. Switching...")
        old_cfg = _docker_servers.get(base_url)
        if old_cfg:
            _stop_server_docker(old_cfg)
            _docker_servers.pop(base_url, None)
        old_proc = _managed_servers.pop(base_url, None)
        if old_proc and old_proc != "DOCKER_RUNNING":
            _stop_server_local(old_proc)
        _active_api.pop(base_url, None)
        time.sleep(2)

    if _is_server_running(base_url) and current_api != api_name:
        print(f"    [Server] An unknown server is already running on {base_url}. Stopping Docker for {api_name}...")
        if is_docker:
            _stop_server_docker(api_cfg)
            time.sleep(2)

        if _is_server_running(base_url):
            print(f"    [Server] The server on {base_url} is still running (likely a manual start).")
            print(f"    [Server] Stop it manually, or the run will continue with the current server.")

    if not _is_server_running(base_url):
        if is_docker:
            if _start_server_docker(api_cfg):
                _docker_servers[base_url] = api_cfg
                _active_api[base_url] = api_name
            else:
                print(f"    [Server] Failed to start {api_name}")
        else:
            proc = _start_server_local(api_cfg)
            if proc:
                _managed_servers[base_url] = proc
                _active_api[base_url] = api_name
            else:
                print(f"    [Server] Failed to start {api_name}")
    else:
        _active_api[base_url] = api_name


def stop_managed_server(api_cfg: dict):
    key = api_cfg["base_url"]

    if _is_docker_mode(api_cfg):
        if key in _docker_servers:
            _stop_server_docker(api_cfg)
            del _docker_servers[key]
    else:
        proc = _managed_servers.pop(key, None)
        if proc and proc != "DOCKER_RUNNING":
            _stop_server_local(proc)

    _active_api.pop(key, None)


def _disable_maintenance_mode(base_url: str, api_key: str = _DEFAULT_API_KEY) -> bool:
    try:
        r = req.post(
            f"{base_url}/admin/maintenance",
            json={"enabled": False},
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=5,
        )
        if r.status_code == 200:
            print(f"    [Maintenance] Maintenance mode disabled.")
            time.sleep(0.5)
            return True
        else:
            print(f"    [Maintenance] Failed to disable (status {r.status_code})")
            return False
    except Exception as e:
        print(f"    [Maintenance] Error: {e}")
        return False


def _is_maintenance_response(status_code: int, text: str) -> bool:
    return status_code == 503 and "maintenance" in text.lower()


def _reset_database(base_url: str) -> bool:
    try:
        r = req.post(f"{base_url}/reset", timeout=10)
        if r.status_code == 200:
            time.sleep(0.5)
            return True

        if _is_maintenance_response(r.status_code, r.text):
            print(f"    [Reset] Server is in maintenance mode. Disabling...")
            if _disable_maintenance_mode(base_url):
                r2 = req.post(f"{base_url}/reset", timeout=10)
                if r2.status_code == 200:
                    time.sleep(0.5)
                    print(f"    [Reset] Reset succeeded after disabling maintenance.")
                    return True
                else:
                    print(f"    [Reset] Reset after maintenance recovery failed: "
                          f"{r2.status_code}: {r2.text[:100]}")
                    return False
            else:
                return False

        print(f"    [Reset] Status {r.status_code}: {r.text[:100]}")
        return False
    except Exception as e:
        print(f"    [Reset] Error: {e}")
        return False


INFRA_ERROR_PATTERNS = [
    r"database is locked",
    r"OperationalError.*locked",
    r"sqlite3\.OperationalError",
    r"ConnectionError",
    r"ConnectionRefusedError",
    r"Connection refused",
    r"Read timed out",
    r"RemoteDisconnected",
    r"BrokenPipeError",
]

_infra_regex = re.compile("|".join(INFRA_ERROR_PATTERNS), re.IGNORECASE)

_maintenance_regex = re.compile(
    r"503.*maintenance|maintenance.*503|"
    r"Service temporarily unavailable for maintenance",
    re.IGNORECASE,
)


def _detect_infra_errors(pytest_output: str) -> tuple[bool, str | None]:
    failed_blocks = re.findall(
        r'FAILED.*?(?=\nFAILED|\n={3,}|\Z)', pytest_output, re.DOTALL
    )
    if not failed_blocks:
        return False, None
    match = _infra_regex.search(pytest_output)
    if not match:
        return False, None
    return True, match.group(0)


def _detect_maintenance_poisoning(pytest_output: str) -> bool:
    match = _maintenance_regex.search(pytest_output)
    if not match:
        return False

    error_lines = re.findall(r'E\s+.*503.*maintenance|E\s+.*maintenance.*503',
                             pytest_output, re.IGNORECASE)
    failed_count = pytest_output.count("FAILED")

    if failed_count == 0:
        return False

    ratio = len(error_lines) / failed_count
    return ratio >= 0.5


def _detect_single_root_cause(pytest_output: str) -> tuple[bool, str | None]:
    error_lines = re.findall(r'E\s+(.+)$', pytest_output, re.MULTILINE)
    if len(error_lines) < 2:
        return False, None

    def normalize(line):
        line = re.sub(r'\d+', 'N', line)
        line = re.sub(r'["\'].*?["\']', 'STR', line)
        return line.strip()

    normalized = [normalize(l) for l in error_lines]
    unique = set(normalized)
    most_common = max(unique, key=lambda x: normalized.count(x))
    ratio = normalized.count(most_common) / len(normalized)

    if ratio >= 0.8:
        idx = normalized.index(most_common)
        return True, error_lines[idx]
    return False, None


def _run_pytest(file_path: str) -> tuple[int, str]:
    result = subprocess.run(
        [
            "pytest", file_path, "-v", "--tb=short", "--disable-warnings",
            "--timeout=30",
            "--timeout-method=thread",
        ],
        capture_output=True, text=True, timeout=900,
    )
    return result.returncode, result.stdout + "\n" + result.stderr


def run_tests_and_validate(
    test_code: str,
    output_filename: str,
    api_cfg: dict,
    iteration: int = 0,
) -> tuple[bool, str]:
    os.makedirs(OUTPUTS_DIR, exist_ok=True)
    file_path = os.path.join(OUTPUTS_DIR, output_filename)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(test_code)

    base_url = api_cfg["base_url"]
    key = base_url
    is_docker = _is_docker_mode(api_cfg)

    _ensure_correct_api(api_cfg)

    if not _is_server_running(base_url):
        if is_docker:
            if not _start_server_docker(api_cfg):
                return False, "SERVER_ERROR: Failed to start the Docker container.\n"
            _docker_servers[key] = api_cfg
            _active_api[key] = api_cfg["name"]
        else:
            proc = _start_server_local(api_cfg)
            if proc is None:
                return False, "SERVER_ERROR: Failed to start the API server.\n"
            _managed_servers[key] = proc
            _active_api[key] = api_cfg["name"]

    _ensure_maintenance_off(base_url)

    print(f"    [Reset] Cleaning the database...")
    if not _reset_database(base_url):
        print(f"    [Reset] Reset failed, attempting to continue...")

    last_log = ""
    log_path = file_path.replace(".py", "_log.txt")

    if not hasattr(run_tests_and_validate, "_active_logs"):
        run_tests_and_validate._active_logs = set()
    if log_path not in run_tests_and_validate._active_logs:
        with open(log_path, "w", encoding="utf-8") as lf:
            lf.write(f"# Log for: {output_filename}\n")
            lf.write(f"# Start time: {__import__('datetime').datetime.now().isoformat()}\n\n")
        run_tests_and_validate._active_logs.add(log_path)

    last_log = ""
    for attempt in range(1, INFRA_RETRY_MAX + 1):
        try:
            returncode, full_log = _run_pytest(file_path)
            last_log = full_log

            with open(log_path, "a", encoding="utf-8") as lf:
                lf.write(f"\n{'=' * 60}\n")
                lf.write(f"== ITERATION {iteration} | pytest returncode={returncode}\n")
                lf.write(f"{'=' * 60}\n\n")
                lf.write(full_log)
                lf.write("\n")

            for line in full_log.strip().split("\n"):
                if any(k in line for k in ["passed", "failed", "FAILED", "ERROR"]):
                    print(f"    {line.strip()}")

            if returncode == 0:
                return True, full_log

            if _detect_maintenance_poisoning(full_log):
                print(f"    Maintenance-mode poisoning detected.")
                print(f"    Disabling maintenance mode and rerunning the tests...")
                _disable_maintenance_mode(base_url)
                time.sleep(1)
                _reset_database(base_url)

                if attempt < INFRA_RETRY_MAX:
                    continue
                else:
                    hint = (
                        f"\n\n=== FRAMEWORK HINT ===\n"
                        f"Maintenance mode poisoning: a test enabled maintenance "
                        f"and failed to disable it.\n"
                        f"The framework automatically disabled maintenance and reset the DB, "
                        f"but all retries are exhausted.\n"
                        f"Check test_toggle_maintenance_mode; it must ALWAYS "
                        f"disable maintenance at the end (even on error).\n"
                    )
                    return False, full_log + hint

            is_infra, pattern = _detect_infra_errors(full_log)
            if is_infra and attempt < INFRA_RETRY_MAX:
                print(f"    Infrastructure error detected ({pattern})")
                print(f"    Retry {attempt}/{INFRA_RETRY_MAX} za {INFRA_RETRY_DELAY}s...")

                if is_docker:
                    _restart_server_docker(api_cfg)
                else:
                    old_proc = _managed_servers.pop(key, None)
                    if old_proc and old_proc != "DOCKER_RUNNING":
                        _stop_server_local(old_proc)
                        time.sleep(2)
                    proc = _start_server_local(api_cfg)
                    if proc:
                        _managed_servers[key] = proc

                time.sleep(INFRA_RETRY_DELAY)
                _reset_database(base_url)
                continue

            is_single, root_msg = _detect_single_root_cause(full_log)
            if is_single:
                print(f"    All errors share the same cause: {root_msg[:120]}")

                if _maintenance_regex.search(root_msg or ""):
                    print(f"    Root cause is maintenance mode. Disabling...")
                    _disable_maintenance_mode(base_url)
                    time.sleep(1)
                    _reset_database(base_url)
                    if attempt < INFRA_RETRY_MAX:
                        continue

                if _infra_regex.search(root_msg or ""):
                    if attempt < INFRA_RETRY_MAX:
                        print(f"    Retry (single root cause = infra)...")
                        _reset_database(base_url)
                        time.sleep(INFRA_RETRY_DELAY)
                        continue

                hint = (
                    f"\n\n=== FRAMEWORK HINT ===\n"
                    f"All {full_log.count('FAILED')} failures share the same root cause.\n"
                    f"Check whether the tests correctly create their own data "
                    f"and do not rely on data from other tests.\n"
                    f"Each test must be self-contained.\n"
                )
                return False, full_log + hint

            return False, full_log

        except subprocess.TimeoutExpired:
            last_log = "TIMEOUT: pytest exceeded the 600s limit.\n"
            print(f"    {last_log.strip()}")
            if attempt < INFRA_RETRY_MAX:
                print(f"    Retry after timeout...")
                _reset_database(base_url)
                time.sleep(INFRA_RETRY_DELAY)
                continue
            return False, last_log

    return False, last_log


def _ensure_maintenance_off(base_url: str):
    try:
        r = req.get(f"{base_url}/health", timeout=3)
        if _is_maintenance_response(r.status_code, r.text):
            print(f"    [Maintenance] Server is in maintenance mode (from a previous test). Disabling...")
            _disable_maintenance_mode(base_url)
    except Exception:
        pass
