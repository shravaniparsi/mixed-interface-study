# Replication Package — Vibe Testing for REST APIs

Companion replication package for the manuscript:

> **Vibe Testing for REST APIs: A Context-Taxonomic Benchmark of LLM-Generated Test Suites**
> (under review, 2026)

It contains the complete experimental pipeline, the target API, all context
artifacts, every archived experiment result (per-run JSON metrics and, where
retained, the LLM-generated pytest suites), the mutation-testing and
instruction-following materials, the statistical analyses, and the published
figures with their generator scripts.

## Package layout

| Folder | Contents |
|---|---|
| `01_framework/` | The Vibe Testing pipeline (context assembly -> planning -> generation -> validation -> metrics -> diagnostics/repair) plus the experiment YAML configurations and `.env.template`. |
| `02_target_api/` | The 50-endpoint Bookstore REST API under test (FastAPI + SQLite; Docker or direct uvicorn). |
| `03_context_artifacts/` | The five context-level input artifacts (OpenAPI spec, business documentation, source code, DB schema, reference tests) that define the L0-L4 taxonomy. |
| `04_context_axis/` | Balanced experiment: 5 cloud LLMs x L0-L4 x 5 runs (t = 0.4) = 125 runs. Per-run metrics JSONs, aggregates, and all 125 generated test suites with logs and test plans. |
| `05_temperature_axis/` | Temperature sweeps: 7 models x 6 temperatures x 3 runs at L1 (+ Qwen L2 sweep). Per-run metrics JSONs and the retained generated suites. |
| `06_openweight_context_matrix/` | Auxiliary open-weight context matrix (Qwen 2.5-Coder 32B L0-L4, DeepSeek-R1 32B, Gemma4 31B). |
| `07_mutation_testing/` | 13 hand-curated mutants of `crud.py`, runner scripts, per-suite kill results for all 125 cloud suites, aggregate matrices, per-operator kill rates, TVR-MS gap bootstrap. |
| `08_instruction_following/` | Instruction-following compliance (IFC) probe definitions and per-model composite results. |
| `09_statistics/` | Statistical validation scripts (Friedman + Kendall W, Holm, Wilcoxon, Mann-Whitney + Cliff's delta, Nemenyi, bootstrap CIs) and their outputs. |
| `10_figures/` | The eight published figures (extracted from the manuscript source, byte-identical to the published versions) and their matplotlib generator scripts. |

`MANIFEST.sha256` lists SHA-256 checksums of every file. `LICENSE` (MIT, software)
and `DATA-LICENSE.txt` (CC BY 4.0, data and figures) are at the package root.

## Reproduction quick-start

1. **Environment** — Python 3.11+, `pip install -r 01_framework/requirements.txt`.
2. **Target API** — `cd 02_target_api && docker compose up -d` (or `uvicorn app.main:app --port 8000`). The SQLite DB is created automatically.
3. **API keys** — copy `01_framework/.env.template` to `.env` and fill in the keys for the providers you want to run. Open-weight models require an Ollama host (set its URL in the YAML config).
4. **Generation experiment** — `python main.py --config configs/<experiment>.yaml`. Each run writes the generated suite + log to `outputs/` and appends per-run metrics to `results/experiment_<name>_<timestamp>.json`.
5. **Analyses** — scripts in `04`/`07`/`08`/`09`/`10` reproduce the aggregations, mutation matrix, IFC scores, statistics and figures from the archived JSONs.

> **Path note.** Analysis scripts are archived exactly as run; their path
> constants refer to the original working tree (`results/`, `v12_data/`,
> `outputs/`, `v12/outputs_v12_<model>/`, `v_temp/`). Mapping to this package:
> `results/` -> `0{4,5,6,7}_*/results/`, `v12_data/` -> `04_context_axis/results/`,
> `v12/outputs_v12_<m>/` -> `04_context_axis/generated_suites/outputs_v12_<m>/`,
> `outputs/` -> `05_temperature_axis/generated_suites/<group>/`,
> figure/stat scripts' own folder -> the respective `scripts/` subfolder.
> Adjust the constants at the top of a script (or recreate the original layout)
> before re-running it.

## Data dictionary (per-run JSON record)

Each experiment JSON is a list of run records with the key fields:

| Field | Meaning |
|---|---|
| `llm`, `api`, `level`, `run_id`, `temperature` | Experimental cell coordinates. |
| `iterations_used`, `all_tests_passed`, `early_stopped` | Feedback-loop outcome (max 5 iterations). |
| `plan_test_count` | Number of scenarios in the generated test plan (target 30). |
| `metrics.test_validity.validity_rate_pct` | TVR — share of generated tests that pass against the unmutated API. |
| `metrics.endpoint_coverage` / `assertion_density` / `response_validation` | EC, AD, RV quality metrics. |
| `diagnostics` | Per-iteration failure analysis from the repair loop. |
| `token_usage` | Prompt/completion token accounting per phase. |
| `output_filename`, `plan_filename` | Names of the generated suite / plan files. |

## Figure map

| Manuscript figure | File | Generator script | Primary data |
|---|---|---|---|
| Fig. 1 workflow | `Fig1_vibe_testing_workflow.png` | `scripts/_fig1_v3.py` | — (schematic) |
| Fig. 2 Bookstore schema | `Fig2_bookstore_api_schema.png` | `scripts/_fig2_v4.py` | `02_target_api/db_schema.sql` |
| Fig. 3 TVR by level | `Fig3_tvr_by_context_level.png` | `scripts/_fig3_fig7_lines.py` | `04_context_axis/results/` |
| Fig. 4 quality metrics | `Fig4_quality_metrics_by_level.png` | `scripts/_fig4_v4.py` | `04_context_axis/results/` |
| Fig. 5 scenario distribution | `Fig5_test_scenario_distribution.png` | `scripts/_fig6_scenarios.py` | test plans in `04_context_axis/generated_suites/` |
| Fig. 6 temperature | `Fig6_temperature_sensitivity.png` | `scripts/_fig5_v5.py` | `05_temperature_axis/results/` |
| Fig. 7 mutation by level | `Fig7_mutation_score_by_level.png` | `scripts/_fig3_fig7_lines.py` | `07_mutation_testing/results/mutation_matrix_multisuite.json` |
| Fig. 8 TVR vs MS | `Fig8_tvr_vs_mutation_score.png` | `scripts/_fig78_multisuite.py` | `07_mutation_testing/` |

(Script output filenames keep their historical working names, e.g.
`fig5_temperature.png` is manuscript Fig. 6 and `fig6_scenarios.png` is
manuscript Fig. 5; the table above is authoritative.)

## Archive completeness notes

* Generated suites are fully archived for the balanced context axis (125/125)
  and for four temperature sweeps (table in `05_temperature_axis/README.md`).
  For the remaining temperature sweeps and the open-weight context matrix the
  compute host was decommissioned before file retrieval; the complete per-run
  metrics, diagnostics and token accounting survive in the results JSONs,
  which are the artifacts all manuscript analyses use.
* Mutation testing: `07_mutation_testing/per_suite_results/` holds the kill
  matrix of every one of the 125 cloud suites against all 13 mutants
  (baseline-aware kill criterion). Open-weight cells are single-suite
  (`mutation_matrix_aggregate.json`).
* All framework and analysis code, prompt templates, and experiment configs are
  in English. The target API and its business documentation
  (`03_context_artifacts/api1_bookstore/documentation.md`) are in Czech because
  the API models a Czech-domain bookstore; they are preserved verbatim as the
  exact inputs supplied to the models.

## Provenance and sanitization

For privacy, host-specific absolute paths were normalized to placeholders
(`<REPO_ROOT>`, `<BOOKSTORE_API>`, `<RUN_HOST>`, `<OLLAMA_HOST>`,
`<USER_HOME>`), personal author metadata was removed from documentation
headers, and an internal project prefix was dropped from experiment
identifiers (`experiment_<prefix>_temp_gemini_*` -> `experiment_temp_gemini_*`),
consistently in file names and inside scripts, so script <-> data references
remain valid. No measurement values, generated code, test outcomes, or
statistics were altered.

## License and citation

The software in this package (the framework, the target API, and all analysis
and figure scripts) is released under the MIT License (see `LICENSE`). The data,
documentation, and figures (per-run JSON metrics, generated suites, mutation and
IFC results, statistics, the eight figures, and all README files) are released
under Creative Commons Attribution 4.0 International, CC BY 4.0 (see
`DATA-LICENSE.txt`). Cite the accompanying article and this package via the DOI
shown on the dataset's repository landing page.
