"""Generator for the test-scenario-distribution figure."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).parent.parent
V12 = ROOT / "v12_data"
OUT = Path(__file__).parent / "fig6_scenarios.png"

LEVELS = ["L0", "L1", "L2", "L3", "L4"]
LABELS = {
    "claude-haiku-4-5-20251001": "Claude Haiku 4.5",
    "deepseek-v4-flash":         "DeepSeek-V4-Flash",
    "deepseek-chat":             "DeepSeek-Chat",
    "mistral-large-2512":        "Mistral Large 3",
    "gemini-3.1-flash-lite-preview": "Gemini 3.1 Flash Lite",
}

agg = {L: {"happy_path": [], "error": [], "edge_case": []} for L in LEVELS}

for f in sorted(V12.glob("experiment_v12_*.json")):
    for r in json.load(open(f, encoding="utf-8")):
        m = LABELS.get(r["llm"], r["llm"])
        if m not in LABELS.values(): continue
        L = r["level"]
        dist = r.get("metrics", {}).get("test_type_distribution", {}).get("distribution", {})
        for kind in ["happy_path", "error", "edge_case"]:
            v = dist.get(kind, {}).get("pct")
            if v is not None:
                agg[L][kind].append(v)

hp = [np.mean(agg[L]["happy_path"]) for L in LEVELS]
er = [np.mean(agg[L]["error"]) for L in LEVELS]
ec = [np.mean(agg[L]["edge_case"]) for L in LEVELS]

x = np.arange(len(LEVELS))
fig, ax = plt.subplots(figsize=(10, 5.5))

C_HP = "#6fa8dc"
C_ER = "#e67c73"
C_EC = "#f6b26b"

b1 = ax.bar(x, hp, color=C_HP, edgecolor='#333', linewidth=1.0, label='Happy path')
b2 = ax.bar(x, er, bottom=hp, color=C_ER, edgecolor='#333', linewidth=1.0, label='Error')
b3 = ax.bar(x, ec, bottom=np.array(hp)+np.array(er),
            color=C_EC, edgecolor='#333', linewidth=1.0, label='Edge case')

for i, (h, e, eg) in enumerate(zip(hp, er, ec)):
    ax.text(i, h/2, f"{h:.1f}%", ha='center', va='center', fontsize=11, fontweight='bold', color='#1c4587')
    ax.text(i, h + e/2, f"{e:.1f}%", ha='center', va='center', fontsize=11, fontweight='bold', color='#7f3030')
    ax.text(i, h + e + eg/2, f"{eg:.1f}%", ha='center', va='center', fontsize=10, fontweight='bold', color='#7a4a1a')

ax.set_xticks(x); ax.set_xticklabels(LEVELS, fontsize=12)
ax.set_xlabel("Context level", fontsize=13)
ax.set_ylabel("Share of test scenarios (%)", fontsize=13)
ax.set_ylim(0, 116)
ax.tick_params(axis='both', labelsize=12)
ax.legend(loc='upper center', fontsize=12, frameon=True, framealpha=0.93, ncol=3,
          bbox_to_anchor=(0.5, 1.09))
ax.grid(True, ls="--", alpha=0.4, axis='y', zorder=0)


fig.tight_layout()
fig.savefig(OUT, dpi=170, bbox_inches="tight")
plt.close(fig)
print(f"Saved {OUT.name}")
print(f"  Happy path: {[round(v,1) for v in hp]}")
print(f"  Error:      {[round(v,1) for v in er]}")
print(f"  Edge case:  {[round(v,1) for v in ec]}")
