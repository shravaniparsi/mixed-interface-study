"""Generator for the temperature-sensitivity figure."""
from pathlib import Path
import json
from collections import defaultdict
import numpy as np
from scipy import stats as scstats
import matplotlib.pyplot as plt

ROOT = Path(__file__).parent.parent
RES = ROOT / "results"
OUT = Path(__file__).parent / "fig5_temperature.png"
STATS_OUT = Path(__file__).parent / "fig5_stats.json"

TEMPS = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
MIN_EXECUTED = 6

SOURCES = [
    ("Gemini 3.1 Flash Lite",  RES / "experiment_temp_gemini_20260415_105537.json",      "#d62728", "cloud"),
    ("DeepSeek-Chat",          RES / "experiment_temp_deepseek_chat_20260428_062426.json", "#17becf", "cloud"),
    ("Mistral Large 3",        RES / "experiment_temp_mistral_20260505_213959.json",     "#9467bd", "cloud"),
    ("DeepSeek-V4-Flash",      RES / "experiment_temp_deepseek_v4_20260505_205646.json", "#2ca02c", "cloud"),
    ("Claude Haiku 4.5",       RES / "experiment_temp_claude_haiku_20260506_201948.json","#1f77b4", "cloud"),
    ("Qwen 2.5-Coder 32B",     RES / "experiment_temp_qwen_20260415_075716.json",        "#ff7f0e", "open"),
    ("DeepSeek-R1 32B",        RES / "experiment_temp_deepseek_20260415_084630.json",    "#8c564b", "open"),
    ("Gemma4 31B",             RES / "experiment_temp_gemma_20260416_003100.json",       "#7f7f7f", "open"),
]

F_LBL, F_AX, F_LEG = 16, 14, 12.5

model_data = {}
excluded = defaultdict(list)
for label, p, color, cohort in SOURCES:
    if not p.exists():
        continue
    by_t = defaultdict(list)
    for r in json.load(open(p, encoding="utf-8")):
        if "metrics" not in r:
            continue
        tv = r["metrics"].get("test_validity", {})
        t = round(r.get("temperature", 0.0), 2)
        v = tv.get("validity_rate_pct")
        tot = tv.get("total_executed", 0)
        if t not in TEMPS or v is None:
            continue
        if tot < MIN_EXECUTED:
            excluded[label].append((t, tot))
            continue
        by_t[t].append(v)
    model_data[label] = (color, cohort, by_t)

print("Excluded generation-failure runs (total_executed < 15):")
for m, lst in excluded.items():
    print(f"  {m}: {lst}")

fig, (axL, axR) = plt.subplots(1, 2, figsize=(15, 6), sharey=True)

def panel(ax, cohort_key):
    for label, (color, cohort, by_t) in model_data.items():
        if cohort != cohort_key:
            continue
        xs, means, sds = [], [], []
        for t in TEMPS:
            vs = by_t.get(t, [])
            if not vs:
                continue
            xs.append(t)
            means.append(float(np.mean(vs)))
            sds.append(float(np.std(vs, ddof=1)) if len(vs) > 1 else 0.0)
        ax.errorbar(xs, means, yerr=sds, marker='o', markersize=9, lw=2.4,
                    capsize=5, elinewidth=1.6, color=color, label=label, zorder=4)

panel(axL, "cloud")
panel(axR, "open")

for ax in (axL, axR):
    ax.set_xlabel("Sampling temperature", fontsize=F_LBL)
    ax.grid(True, ls="--", alpha=0.4, zorder=1)
    ax.set_xticks(TEMPS)
    ax.tick_params(axis='both', labelsize=F_AX)
axL.set_ylabel("Test Validity Rate (%)", fontsize=F_LBL)
axL.set_ylim(-5, 118)

axL.legend(loc="lower left", fontsize=F_LEG, frameon=True, framealpha=0.95)
axR.legend(loc="upper right", fontsize=F_LEG, frameon=True, framealpha=0.95)

pkw = dict(fontsize=24, fontweight='bold', va='top', ha='left')
axL.text(0.02, 0.985, "A", transform=axL.transAxes, **pkw)
axR.text(0.02, 0.985, "B", transform=axR.transAxes, **pkw)

fig.tight_layout()
fig.savefig(OUT, dpi=170, bbox_inches="tight")
plt.close(fig)
print(f"Saved {OUT.name}")

cloud_full = []
cloud_names = []
for label, (color, cohort, by_t) in model_data.items():
    if cohort != "cloud":
        continue
    if all(by_t.get(t) for t in TEMPS):
        cloud_full.append([float(np.mean(by_t[t])) for t in TEMPS])
        cloud_names.append(label)
M = np.array(cloud_full)
chi2 = p_fried = None
if M.shape[0] >= 3:
    chi2, p_fried = scstats.friedmanchisquare(*[M[:, j] for j in range(M.shape[1])])
    print(f"Within-cloud Friedman across temps (n={M.shape[0]} models): chi2={chi2:.2f}, p={p_fried:.3f}")

all_c, all_o = [], []
for label, (color, cohort, by_t) in model_data.items():
    tgt = all_c if cohort == "cloud" else all_o
    for t in TEMPS:
        tgt.extend(by_t.get(t, []))
u, p_mw = scstats.mannwhitneyu(all_c, all_o, alternative="two-sided")
gt = sum(1 for a in all_c for b in all_o if a > b)
lt = sum(1 for a in all_c for b in all_o if a < b)
delta = (gt - lt) / (len(all_c) * len(all_o))
print(f"Cloud vs open (valid runs): n_c={len(all_c)}, n_o={len(all_o)}, MW p={p_mw:.3e}, Cliff's d={delta:.3f}")

STATS_OUT.write_text(json.dumps({
    "min_executed": MIN_EXECUTED,
    "excluded": {m: lst for m, lst in excluded.items()},
    "cloud_friedman": {"models": cloud_names, "chi2": round(float(chi2), 2) if chi2 else None,
                        "p": round(float(p_fried), 3) if p_fried else None},
    "mw": {"n_cloud": len(all_c), "n_open": len(all_o),
            "p": float(p_mw), "cliffs_delta": round(float(delta), 3)},
}, indent=2), encoding="utf-8")
print(f"Saved {STATS_OUT.name}")
