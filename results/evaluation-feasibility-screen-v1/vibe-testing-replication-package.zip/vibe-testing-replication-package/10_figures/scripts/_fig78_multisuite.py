"""Generator for the TVR-versus-mutation-score scatter figure."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).parent.parent
MS_DIR = ROOT / "v_temp" / "mutation_multisuite"
OLD = ROOT / "results" / "mutation_matrix_aggregate.json"
F7 = Path(__file__).parent / "fig7_mutation_mean.png"
F8 = Path(__file__).parent / "fig7_tvr_vs_ms.png"

CLOUD = {
    "Claude Haiku 4.5": "#1f77b4", "DeepSeek-V4-Flash": "#2ca02c",
    "DeepSeek-Chat": "#17becf", "Mistral Large 3": "#9467bd",
    "Gemini 3.1 Flash Lite": "#d62728",
}
OSS = {"Qwen 2.5-Coder 32B": "#ff7f0e", "DeepSeek-R1 32B": "#8c564b", "Gemma4 31B": "#7f7f7f"}
LEVELS = ["L0", "L1", "L2", "L3", "L4"]

runs = defaultdict(list)
allpts = []
for jf in sorted(MS_DIR.glob("*.json")):
    d = json.load(open(jf, encoding="utf-8"))
    if d.get("score"):
        runs[d["model"]].append(d["score"]["pct"])
        if d.get("baseline_tvr") is not None:
            allpts.append((d["model"], d["baseline_tvr"], d["score"]["pct"]))

old = json.load(open(OLD, encoding="utf-8"))
NF = {"DeepSeek-V4": "DeepSeek-V4-Flash", "Mistral Large 2411": "Mistral Large 3",
      "Qwen 2.5-coder 32b": "Qwen 2.5-Coder 32B", "DeepSeek-R1 32b": "DeepSeek-R1 32B",
      "Gemma4 31b": "Gemma4 31B"}
oss_runs = defaultdict(list)
for c in old:
    m = NF.get(c.get("model"), c.get("model"))
    if m in OSS and c.get("score") and isinstance(c["score"].get("pct"), (int, float)):
        oss_runs[m].append(c["score"]["pct"])
        if c.get("baseline_tvr") is not None:
            allpts.append((m, c["baseline_tvr"], c["score"]["pct"]))

stats = []
for m in CLOUD:
    if runs.get(m):
        stats.append((m, np.mean(runs[m]), np.std(runs[m], ddof=1) if len(runs[m]) > 1 else 0, CLOUD[m], len(runs[m])))
for m in OSS:
    if oss_runs.get(m):
        stats.append((m, np.mean(oss_runs[m]), np.std(oss_runs[m], ddof=1) if len(oss_runs[m]) > 1 else 0, OSS[m], len(oss_runs[m])))
stats.sort(key=lambda x: -x[1])

fig, ax = plt.subplots(figsize=(10.5, 5.5))
xs = range(len(stats))
ax.bar(xs, [s[1] for s in stats], yerr=[s[2] for s in stats], color=[s[3] for s in stats],
       edgecolor='#333', linewidth=1.0, capsize=5, error_kw={'lw': 1.3})
ax.set_xticks(list(xs))
ax.set_xticklabels([s[0] for s in stats], rotation=22, ha='right', fontsize=11)
ax.set_ylabel("Mean mutation score (%)", fontsize=13)
ax.set_ylim(0, 65)
ax.grid(True, ls="--", alpha=0.4, axis='y', zorder=0)
ax.tick_params(axis='y', labelsize=12)
for i, s in enumerate(stats):
    ax.text(i, s[1] + s[2] + 1.5, f"{s[1]:.1f}", ha='center', fontsize=11, fontweight='bold')
fig.tight_layout()
fig.savefig(F7, dpi=170, bbox_inches="tight"); plt.close(fig)
print(f"Saved {F7.name}")
for s in stats:
    print(f"  {s[0]:<24} {s[1]:5.1f} +- {s[2]:4.1f}  (n={s[4]} cells)")

fig, ax = plt.subplots(figsize=(8.5, 6.5))
ax.plot([0, 100], [0, 100], '--', color='#888', lw=1.4, alpha=0.85, zorder=1)
ax.annotate("y = x", xy=(72, 72), fontsize=12, color='#555', ha='center', va='center', rotation=45,
            bbox=dict(facecolor='white', edgecolor='none', pad=2))
for m, tvr, ms in allpts:
    color = CLOUD.get(m) or OSS.get(m) or "#555"
    marker = 'o' if m in CLOUD else 's'
    ax.scatter(tvr, ms, s=70, color=color, edgecolor='#222', linewidth=0.6,
               marker=marker, alpha=0.38, zorder=3)
ax.set_xlabel("Baseline TVR on unmutated API (%)", fontsize=13)
ax.set_ylabel("Mutation score (%)", fontsize=13)
ax.set_xlim(0, 100); ax.set_ylim(0, 100)
ax.set_xticks(range(0, 101, 10)); ax.set_yticks(range(0, 101, 10))
ax.grid(True, ls="--", alpha=0.4, zorder=1); ax.set_aspect('equal')
ax.tick_params(labelsize=11)
handles = [Line2D([0],[0], marker='o', color='w', markerfacecolor=c, markeredgecolor='#222',
                  markersize=10, label=m) for m, c in CLOUD.items() if runs.get(m)]
handles += [Line2D([0],[0], marker='s', color='w', markerfacecolor=c, markeredgecolor='#222',
                   markersize=10, label=m) for m, c in OSS.items() if oss_runs.get(m)]
ax.legend(handles=handles, loc="upper left", fontsize=9.5, frameon=True, framealpha=0.95,
          title="Model (circle = cloud, square = open-weight)", title_fontsize=9.5)
fig.tight_layout()
fig.savefig(F8, dpi=170, bbox_inches="tight"); plt.close(fig)
print(f"Saved {F8.name}  ({len(allpts)} points)")
