"""Generator for the TVR-by-context-level and mutation-score-by-level line figures."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).parent.parent
V12 = ROOT / "v12_data"
AGG = json.load(open(ROOT / "results" / "mutation_matrix_multisuite.json", encoding="utf-8"))
F3 = Path(__file__).parent / "fig3_tvr.png"
F7 = Path(__file__).parent / "fig7_mutation_mean.png"

LEVELS = ["L0", "L1", "L2", "L3", "L4"]
X = np.arange(5)
CLOUD = {
    "Claude Haiku 4.5": "#1f77b4", "DeepSeek-V4-Flash": "#2ca02c",
    "DeepSeek-Chat": "#17becf", "Mistral Large 3": "#9467bd",
    "Gemini 3.1 Flash Lite": "#d62728",
}
OSS = {"Qwen 2.5-Coder 32B": "#ff7f0e", "DeepSeek-R1 32B": "#8c564b", "Gemma4 31B": "#7f7f7f"}
LBL = {"claude-haiku-4-5-20251001": "Claude Haiku 4.5", "deepseek-v4-flash": "DeepSeek-V4-Flash",
       "deepseek-chat": "DeepSeek-Chat", "mistral-large-2512": "Mistral Large 3",
       "gemini-3.1-flash-lite-preview": "Gemini 3.1 Flash Lite"}
F_LBL, F_AX, F_LEG = 15, 13, 11.5

cell = defaultdict(list)
for f in sorted(V12.glob("experiment_v12_*.json")):
    for r in json.load(open(f, encoding="utf-8")):
        cell[(LBL[r["llm"]], r["level"])].append(r["metrics"]["test_validity"]["validity_rate_pct"])

fig, ax = plt.subplots(figsize=(9.5, 5.6))
for m, color in CLOUD.items():
    means = [np.mean(cell[(m, L)]) for L in LEVELS]
    sds = [np.std(cell[(m, L)], ddof=1) for L in LEVELS]
    ax.errorbar(X, means, yerr=sds, marker="o", markersize=8, lw=2.3, capsize=4,
                elinewidth=1.4, color=color, label=m, zorder=4)
ax.set_xticks(X); ax.set_xticklabels(LEVELS, fontsize=F_AX)
ax.set_xlabel("Context level", fontsize=F_LBL)
ax.set_ylabel("Test Validity Rate (%)", fontsize=F_LBL)
ax.set_ylim(55, 104)
ax.grid(True, ls="--", alpha=0.4, zorder=1)
ax.tick_params(axis="both", labelsize=F_AX)
ax.legend(loc="lower center", bbox_to_anchor=(0.5, 0.19), fontsize=F_LEG,
          frameon=True, framealpha=0.95, ncol=1)
ax.text(0.02, 0.05,
        "Friedman (25 blocks): χ² = 12.14, p = 0.016, W = 0.121\n"
        "L0 to L1: +5.87 pp (Wilcoxon p_Holm = 0.005, r = +0.75)",
        transform=ax.transAxes, ha="left", va="bottom", fontsize=10.5,
        bbox=dict(facecolor="white", edgecolor="#bbbbbb", boxstyle="round,pad=0.4"))
fig.tight_layout()
fig.savefig(F3, dpi=170, bbox_inches="tight"); plt.close(fig)
print(f"Saved {F3.name}")

fig, ax = plt.subplots(figsize=(9.5, 5.6))
for m, color in CLOUD.items():
    means, sds = [], []
    for L in LEVELS:
        c = AGG["cloud_cells"].get(f"{m}::{L}")
        means.append(c["ms_mean"] if c else np.nan)
        sds.append(c["ms_sd"] if c else 0)
    ax.errorbar(X, means, yerr=sds, marker="o", markersize=8, lw=2.3, capsize=4,
                elinewidth=1.4, color=color, label=m, zorder=4)
for m, color in OSS.items():
    xs, ys = [], []
    for j, L in enumerate(LEVELS):
        c = AGG["oss_cells"].get(f"{m}::{L}")
        if c is not None:
            xs.append(j); ys.append(c["ms_mean"])
    if xs:
        ax.plot(xs, ys, marker="s", markersize=8, lw=2.0, ls="--", color=color,
                label=m + " (single suite)", zorder=3)
ax.set_xticks(X); ax.set_xticklabels(LEVELS, fontsize=F_AX)
ax.set_xlabel("Context level", fontsize=F_LBL)
ax.set_ylabel("Mutation score (%)", fontsize=F_LBL)
ax.set_ylim(-3, 78)
ax.grid(True, ls="--", alpha=0.4, zorder=1)
ax.tick_params(axis="both", labelsize=F_AX)
ax.legend(loc="upper center", fontsize=10, frameon=True, framealpha=0.95, ncol=2)
fig.tight_layout()
fig.savefig(F7, dpi=170, bbox_inches="tight"); plt.close(fig)
print(f"Saved {F7.name}")
