"""Generator for the context-effect quality-metrics figure."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats as scstats

ROOT = Path(__file__).parent.parent
V12 = ROOT / "v12_data"
STUDENT_CC = ROOT / "v_temp" / "student_zip" / "vibe-testing-framework-main" / "v12"
OUT = Path(__file__).parent / "fig4_metrics.png"

LEVELS = ["L0", "L1", "L2", "L3", "L4"]
LABELS = {
    "claude-haiku-4-5-20251001": "Claude Haiku 4.5",
    "deepseek-v4-flash":         "DeepSeek-V4-Flash",
    "deepseek-chat":             "DeepSeek-Chat",
    "mistral-large-2512":        "Mistral Large 3",
    "gemini-3.1-flash-lite-preview": "Gemini 3.1 Flash Lite",
}
CC_SLUG = {
    "Claude Haiku 4.5":         "claude",
    "DeepSeek-Chat":            "deepseek-chat",
    "DeepSeek-V4-Flash":        "deepseek-v4",
    "Gemini 3.1 Flash Lite":    "gemini",
    "Mistral Large 3":          "mistral",
}

rows = []
for f in sorted(V12.glob("experiment_v12_*.json")):
    for r in json.load(open(f, encoding="utf-8")):
        m = LABELS.get(r["llm"], r["llm"])
        met = r.get("metrics", {})
        rows.append({
            "model": m, "level": r["level"],
            "ec":  met.get("endpoint_coverage", {}).get("endpoint_coverage_pct"),
            "ad":  met.get("assertion_depth", {}).get("assertion_depth"),
            "rv":  met.get("response_validation", {}).get("response_validation_pct"),
        })

import re
cc_rows = []
for label, slug in CC_SLUG.items():
    cov_dir = STUDENT_CC / f"outputs_v12_{slug}" / "coverage_results"
    if not cov_dir.exists():
        continue
    for jf in sorted(cov_dir.glob("coverage_*.json")):
        try:
            data = json.load(open(jf, encoding="utf-8"))
        except Exception:
            continue
        mt = re.search(r"__L(\d)__run(\d)", jf.name)
        if not mt: continue
        level = "L" + mt.group(1)
        files = data.get("files", {})
        tot = sum(s.get("num_statements", 0) for s in files.values())
        cov = sum(s.get("covered_lines", 0) for s in files.values())
        pct = 100.0 * cov / tot if tot else 0
        cc_rows.append({"model": label, "level": level, "cc": pct})


def build_matrix(field, source_rows):
    M = []
    for model in LABELS.values():
        m_rows = [[r[field] for r in source_rows
                   if r["model"] == model and r["level"] == L and r[field] is not None]
                  for L in LEVELS]
        n = min(len(c) for c in m_rows)
        for k in range(n):
            row = [m_rows[i][k] for i in range(len(LEVELS))]
            if all(v is not None for v in row):
                M.append(row)
    return np.array(M)


metrics = {
    "EC":  ("Endpoint Coverage (%)",       build_matrix("ec", rows), (25, 50)),
    "AD":  ("Assertion Depth\n(assertions / test)", build_matrix("ad", rows), (1.5, 3.2)),
    "RV":  ("Response Validation (%)",     build_matrix("rv", rows), (35, 90)),
    "CC":  ("Code Coverage (%)",           build_matrix("cc", cc_rows), (60, 76)),
}

panels = [("A", "EC"), ("B", "AD"), ("C", "RV"), ("D", "CC")]
fig, axes = plt.subplots(2, 2, figsize=(13, 8.5))
axes = axes.flatten()

x = np.arange(len(LEVELS))

for ax, (panel, key) in zip(axes, panels):
    ylabel, M, ylim = metrics[key]
    if M.shape[0] == 0:
        continue
    chi2, p = scstats.friedmanchisquare(*[M[:, j] for j in range(5)])
    N, k_ = M.shape
    W = chi2 / (N * (k_ - 1))
    means = M.mean(axis=0)
    sems  = M.std(axis=0, ddof=1) / np.sqrt(N)

    ax.plot(x, means, marker='o', markersize=10, lw=3.0, color='#1c4587', zorder=5)
    ax.errorbar(x, means, yerr=sems, fmt='none', ecolor='#1c4587', capsize=6,
                elinewidth=1.5, zorder=4)
    ax.fill_between(x, means - sems, means + sems, color='#1c4587', alpha=0.15, zorder=3)
    for xi, m_v, s_v in zip(x, means, sems):
        ax.annotate(f"{m_v:.2f}", (xi, m_v + s_v), xytext=(0, 5),
                    textcoords='offset points', ha='center', va='bottom', fontsize=10,
                    fontweight='bold', color='#1c4587')

    ax.set_xticks(x); ax.set_xticklabels(LEVELS, fontsize=11)
    ax.set_xlabel("Context level", fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_ylim(ylim)
    ax.grid(True, ls="--", alpha=0.4, zorder=1)
    ax.tick_params(axis='both', labelsize=10)

    ax.text(0.97, 0.05,
            f"χ² = {chi2:.2f},  p = {p:.4g}\nKendall's W = {W:.3f}",
            transform=ax.transAxes, ha='right', va='bottom',
            fontsize=10, color='#222',
            bbox=dict(facecolor='white', edgecolor='#bbbbbb',
                      boxstyle='round,pad=0.4'))

    ax.text(0.025, 0.96, panel, transform=ax.transAxes, ha='left', va='top',
            fontsize=20, fontweight='bold')

fig.tight_layout()
fig.savefig(OUT, dpi=170, bbox_inches="tight")
plt.close(fig)
print(f"Saved {OUT.name}")
