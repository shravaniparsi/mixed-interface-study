"""Generator for the Bookstore API entity-relationship figure."""
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).parent / "fig2_bookstore.png"

fig, ax = plt.subplots(figsize=(12, 5.5))
ax.set_xlim(0, 14)
ax.set_ylim(0, 7.0)
ax.set_aspect('equal')
ax.axis('off')

C_ENT  = "#cfe2f3"
F_NAME = 16
F_FLD  = 12
F_CARD = 13


def ent(ax, x, y, w, h, name, fields=None):
    bb = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.06,rounding_size=0.18",
                        linewidth=1.8, facecolor=C_ENT, edgecolor='#1f4e79', zorder=2)
    ax.add_patch(bb)
    if fields:
        ax.text(x + w/2, y + h - 0.22, name, ha='center', va='top',
                fontsize=F_NAME, fontweight='bold', zorder=3)
        ax.plot([x + 0.12, x + w - 0.12], [y + h - 0.55, y + h - 0.55],
                color='#777', lw=1.0, zorder=3)
        ax.text(x + w/2, y + (h - 0.55) * 0.50, "\n".join(fields), ha='center', va='center',
                fontsize=F_FLD, color='#222', zorder=3)
    else:
        ax.text(x + w/2, y + h/2, name, ha='center', va='center',
                fontsize=F_NAME, fontweight='bold', zorder=3)


def relation(ax, p1, p2, label, lw=1.6):
    arr = FancyArrowPatch(p1, p2, arrowstyle='-', mutation_scale=0,
                          color='#444', lw=lw, zorder=1)
    ax.add_patch(arr)
    mx, my = (p1[0]+p2[0])/2, (p1[1]+p2[1])/2
    ax.text(mx, my, label, ha='center', va='center', fontsize=F_CARD, color='#222',
            bbox=dict(facecolor='white', edgecolor='#666666',
                      boxstyle='round,pad=0.3'),
            zorder=4, fontweight='bold')


bx, by, bw, bh = 5.5, 3.05, 3.0, 1.8
ent(ax, bx, by, bw, bh, "Books",
    fields=["isbn  (unique, 10–13)", "price", "stock", "discount %"])
books_top    = (bx + bw/2, by + bh)
books_bottom = (bx + bw/2, by)

au_x, au_y, au_w, au_h = 0.7, 5.35, 2.4, 0.95
ent(ax, au_x, au_y, au_w, au_h, "Authors")
relation(ax, (au_x + au_w, au_y + au_h/2),
         (bx, by + bh*0.78), "1 : N")

ct_x, ct_y, ct_w, ct_h = 10.9, 5.35, 2.4, 0.95
ent(ax, ct_x, ct_y, ct_w, ct_h, "Categories")
relation(ax, (ct_x, ct_y + ct_h/2),
         (bx + bw, by + bh*0.78), "1 : N")

tg_x, tg_y, tg_w, tg_h = 6.3, 5.70, 1.4, 0.65
ent(ax, tg_x, tg_y, tg_w, tg_h, "Tags")
relation(ax, (tg_x + tg_w/2, tg_y), books_top, "N : M")

rv_x, rv_y, rv_w, rv_h = 0.7, 0.6, 2.7, 1.30
ent(ax, rv_x, rv_y, rv_w, rv_h, "Reviews",
    fields=["rating 1–5", "comment"])
relation(ax, (rv_x + rv_w, rv_y + rv_h/2),
         (bx, by + bh*0.22), "N : 1")

oi_x, oi_y, oi_w, oi_h = 5.5, 0.6, 3.0, 1.30
ent(ax, oi_x, oi_y, oi_w, oi_h, "Order Items",
    fields=["qty", "price snapshot"])
relation(ax, books_bottom, (oi_x + oi_w/2, oi_y + oi_h), "1 : N")

or_x, or_y, or_w, or_h = 10.5, 0.6, 2.8, 1.30
ent(ax, or_x, or_y, or_w, or_h, "Orders",
    fields=["state machine"])
relation(ax, (oi_x + oi_w, oi_y + oi_h/2),
         (or_x, or_y + or_h/2), "N : 1")

fig.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
fig.savefig(OUT, dpi=170, bbox_inches='tight', pad_inches=0.1)
print(f"Saved {OUT.name}")
