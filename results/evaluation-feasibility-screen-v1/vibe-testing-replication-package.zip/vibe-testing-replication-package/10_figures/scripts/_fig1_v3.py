"""Generator for the Vibe Testing workflow figure."""
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

OUT = Path(__file__).parent / "fig1_workflow.png"

fig, ax = plt.subplots(figsize=(12, 6.0))
ax.set_xlim(0, 14)
ax.set_ylim(0, 7)
ax.set_aspect('equal')
ax.axis('off')

C_CTX_PARENT = "#dfe7ee"
C_CTX  = "#cfe2f3"
C_PLAN = "#d9ead3"
C_CODE = "#fff2cc"
C_VAL  = "#f4cccc"
C_REP  = "#ead1dc"
C_OUT  = "#d9d2e9"
C_AUX  = "#fce5cd"

F_TITLE = 16
F_LBL   = 14
F_SM    = 12


def box(ax, x, y, w, h, text, color, fontsize=F_LBL, fontweight='bold',
        subtext=None, edgecolor='#333', lw=1.6):
    bb = FancyBboxPatch((x, y), w, h,
                        boxstyle="round,pad=0.05,rounding_size=0.18",
                        linewidth=lw, facecolor=color, edgecolor=edgecolor, zorder=3)
    ax.add_patch(bb)
    if subtext:
        ax.text(x + w/2, y + h*0.65, text, ha='center', va='center',
                fontsize=fontsize, fontweight=fontweight, zorder=4)
        ax.text(x + w/2, y + h*0.28, subtext, ha='center', va='center',
                fontsize=F_SM, color='#333', zorder=4)
    else:
        ax.text(x + w/2, y + h/2, text, ha='center', va='center',
                fontsize=fontsize, fontweight=fontweight, zorder=4)


def arrow(ax, p1, p2, color='#333', lw=2.0, style='->', ls='-', zorder=5):
    ar = FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=22,
                         color=color, linewidth=lw, linestyle=ls, zorder=zorder)
    ax.add_patch(ar)


parent_x, parent_y = 0.4, 4.85
parent_w, parent_h = 13.2, 1.75
container = FancyBboxPatch((parent_x, parent_y), parent_w, parent_h,
                           boxstyle="round,pad=0.05,rounding_size=0.20",
                           linewidth=2.0, facecolor=C_CTX_PARENT, edgecolor='#1f4e79',
                           zorder=1)
ax.add_patch(container)

ax.text(parent_x + 0.20, parent_y + parent_h - 0.18, "Context artifacts",
        fontsize=F_LBL, fontweight='bold', color='#1f4e79', va='top', ha='left',
        zorder=4)

n = 5
inner_y = parent_y + 0.25
inner_h = 0.85
inner_w = 2.20
gap = (parent_w - n*inner_w) / (n + 1)
ctx_labels = [("L0", "OpenAPI"), ("L1", "+ Docs"), ("L2", "+ Source"),
              ("L3", "+ DB schema"), ("L4", "+ Ref. tests")]
for i, (lbl, sub) in enumerate(ctx_labels):
    x = parent_x + gap + i*(inner_w + gap)
    box(ax, x, inner_y, inner_w, inner_h, lbl, C_CTX,
        fontsize=F_LBL, subtext=sub, lw=1.3)

stage_y = 2.85
stage_h = 1.30
stage_w = 2.80
stage_gap = (14 - 0.6 - 4*stage_w) / 3
stage_x0 = 0.3
stage_x = [stage_x0 + i*(stage_w + stage_gap) for i in range(4)]

stages = ["Stage 1\nContext\nAssembly",
          "Stage 2\nPlan\nGeneration",
          "Stage 3\nCode\nGeneration",
          "Stage 4\nValidation"]
stage_colors = [C_CTX, C_PLAN, C_CODE, C_VAL]
for i, (text, color) in enumerate(zip(stages, stage_colors)):
    box(ax, stage_x[i], stage_y, stage_w, stage_h, text, color,
        fontsize=F_LBL, fontweight='bold', lw=1.8)

arrow(ax, (stage_x[0] + stage_w/2, parent_y),
      (stage_x[0] + stage_w/2, stage_y + stage_h),
      color='#1f4e79', lw=2.2)

for i in range(3):
    y_mid = stage_y + stage_h/2
    arrow(ax, (stage_x[i] + stage_w, y_mid),
          (stage_x[i+1], y_mid), color='#333', lw=2.2)

aux_y = 0.40
aux_h = 1.10
aux_w = 2.80

pm_x = stage_x[0]
box(ax, pm_x, aux_y, aux_w, aux_h, "Process metrics",
    C_AUX, fontsize=F_LBL, subtext="iters · stale · tokens", lw=1.6)

tr_x = stage_x[2]
box(ax, tr_x, aux_y, aux_w, aux_h, "Targeted repair",
    C_REP, fontsize=F_LBL, subtext="helpers / isolated / stale", lw=1.6)

fs_x = stage_x[3]
box(ax, fs_x, aux_y, aux_w, aux_h, "Final test suite",
    C_OUT, fontsize=F_LBL, subtext="(passed)", lw=1.6)

def elbow(ax, pts, color, lw=2.2, ls='-', arrow_end=True):
    for i in range(len(pts) - 1):
        p1, p2 = pts[i], pts[i + 1]
        last = (i == len(pts) - 2)
        if last and arrow_end:
            arrow(ax, p1, p2, color=color, lw=lw, ls=ls)
        else:
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=color, lw=lw, ls=ls, zorder=5,
                    solid_capstyle='round')

elbow(ax, [(stage_x[0] + stage_w/2, stage_y), (pm_x + aux_w/2, aux_y + aux_h)],
      color='#b08000', lw=2.2, ls=':')

sx4_cx = stage_x[3] + stage_w/2
branch_y = stage_y - 0.45
elbow(ax, [(sx4_cx, stage_y), (sx4_cx, branch_y)], color='#555', lw=2.2, arrow_end=False)

elbow(ax, [(sx4_cx, branch_y), (fs_x + aux_w/2, branch_y), (fs_x + aux_w/2, aux_y + aux_h)],
      color='#2a7e2a', lw=2.2)
ax.text(fs_x + aux_w/2 + 0.15, branch_y - 0.55, "pass",
        color='#2a7e2a', fontsize=F_SM, fontweight='bold', ha='left', va='center')

elbow(ax, [(sx4_cx, branch_y), (tr_x + aux_w/2, branch_y), (tr_x + aux_w/2, aux_y + aux_h)],
      color='#b34141', lw=2.2)
ax.text((sx4_cx + tr_x + aux_w/2) / 2, branch_y - 0.16, "fail",
        color='#b34141', fontsize=F_SM, fontweight='bold', ha='center', va='top')

loop_x = tr_x - 0.45
mid_y = (stage_y + aux_y + aux_h) / 2
elbow(ax, [(tr_x, aux_y + aux_h/2),
           (loop_x, aux_y + aux_h/2),
           (loop_x, stage_y - 0.25),
           (stage_x[2] + stage_w*0.30, stage_y - 0.25),
           (stage_x[2] + stage_w*0.30, stage_y)],
      color='#b34141', lw=2.2, ls='--')
ax.text(loop_x - 0.20, mid_y, "repair loop\n(passing tests\npreserved)",
        color='#b34141', fontsize=F_SM, fontstyle='italic',
        ha='right', va='center')

fig.subplots_adjust(left=0.0, right=1.0, top=1.0, bottom=0.0)
fig.savefig(OUT, dpi=170, bbox_inches='tight', pad_inches=0.1)
print(f"Saved {OUT.name}, size {OUT.stat().st_size/1024:.1f} KB")
