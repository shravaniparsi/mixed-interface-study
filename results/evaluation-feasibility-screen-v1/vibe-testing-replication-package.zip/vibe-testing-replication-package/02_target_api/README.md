# Bookstore API (target system under test)

A deliberately feature-rich 50-endpoint REST API (FastAPI + SQLAlchemy +
SQLite) used as the controlled target of all experiments: authors, books,
categories, tags, reviews, orders, discounts, statistics; soft delete,
duplicate detection, API-key-protected endpoints, pagination and business
rules (e.g. an author with existing books cannot be deleted -> 409).

Run with Docker:

    docker compose up -d        # serves on http://localhost:8000

or directly:

    pip install -r requirements.txt
    uvicorn app.main:app --port 8000

The SQLite database is created automatically on startup. `db_schema.sql`
documents the schema; `docs/documentation.md` is the business documentation
(L1 context artifact); `tests/test_existing.py` are the reference tests
(part of the L4 context). `app/crud.py` is the mutation-testing target.
