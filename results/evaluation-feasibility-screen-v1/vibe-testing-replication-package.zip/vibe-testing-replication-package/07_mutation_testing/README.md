# Mutation testing

13 hand-curated single-point mutants of `02_target_api/app/crud.py`
(HTTP status codes, boolean/arithmetic operators, off-by-one comparisons,
raise->pass, return->None). Operator definitions: `scripts/mutation_pilot.py`.

* `per_suite_results/` — one JSON per generated suite (125 cloud suites):
  per-mutant kill verdicts with the baseline-aware criterion
  (kill = passed < baseline OR failed > baseline OR errors > baseline).
* `results/mutation_matrix_multisuite.json` — per (model, level) mean +- SD
  across the 5 suites, per-model means, TVR-MS gap with 10k bootstrap CI.
* `results/mutation_matrix_aggregate.json` — earlier single-suite matrix
  (includes the open-weight cells).
* `results/operator_aggregate.json` — per-operator kill rates across suites.
* `scripts/_mutation_worker.py` + `_mutation_local.py` — parallel local
  runner (isolated API copies per worker, pristine-restore of crud.py).
* `scripts/_bootstrap_ms_gap.py` — TVR-MS gap bootstrap.
