"""Definitions of the 13 hand-curated crud.py mutants and a single-suite mutation-scoring pilot."""
import argparse
import os
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

REPO = Path("<RUN_HOST>/projects")
BOOKSTORE = REPO / "bookstore-api"
CRUD = BOOKSTORE / "app" / "crud.py"
PORT = 8000

MUTATIONS = [
    ("EQ_TO_NE", r"\b==\b", "!="),
    ("LT_TO_LE", r"(?<![<=!])<(?!=)", "<="),
    ("GT_TO_GE", r"(?<![>=!])>(?!=)", ">="),
    ("PLUS_TO_MINUS", r"(?<![+\-=*/])\+(?![+=])", "-"),
    ("AND_TO_OR", r"\band\b", "or"),
    ("OR_TO_AND", r"\bor\b", "and"),
    ("TRUE_TO_FALSE", r"\bTrue\b", "False"),
    ("FALSE_TO_TRUE", r"\bFalse\b", "True"),
    ("ZERO_TO_ONE", r"(?<![\w.])0(?![\w.])", "1"),
    ("ONE_TO_TWO", r"(?<![\w.])1(?![\w.])", "2"),
    ("RAISE_TO_PASS", r"raise\s+HTTPException", "pass  # mutated"),
    ("STATUS_400_TO_500", r"status_code=400", "status_code=500"),
    ("STATUS_404_TO_200", r"status_code=404", "status_code=200"),
    ("STATUS_409_TO_200", r"status_code=409", "status_code=200"),
    ("RETURN_NONE", r"return\s+\w+", "return None"),
]


def start_uvicorn():
    proc = subprocess.Popen(
        ["python3", "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
         "--port", str(PORT)],
        cwd=str(BOOKSTORE),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        preexec_fn=os.setsid,
    )
    import urllib.request, urllib.error
    for _ in range(30):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/openapi.json", timeout=1)
            return proc
        except (urllib.error.URLError, ConnectionResetError):
            time.sleep(0.5)
    raise RuntimeError("uvicorn nestartoval do 15s")


def stop_uvicorn(proc):
    if proc and proc.poll() is None:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            proc.wait(timeout=5)
        except Exception:
            pass


def reset_db():
    import urllib.request
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{PORT}/reset", method="POST")
        urllib.request.urlopen(req, timeout=10)
        return True
    except Exception:
        return False


def run_pytest(test_file: Path, timeout=120) -> tuple[int, int, int, str]:
    proc = subprocess.run(
        ["python3", "-m", "pytest", str(test_file),
         "--tb=no", "--timeout=30", "--timeout-method=thread", "-q"],
        cwd=str(BOOKSTORE),
        capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    m_pass = re.search(r"(\d+)\s+passed", out)
    m_fail = re.search(r"(\d+)\s+failed", out)
    m_err  = re.search(r"(\d+)\s+error", out)
    p = int(m_pass.group(1)) if m_pass else 0
    f = int(m_fail.group(1)) if m_fail else 0
    e = int(m_err.group(1))  if m_err  else 0
    return p, f, e, out[-500:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--max-mutations", type=int, default=10)
    args = ap.parse_args()

    test_file = Path(args.test_file)
    assert test_file.exists(), f"Test file not found: {test_file}"
    assert CRUD.exists(), f"crud.py not found: {CRUD}"

    original = CRUD.read_text(encoding="utf-8")

    print("=" * 70)
    print("BASELINE - original crud.py, no mutation")
    proc = start_uvicorn(); reset_db()
    p0, f0, e0, _ = run_pytest(test_file)
    stop_uvicorn(proc)
    total = p0 + f0 + e0
    print(f"  passed={p0}, failed={f0}, errored={e0}, total={total}")
    if p0 == 0 or total == 0:
        print("WARN: baseline failure - abort pilot")
        return

    results = []

    for i, (name, pattern, replacement) in enumerate(MUTATIONS[:args.max_mutations], 1):
        print(f"\n[{i}/{args.max_mutations}] MUTATION {name}: {pattern!r} -> {replacement!r}")
        new_text, n_subs = re.subn(pattern, replacement, original, count=1)
        if n_subs == 0:
            print("  (pattern not found - skip)")
            results.append({"name": name, "applied": False})
            continue

        CRUD.write_text(new_text, encoding="utf-8")
        try:
            proc = start_uvicorn()
            reset_db()
            p, f, e, tail = run_pytest(test_file)
            stop_uvicorn(proc)
        except Exception as ex:
            print(f"  uvicorn/pytest failure: {ex}")
            CRUD.write_text(original, encoding="utf-8")
            results.append({"name": name, "applied": True, "error": str(ex)})
            continue

        killed = (p < p0) or (f > f0) or (e > e0)
        verdict = "KILLED" if killed else "SURVIVED"
        print(f"  passed={p} (baseline {p0}), failed={f} (baseline {f0}), errored={e} (baseline {e0})  -> {verdict}")
        results.append({
            "name": name, "applied": True, "killed": killed,
            "passed": p, "failed": f, "errored": e,
            "baseline_passed": p0, "baseline_failed": f0, "baseline_errored": e0,
        })

    CRUD.write_text(original, encoding="utf-8")

    print("\n" + "=" * 70)
    print("SUMMARY")
    print(f"{'Mutation':<22} {'Result':<10} {'P/F/E':<15}")
    print("-" * 70)
    applied = [r for r in results if r.get("applied") and "killed" in r]
    killed = [r for r in applied if r["killed"]]
    survived = [r for r in applied if not r["killed"]]
    for r in results:
        if not r.get("applied"):
            print(f"{r['name']:<22} {'no-pattern':<10}")
        elif "error" in r:
            print(f"{r['name']:<22} {'ERROR':<10} {r['error'][:40]}")
        else:
            verdict = "KILLED" if r["killed"] else "SURVIVED"
            pfe = f"{r['passed']}/{r['failed']}/{r['errored']}"
            print(f"{r['name']:<22} {verdict:<10} {pfe:<15}")
    print("-" * 70)
    if applied:
        ms = 100 * len(killed) / len(applied)
        print(f"Mutation score: {len(killed)}/{len(applied)} = {ms:.1f}%")

    import json
    out = Path("results")
    out.mkdir(exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_file = out / f"mutation_pilot_{ts}.json"
    out_file.write_text(json.dumps({
        "test_file": str(test_file),
        "baseline": {"passed": p0, "failed": f0, "errored": e0},
        "mutations": results,
    }, indent=2), encoding="utf-8")
    print(f"\nResult saved to: {out_file}")


if __name__ == "__main__":
    main()
