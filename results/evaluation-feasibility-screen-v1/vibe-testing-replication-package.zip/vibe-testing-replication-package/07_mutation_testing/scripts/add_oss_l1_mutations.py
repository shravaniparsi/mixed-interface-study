"""Add the open-weight L1 cells to the mutation matrix."""
import json
import subprocess
import sys
from pathlib import Path

REPO = Path("<RUN_HOST>")
PILOT = REPO / "v_temp" / "mutation_pilot.py"
AGG_FILE = REPO / "results" / "mutation_matrix_aggregate.json"

CELLS = [
    {
        "model": "Gemma4 31b",
        "level": "L1",
        "temperature": 0.4,
        "test_file": str(REPO / "outputs" / "test_generated_gemma4_31b-fast__bookstore__L1__run1__t0_4.py"),
        "baseline_tvr": 20.0,
    },
    {
        "model": "DeepSeek-R1 32b",
        "level": "L1",
        "temperature": 0.4,
        "test_file": str(REPO / "outputs" / "test_generated_deepseek-r1_32b-fast__bookstore__L1__run1__t0_4.py"),
        "baseline_tvr": 32.14,
    },
]


def run_pilot(test_file, max_mutations=15, timeout=600):
    proc = subprocess.run(
        [sys.executable, str(PILOT),
         "--test-file", str(test_file),
         "--max-mutations", str(max_mutations)],
        cwd="<BOOKSTORE_API>",
        capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    import re
    m = re.search(r"Mutation score:\s*(\d+)/(\d+)\s*=\s*([0-9.]+)%", out)
    score = None
    if m:
        score = {"killed": int(m.group(1)), "applied": int(m.group(2)), "pct": float(m.group(3))}
    m2 = re.search(r"Result saved to:\s*(\S+)", out)
    out_json = m2.group(1) if m2 else None
    m3 = re.search(r"BASELINE.*?passed=(\d+).*?failed=(\d+).*?errored=(\d+).*?total=(\d+)", out, re.DOTALL)
    baseline_meta = None
    if m3:
        baseline_meta = {"p": int(m3.group(1)), "f": int(m3.group(2)),
                         "e": int(m3.group(3)), "total": int(m3.group(4))}
    return {"score": score, "out_json": out_json, "baseline": baseline_meta, "stdout_tail": out[-500:]}


def main():
    agg = json.load(open(AGG_FILE, encoding="utf-8"))

    for cell_def in CELLS:
        existing = next((c for c in agg
                         if c.get("model") == cell_def["model"]
                         and c.get("level") == cell_def["level"]
                         and abs(c.get("temperature", -1) - cell_def["temperature"]) < 0.01), None)
        if existing and existing.get("score"):
            print(f"[SKIP] {cell_def['model']} {cell_def['level']} already in aggregate")
            continue

        print(f"\n=== {cell_def['model']} {cell_def['level']} t={cell_def['temperature']} ===")
        print(f"  file: {Path(cell_def['test_file']).name}")
        try:
            result = run_pilot(cell_def["test_file"])
            print(f"  -> baseline {result['baseline']}, score {result['score']}")
            cell_new = dict(cell_def)
            cell_new["score"] = result["score"]
            cell_new["out_json"] = result["out_json"]
            cell_new["baseline_pytest"] = result["baseline"]
            agg.append(cell_new)
        except Exception as ex:
            print(f"  FAIL: {ex}")

    AGG_FILE.write_text(json.dumps(agg, indent=2), encoding="utf-8")
    print(f"\n=== Aggregate updated: {AGG_FILE} ===")
    print(f"\n{'Model':<25} {'Level':<5} {'TVR':>8} {'Score':>15}")
    print("-" * 60)
    for c in agg:
        s = c.get("score")
        sc = f"{s['killed']}/{s['applied']}={s['pct']:.1f}%" if s else "?"
        tvr = c.get("baseline_tvr", "-")
        tvr_s = f"{tvr}%" if isinstance(tvr, (int, float)) else "-"
        print(f"{c.get('model','?'):<25} {c.get('level','?'):<5} {tvr_s:>8} {sc:>15}")


if __name__ == "__main__":
    main()
