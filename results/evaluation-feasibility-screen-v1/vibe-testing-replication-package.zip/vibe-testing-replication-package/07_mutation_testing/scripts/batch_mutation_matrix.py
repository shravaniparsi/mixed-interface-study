"""Batch driver that builds the full multi-suite mutation matrix."""
import json
import subprocess
import sys
from pathlib import Path

REPO = Path("<RUN_HOST>")
PILOT = REPO / "v_temp" / "mutation_pilot.py"
RESULTS_DIR = REPO / "results"
OUT_FILE = RESULTS_DIR / "mutation_matrix_aggregate.json"

SOURCES = [
    ("Claude Haiku 4.5",
     REPO / "v12" / "outputs_v12_claude" / "results" / "experiment_v12_20260424_160040.json",
     "claude-haiku-4-5-20251001", ["L0", "L1", "L2", "L3"]),
    ("DeepSeek-Chat",
     REPO / "v12" / "outputs_v12_deepseek-chat" / "results" / "experiment_v12_20260415_165515.json",
     "deepseek-chat", ["L0", "L1", "L2", "L3", "L4"]),
    ("DeepSeek-V4",
     REPO / "v12" / "outputs_v12_deepseek-v4" / "results" / "experiment_v12_20260426_220445.json",
     "deepseek-v4", ["L0", "L1", "L2", "L3", "L4"]),
    ("Mistral Large 2411",
     REPO / "v12" / "outputs_v12_mistral" / "results" / "experiment_v12_20260415_220449.json",
     "mistral-large", ["L0", "L1", "L2", "L3", "L4"]),
    ("Gemini 3.1 Flash Lite",
     REPO / "v12" / "outputs_v12_gemini" / "results" / "experiment_v12_20260416_073106.json",
     "gemini", ["L0", "L1", "L2", "L3", "L4"]),
    ("Qwen 2.5-coder 32b",
     None,
     "qwen2.5-coder", ["L1", "L2"]),
]


def find_results_json_for_model(model_substr):
    candidates = []
    for v12dir in (REPO / "v12").glob("outputs_v12_*/results/*.json"):
        try:
            data = json.load(open(v12dir, encoding="utf-8"))
            if isinstance(data, list) and data:
                if model_substr.lower() in (data[0].get("llm","") + "").lower():
                    candidates.append(v12dir)
        except Exception:
            pass
    for r in (REPO / "results").glob("*.json"):
        try:
            data = json.load(open(r, encoding="utf-8"))
            if isinstance(data, list) and data:
                if model_substr.lower() in (data[0].get("llm","") + "").lower():
                    candidates.append(r)
        except Exception:
            pass
    return candidates


def find_best_run(json_path, level, target_temp=0.4):
    runs = json.load(open(json_path, encoding="utf-8"))
    cands = [r for r in runs if r.get("level")==level
             and abs(r.get("temperature",-99) - target_temp) < 0.01
             and "metrics" in r]
    if not cands:
        return None, None
    cands.sort(key=lambda r: r.get("metrics",{}).get("test_validity",{}).get("validity_rate_pct",0),
               reverse=True)
    best = cands[0]
    fname = best.get("output_filename")
    tvr = best.get("metrics",{}).get("test_validity",{}).get("validity_rate_pct",0)
    json_dir = Path(json_path).parent.parent
    candidate_paths = [
        json_dir / fname,
        REPO / "outputs" / fname,
        REPO / "outputs" / fname.replace(":", "_"),
    ]
    for p in candidate_paths:
        if p.exists():
            return str(p), tvr
    short = fname.split("__")[0].replace(":", "_")
    glob_pat = f"test_*{short}*{level}*t0_4*.py"
    for d in [REPO / "outputs", json_dir]:
        for f in d.glob(glob_pat):
            return str(f), tvr
    return None, tvr


def run_pilot(test_file, max_mutations=15, timeout=600):
    proc = subprocess.run(
        [sys.executable, str(PILOT),
         "--test-file", str(test_file),
         "--max-mutations", str(max_mutations)],
        cwd="<BOOKSTORE_API>",
        capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    import re
    m = re.search(r"Mutation score:\s*(\d+)/(\d+)\s*=\s*([0-9.]+)%", out)
    score = None
    if m:
        score = {"killed": int(m.group(1)), "applied": int(m.group(2)), "pct": float(m.group(3))}
    m2 = re.search(r"Result saved to:\s*(\S+)", out)
    out_json = m2.group(1) if m2 else None
    return {"score": score, "out_json": out_json, "stdout_tail": out[-500:]}


def main():
    matrix = []
    for label, json_path, model_substr, levels in SOURCES:
        if json_path is None:
            cands = find_results_json_for_model(model_substr)
            if not cands:
                print(f"[{label}] no result JSON found, skipping all levels")
                continue
            v12_cands = [c for c in cands if "v12" in str(c)]
            json_path = v12_cands[0] if v12_cands else cands[0]
        print(f"\n=== {label} (data: {Path(json_path).name}) ===")
        for level in levels:
            best_file, tvr = find_best_run(json_path, level)
            if not best_file:
                print(f"  [{level}] best file not found - skip")
                matrix.append({"model": label, "level": level, "status": "no_file"})
                continue
            print(f"  [{level}] best run TVR={tvr}% file={Path(best_file).name}")
            print(f"    running mutation_pilot.py ...", flush=True)
            try:
                result = run_pilot(best_file)
                print(f"    -> {result['score']}")
                matrix.append({
                    "model": label, "level": level, "temperature": 0.4,
                    "test_file": best_file, "baseline_tvr": tvr,
                    "score": result["score"], "out_json": result["out_json"],
                })
            except Exception as ex:
                print(f"    FAIL: {ex}")
                matrix.append({"model": label, "level": level, "status": "error",
                               "error": str(ex)})

    OUT_FILE.write_text(json.dumps(matrix, indent=2), encoding="utf-8")
    print(f"\n=== Aggregate saved: {OUT_FILE} ===")
    print(f"\n{'Model':<22} {'Level':<5} {'Baseline TVR':>12} {'Mutation score':>15}")
    print("-" * 60)
    for m in matrix:
        s = m.get("score")
        score_str = f"{s['killed']}/{s['applied']} = {s['pct']:.1f}%" if s else m.get("status","?")
        tvr = m.get("baseline_tvr")
        tvr_str = f"{tvr}%" if tvr is not None else "-"
        print(f"{m.get('model','?'):<22} {m.get('level','?'):<5} {tvr_str:>12} {score_str:>15}")


if __name__ == "__main__":
    main()
