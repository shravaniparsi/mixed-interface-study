"""Worker process that applies one mutant to an isolated API copy and runs a suite against it."""
import argparse, json, os, re, subprocess, sys, time, urllib.request, urllib.error
from pathlib import Path

ROOT = Path(__file__).parent.parent
V12 = ROOT / "v_temp" / "student_zip" / "vibe-testing-framework-main" / "v12"
OUT_DIR = ROOT / "v_temp" / "mutation_multisuite"
OUT_DIR.mkdir(exist_ok=True)
PYEXE = sys.executable

MUTATIONS = [
    ("EQ_TO_NE", r"\b==\b", "!="),
    ("LT_TO_LE", r"(?<![<=!])<(?!=)", "<="),
    ("GT_TO_GE", r"(?<![>=!])>(?!=)", ">="),
    ("PLUS_TO_MINUS", r"(?<![+\-=*/])\+(?![+=])", "-"),
    ("AND_TO_OR", r"\band\b", "or"),
    ("OR_TO_AND", r"\bor\b", "and"),
    ("TRUE_TO_FALSE", r"\bTrue\b", "False"),
    ("FALSE_TO_TRUE", r"\bFalse\b", "True"),
    ("ZERO_TO_ONE", r"(?<![\w.])0(?![\w.])", "1"),
    ("ONE_TO_TWO", r"(?<![\w.])1(?![\w.])", "2"),
    ("RAISE_TO_PASS", r"raise\s+HTTPException", "pass  # mutated"),
    ("STATUS_400_TO_500", r"status_code=400", "status_code=500"),
    ("STATUS_404_TO_200", r"status_code=404", "status_code=200"),
    ("STATUS_409_TO_200", r"status_code=409", "status_code=200"),
    ("RETURN_NONE", r"return\s+\w+", "return None"),
]

MODEL_DIRS = {
    "Claude Haiku 4.5":      "outputs_v12_claude",
    "DeepSeek-Chat":         "outputs_v12_deepseek-chat",
    "DeepSeek-V4-Flash":     "outputs_v12_deepseek-v4",
    "Gemini 3.1 Flash Lite": "outputs_v12_gemini",
    "Mistral Large 3":       "outputs_v12_mistral",
}


def make_worker(bookstore: Path, port: int, wid: int):
    crud = bookstore / "app" / "crud.py"
    worker_test = bookstore / "_worker_test.py"
    logf = ROOT / "v_temp" / f"mutation_worker{wid}.log"
    pristine = bookstore / "app" / "crud.pristine.py"
    if not pristine.exists():
        pristine.write_text(crud.read_text(encoding="utf-8"), encoding="utf-8")
    crud.write_text(pristine.read_text(encoding="utf-8"), encoding="utf-8")

    def log(m):
        with open(logf, "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%H:%M:%S')}] {m}\n")

    def start_uv():
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        p = subprocess.Popen(
            [PYEXE, "-m", "uvicorn", "app.main:app", "--host", "::1",
             "--port", str(port), "--log-level", "critical"],
            cwd=str(bookstore), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        for _ in range(40):
            try:
                urllib.request.urlopen(f"http://localhost:{port}/openapi.json", timeout=1)
                return p
            except (urllib.error.URLError, ConnectionResetError, ConnectionError):
                time.sleep(0.5)
        p.kill()
        raise RuntimeError("uvicorn no-start")

    def stop_uv(p):
        if p and p.poll() is None:
            try:
                p.terminate(); p.wait(timeout=5)
            except Exception:
                p.kill()

    def reset():
        try:
            urllib.request.urlopen(
                urllib.request.Request(f"http://localhost:{port}/reset", method="POST"), timeout=10)
        except Exception:
            pass

    def pytest_run(timeout=300):
        r = subprocess.run(
            [PYEXE, "-m", "pytest", str(worker_test), "--tb=no", "-q",
             "-p", "no:cacheprovider", "--timeout=15", "--timeout-method=thread"],
            cwd=str(bookstore), capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "") + "\n" + (r.stderr or "")
        gp = lambda pat: (int(re.search(pat, out).group(1)) if re.search(pat, out) else 0)
        return gp(r"(\d+)\s+passed"), gp(r"(\d+)\s+failed"), gp(r"(\d+)\s+error")

    def run_one(src_test: Path):
        txt = src_test.read_text(encoding="utf-8", errors="ignore")
        txt = re.sub(r"(localhost|127\.0\.0\.1):8000", f"localhost:{port}", txt)
        worker_test.write_text(txt, encoding="utf-8")
        original = pristine.read_text(encoding="utf-8")
        crud.write_text(original, encoding="utf-8")
        try:
            p = start_uv(); reset()
            try:
                p0, f0, e0 = pytest_run()
            finally:
                stop_uv(p)
            total = p0 + f0 + e0
            if p0 == 0 or total <= 1:
                return {"baseline": {"passed": p0, "failed": f0, "errored": e0},
                        "baseline_tvr": round(100*p0/total, 2) if total else 0.0,
                        "mutations": [], "status": "degenerate_baseline"}
            results = []
            for name, pat, rep in MUTATIONS:
                new, n = re.subn(pat, rep, original, count=1)
                if n == 0:
                    results.append({"name": name, "applied": False}); continue
                crud.write_text(new, encoding="utf-8")
                try:
                    p = start_uv(); reset()
                    pp, ff, ee = pytest_run()
                    stop_uv(p)
                except Exception as ex:
                    results.append({"name": name, "applied": True, "error": str(ex)}); continue
                finally:
                    crud.write_text(original, encoding="utf-8")
                killed = (pp < p0) or (ff > f0) or (ee > e0)
                results.append({"name": name, "applied": True, "killed": killed,
                                "passed": pp, "failed": ff, "errored": ee, "baseline_passed": p0})
            applied = [r for r in results if r.get("applied") and "killed" in r]
            killed = [r for r in applied if r["killed"]]
            return {"baseline": {"passed": p0, "failed": f0, "errored": e0},
                    "baseline_tvr": round(100*p0/total, 2),
                    "score": {"killed": len(killed), "applied": len(applied),
                              "pct": round(100*len(killed)/len(applied), 1) if applied else 0.0},
                    "mutations": results}
        finally:
            crud.write_text(original, encoding="utf-8")

    return run_one, log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, required=True)
    ap.add_argument("--total", type=int, required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--bookstore", required=True)
    args = ap.parse_args()

    run_one, log = make_worker(Path(args.bookstore), args.port, args.worker)
    all_files = []
    for model, dirn in MODEL_DIRS.items():
        for f in sorted((V12 / dirn).glob("test_generated_*__bookstore__L*__run*__t0_4.py")):
            m = re.search(r"__(L\d)__run(\d)__", f.name)
            if m:
                all_files.append((model, m.group(1), int(m.group(2)), f))
    mine = [x for i, x in enumerate(all_files) if i % args.total == args.worker]
    log(f"WORKER {args.worker} start: {len(mine)} files, port {args.port}")
    for model, level, run, f in mine:
        slug = f"{MODEL_DIRS[model]}__{level}__run{run}"
        out = OUT_DIR / f"{slug}.json"
        if out.exists():
            continue
        t0 = time.time()
        try:
            res = run_one(f)
        except Exception as ex:
            res = {"status": "error", "error": str(ex)}
        res.update({"model": model, "level": level, "run": run, "test_file": f.name})
        out.write_text(json.dumps(res, indent=2), encoding="utf-8")
        log(f"{slug} -> {res.get('score', res.get('status'))} btvr={res.get('baseline_tvr')} ({time.time()-t0:.0f}s)")
    log(f"WORKER {args.worker} DONE")


if __name__ == "__main__":
    main()
