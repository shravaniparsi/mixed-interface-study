"""Bootstrap confidence interval for the TVR minus mutation-score gap."""
import json
import numpy as np
from pathlib import Path

ROOT = Path(__file__).parent.parent
agg = json.load(open(ROOT / "results/mutation_matrix_aggregate.json", encoding="utf-8"))

gaps = []
for c in agg:
    s = c.get("score")
    tvr = c.get("baseline_tvr_pct") or c.get("tvr") or c.get("baseline_tvr")
    if s and isinstance(s.get("pct"), (int, float)) and tvr is not None:
        gap = float(tvr) - float(s["pct"])
        gaps.append(gap)

print(f"Cells with both TVR and MS: {len(gaps)}")
print(f"Mean gap: {np.mean(gaps):.2f} pp, Median: {np.median(gaps):.2f} pp")
print(f"Std: {np.std(gaps, ddof=1):.2f}")
print(f"Range: {min(gaps):.2f} – {max(gaps):.2f}")

rng = np.random.default_rng(42)
boot = []
for _ in range(10000):
    sample = rng.choice(gaps, size=len(gaps), replace=True)
    boot.append(np.mean(sample))
boot = np.array(boot)
print(f"Bootstrap 95% CI for mean gap: [{np.percentile(boot, 2.5):.2f}, {np.percentile(boot, 97.5):.2f}]")
print(f"Bootstrap 95% CI for median gap: [", end="")
boot_med = [np.median(rng.choice(gaps, size=len(gaps), replace=True)) for _ in range(10000)]
print(f"{np.percentile(boot_med, 2.5):.2f}, {np.percentile(boot_med, 97.5):.2f}]")
