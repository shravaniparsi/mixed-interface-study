"""Local driver that scores every generated suite against all mutants using isolated copies of the API."""
import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

BOOKSTORE = Path(r"<BOOKSTORE_API>")
CRUD = BOOKSTORE / "app" / "crud.py"
PORT = 8000
PYEXE = sys.executable

MUTATIONS = [
    ("EQ_TO_NE", r"\b==\b", "!="),
    ("LT_TO_LE", r"(?<![<=!])<(?!=)", "<="),
    ("GT_TO_GE", r"(?<![>=!])>(?!=)", ">="),
    ("PLUS_TO_MINUS", r"(?<![+\-=*/])\+(?![+=])", "-"),
    ("AND_TO_OR", r"\band\b", "or"),
    ("OR_TO_AND", r"\bor\b", "and"),
    ("TRUE_TO_FALSE", r"\bTrue\b", "False"),
    ("FALSE_TO_TRUE", r"\bFalse\b", "True"),
    ("ZERO_TO_ONE", r"(?<![\w.])0(?![\w.])", "1"),
    ("ONE_TO_TWO", r"(?<![\w.])1(?![\w.])", "2"),
    ("RAISE_TO_PASS", r"raise\s+HTTPException", "pass  # mutated"),
    ("STATUS_400_TO_500", r"status_code=400", "status_code=500"),
    ("STATUS_404_TO_200", r"status_code=404", "status_code=200"),
    ("STATUS_409_TO_200", r"status_code=409", "status_code=200"),
    ("RETURN_NONE", r"return\s+\w+", "return None"),
]


def start_uvicorn():
    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    proc = subprocess.Popen(
        [PYEXE, "-m", "uvicorn", "app.main:app", "--host", "::1",
         "--port", str(PORT), "--log-level", "critical"],
        cwd=str(BOOKSTORE),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        **kwargs,
    )
    for _ in range(40):
        try:
            urllib.request.urlopen(f"http://localhost:{PORT}/openapi.json", timeout=1)
            return proc
        except (urllib.error.URLError, ConnectionResetError, ConnectionError):
            time.sleep(0.5)
    proc.kill()
    raise RuntimeError("uvicorn did not start within 20s")


def stop_uvicorn(proc):
    if proc and proc.poll() is None:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


def reset_db():
    try:
        req = urllib.request.Request(f"http://localhost:{PORT}/reset", method="POST")
        urllib.request.urlopen(req, timeout=10)
        return True
    except Exception:
        return False


def run_pytest(test_file: Path, timeout=300):
    proc = subprocess.run(
        [PYEXE, "-m", "pytest", str(test_file), "--tb=no", "-q", "-p", "no:cacheprovider",
         "--timeout=15", "--timeout-method=thread"],
        cwd=str(BOOKSTORE), capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    m_pass = re.search(r"(\d+)\s+passed", out)
    m_fail = re.search(r"(\d+)\s+failed", out)
    m_err  = re.search(r"(\d+)\s+error", out)
    p = int(m_pass.group(1)) if m_pass else 0
    f = int(m_fail.group(1)) if m_fail else 0
    e = int(m_err.group(1))  if m_err  else 0
    return p, f, e


def run_one(test_file: Path, max_mutations=15, verbose=True):
    test_file = Path(test_file).resolve()
    original = CRUD.read_text(encoding="utf-8")
    proc = start_uvicorn(); reset_db()
    p0, f0, e0 = run_pytest(test_file)
    stop_uvicorn(proc)
    total = p0 + f0 + e0
    if verbose:
        print(f"  baseline: passed={p0} failed={f0} err={e0} total={total}")
    if p0 == 0 or total <= 1:
        return {"baseline": {"passed": p0, "failed": f0, "errored": e0},
                "baseline_tvr": round(100*p0/total, 2) if total else 0.0,
                "mutations": [], "status": "degenerate_baseline"}

    results = []
    for name, pattern, replacement in MUTATIONS[:max_mutations]:
        new_text, n = re.subn(pattern, replacement, original, count=1)
        if n == 0:
            results.append({"name": name, "applied": False})
            continue
        CRUD.write_text(new_text, encoding="utf-8")
        try:
            proc = start_uvicorn(); reset_db()
            p, f, e = run_pytest(test_file)
            stop_uvicorn(proc)
        except Exception as ex:
            CRUD.write_text(original, encoding="utf-8")
            results.append({"name": name, "applied": True, "error": str(ex)})
            continue
        killed = (p < p0) or (f > f0) or (e > e0)
        results.append({"name": name, "applied": True, "killed": killed,
                        "passed": p, "failed": f, "errored": e,
                        "baseline_passed": p0})
    CRUD.write_text(original, encoding="utf-8")

    applied = [r for r in results if r.get("applied") and "killed" in r]
    killed = [r for r in applied if r["killed"]]
    score = {"killed": len(killed), "applied": len(applied),
             "pct": round(100*len(killed)/len(applied), 1) if applied else 0.0}
    return {"baseline": {"passed": p0, "failed": f0, "errored": e0},
            "baseline_tvr": round(100*p0/total, 2),
            "score": score, "mutations": results}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-file", required=True)
    ap.add_argument("--max-mutations", type=int, default=15)
    args = ap.parse_args()
    t0 = time.time()
    res = run_one(Path(args.test_file), args.max_mutations)
    dt = time.time() - t0
    print(json.dumps(res.get("score", res.get("status")), indent=2))
    print(f"baseline_tvr={res.get('baseline_tvr')}  elapsed={dt:.1f}s")
