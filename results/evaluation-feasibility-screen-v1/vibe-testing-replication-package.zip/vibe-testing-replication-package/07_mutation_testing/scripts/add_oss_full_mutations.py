"""Add the open-weight L0-L4 cells to the mutation matrix."""
import json
import subprocess
import sys
import glob
from pathlib import Path

REPO = Path("<RUN_HOST>")
PILOT = REPO / "v_temp" / "mutation_pilot.py"
AGG_FILE = REPO / "results" / "mutation_matrix_aggregate.json"

CELLS_TO_ADD = [
    ("Qwen 2.5-coder 32b",
     REPO / "results" / "experiment_qwen_L0_L4_20260506_100101.json",
     ["L0", "L4"]),
    ("DeepSeek-R1 32b",
     REPO / "results" / "experiment_deepseek_r1_multi_L_20260506_111907.json",
     ["L0", "L2", "L3", "L4"]),
    ("Gemma4 31b",
     REPO / "results" / "experiment_gemma_multi_L_20260506_192416.json",
     ["L0", "L2", "L3", "L4"]),
]


def find_best_run(json_path, level, target_temp=0.4):
    runs = json.load(open(json_path, encoding="utf-8"))
    cands = [r for r in runs if r.get("level") == level
             and abs(r.get("temperature", -99) - target_temp) < 0.01
             and "metrics" in r]
    if not cands:
        return None, None
    cands.sort(key=lambda r: r.get("metrics", {}).get("test_validity", {}).get("validity_rate_pct", 0),
               reverse=True)
    best = cands[0]
    fname = best.get("output_filename")
    tvr = best.get("metrics", {}).get("test_validity", {}).get("validity_rate_pct", 0)
    candidate_paths = [
        REPO / "outputs" / fname,
        REPO / "outputs" / fname.replace(":", "_"),
    ]
    for p in candidate_paths:
        if p.exists():
            return str(p), tvr
    short = fname.split("__")[0].replace(":", "_")
    for f in (REPO / "outputs").glob(f"test_*{short}*{level}*t0_4*.py"):
        return str(f), tvr
    return None, tvr


def run_pilot(test_file, max_mutations=15, timeout=600):
    proc = subprocess.run(
        [sys.executable, str(PILOT),
         "--test-file", str(test_file),
         "--max-mutations", str(max_mutations)],
        cwd="<BOOKSTORE_API>",
        capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    import re
    m = re.search(r"Mutation score:\s*(\d+)/(\d+)\s*=\s*([0-9.]+)%", out)
    score = None
    if m:
        score = {"killed": int(m.group(1)), "applied": int(m.group(2)), "pct": float(m.group(3))}
    m2 = re.search(r"Result saved to:\s*(\S+)", out)
    out_json = m2.group(1) if m2 else None
    m3 = re.search(r"BASELINE.*?passed=(\d+).*?failed=(\d+).*?errored=(\d+).*?total=(\d+)", out, re.DOTALL)
    baseline_meta = None
    if m3:
        baseline_meta = {"p": int(m3.group(1)), "f": int(m3.group(2)),
                         "e": int(m3.group(3)), "total": int(m3.group(4))}
    return {"score": score, "out_json": out_json, "baseline": baseline_meta}


def main():
    agg = json.load(open(AGG_FILE, encoding="utf-8"))

    for model_label, json_path, levels in CELLS_TO_ADD:
        print(f"\n=== {model_label} (data: {Path(json_path).name}) ===")
        for level in levels:
            existing = next((c for c in agg
                             if c.get("model") == model_label and c.get("level") == level
                             and abs(c.get("temperature", -1) - 0.4) < 0.01), None)
            if existing and existing.get("score"):
                print(f"  [SKIP] {level} already in aggregate")
                continue

            best_file, tvr = find_best_run(json_path, level)
            if not best_file:
                print(f"  [{level}] best file not found - skip")
                agg.append({"model": model_label, "level": level, "temperature": 0.4,
                            "status": "no_file"})
                continue

            print(f"  [{level}] best run TVR={tvr}% file={Path(best_file).name}")
            try:
                result = run_pilot(best_file)
                print(f"    -> baseline {result['baseline']}, score {result['score']}")
                agg.append({
                    "model": model_label, "level": level, "temperature": 0.4,
                    "test_file": best_file, "baseline_tvr": tvr,
                    "score": result["score"], "out_json": result["out_json"],
                    "baseline_pytest": result["baseline"],
                })
            except Exception as ex:
                print(f"    FAIL: {ex}")
                agg.append({"model": model_label, "level": level, "temperature": 0.4,
                            "status": "error", "error": str(ex)})

    AGG_FILE.write_text(json.dumps(agg, indent=2), encoding="utf-8")
    print(f"\n=== Aggregate updated: {AGG_FILE} ===")
    print(f"\n{'Model':<25} {'Level':<5} {'TVR':>8} {'Score':>15}")
    print("-" * 60)
    for c in agg:
        s = c.get("score")
        sc = f"{s['killed']}/{s['applied']}={s['pct']:.1f}%" if s else c.get("status", "?")
        tvr = c.get("baseline_tvr", "-")
        tvr_s = f"{tvr}%" if isinstance(tvr, (int, float)) else "-"
        print(f"{c.get('model','?'):<25} {c.get('level','?'):<5} {tvr_s:>8} {sc:>15}")


if __name__ == "__main__":
    main()
