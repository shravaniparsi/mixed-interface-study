"""Re-run mutation scoring for cells flagged as anomalous."""
import json
import subprocess
import sys
from pathlib import Path

REPO = Path("<RUN_HOST>")
PILOT = REPO / "v_temp" / "mutation_pilot.py"
AGG_FILE = REPO / "results" / "mutation_matrix_aggregate.json"

AFFECTED = [
    ("DeepSeek-Chat", "L0"),
    ("Mistral Large 2411", "L2"),
    ("Mistral Large 2411", "L3"),
    ("Mistral Large 2411", "L4"),
    ("Gemini 3.1 Flash Lite", "L0"),
    ("Gemini 3.1 Flash Lite", "L4"),
    ("Qwen 2.5-coder 32b", "L2"),
]

QWEN_L1_FILE = REPO / "outputs" / "test_generated_qwen2_5-coder_32b-fast__bookstore__L1__run1__t0_4.py"


def run_pilot(test_file, max_mutations=15, timeout=600):
    proc = subprocess.run(
        [sys.executable, str(PILOT),
         "--test-file", str(test_file),
         "--max-mutations", str(max_mutations)],
        cwd="<BOOKSTORE_API>",
        capture_output=True, text=True, timeout=timeout,
    )
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    import re
    m = re.search(r"Mutation score:\s*(\d+)/(\d+)\s*=\s*([0-9.]+)%", out)
    score = None
    if m:
        score = {"killed": int(m.group(1)), "applied": int(m.group(2)), "pct": float(m.group(3))}
    m2 = re.search(r"Result saved to:\s*(\S+)", out)
    out_json = m2.group(1) if m2 else None
    m3 = re.search(r"BASELINE.*?passed=(\d+).*?failed=(\d+).*?errored=(\d+).*?total=(\d+)", out, re.DOTALL)
    baseline_meta = None
    if m3:
        baseline_meta = {"p": int(m3.group(1)), "f": int(m3.group(2)),
                         "e": int(m3.group(3)), "total": int(m3.group(4))}
    return {"score": score, "out_json": out_json, "baseline": baseline_meta, "stdout_tail": out[-500:]}


def main():
    agg = json.load(open(AGG_FILE, encoding="utf-8"))
    updated = []
    for cell in agg:
        match = (cell.get("model"), cell.get("level"))
        if match in AFFECTED:
            test_file = cell.get("test_file")
            if not test_file or not Path(test_file).exists():
                print(f"[{match}] file missing: {test_file}")
                updated.append(cell); continue
            print(f"\n=== RE-RUN [{match}] ===")
            print(f"  file: {Path(test_file).name}")
            try:
                result = run_pilot(test_file)
                print(f"  -> baseline {result['baseline']}, score {result['score']}")
                cell_new = dict(cell)
                cell_new["score"] = result["score"]
                cell_new["out_json"] = result["out_json"]
                cell_new["baseline_pytest"] = result["baseline"]
                cell_new["rerun_reason"] = "fixed_pytest_x_flag"
                updated.append(cell_new)
            except Exception as ex:
                print(f"  FAIL: {ex}")
                updated.append(cell)
        else:
            updated.append(cell)

    if QWEN_L1_FILE.exists():
        print(f"\n=== ADD Qwen L1 (file: {QWEN_L1_FILE.name}) ===")
        try:
            result = run_pilot(QWEN_L1_FILE)
            print(f"  -> baseline {result['baseline']}, score {result['score']}")
            updated.append({
                "model": "Qwen 2.5-coder 32b", "level": "L1", "temperature": 0.4,
                "test_file": str(QWEN_L1_FILE),
                "score": result["score"], "out_json": result["out_json"],
                "baseline_pytest": result["baseline"],
                "rerun_reason": "added_after_no_file",
            })
        except Exception as ex:
            print(f"  FAIL: {ex}")
    else:
        print(f"Qwen L1 file not found: {QWEN_L1_FILE}")

    AGG_FILE.write_text(json.dumps(updated, indent=2), encoding="utf-8")
    print(f"\n=== Aggregate updated: {AGG_FILE} ===")
    print(f"\n{'Model':<22} {'Level':<5} {'TVR':>8} {'Score':>15}")
    print("-" * 60)
    for c in updated:
        s = c.get("score")
        sc = f"{s['killed']}/{s['applied']}={s['pct']:.1f}%" if s else "?"
        tvr = c.get("baseline_tvr","-")
        tvr_s = f"{tvr}%" if isinstance(tvr,(int,float)) else "-"
        print(f"{c.get('model','?'):<22} {c.get('level','?'):<5} {tvr_s:>8} {sc:>15}")


if __name__ == "__main__":
    main()
