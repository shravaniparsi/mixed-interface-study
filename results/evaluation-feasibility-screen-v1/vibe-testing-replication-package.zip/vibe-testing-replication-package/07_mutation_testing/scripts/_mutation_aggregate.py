"""Aggregate the per-suite mutation results into the per (model, level) mutation matrix."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np

ROOT = Path(__file__).parent.parent
MS_DIR = ROOT / "v_temp" / "mutation_multisuite"
OLD = ROOT / "results" / "mutation_matrix_aggregate.json"
OUT = ROOT / "results" / "mutation_matrix_multisuite.json"
LEVELS = ["L0", "L1", "L2", "L3", "L4"]
CLOUD = ["Claude Haiku 4.5", "DeepSeek-V4-Flash", "DeepSeek-Chat",
         "Mistral Large 3", "Gemini 3.1 Flash Lite"]

runs = defaultdict(list)
nfiles = 0
for jf in sorted(MS_DIR.glob("*.json")):
    d = json.load(open(jf, encoding="utf-8"))
    nfiles += 1
    runs[(d["model"], d["level"])].append(d)
print(f"Loaded {nfiles} per-run mutation files")

cells = {}
gap_runs = []
for (model, level), rs in runs.items():
    scores = [r["score"]["pct"] for r in rs if r.get("score")]
    btvrs = [r.get("baseline_tvr") for r in rs if r.get("score") and r.get("baseline_tvr") is not None]
    degen = [r for r in rs if r.get("status") == "degenerate_baseline"]
    if scores:
        cells[(model, level)] = {
            "n_runs": len(scores), "ms_mean": float(np.mean(scores)),
            "ms_sd": float(np.std(scores, ddof=1)) if len(scores) > 1 else 0.0,
            "ms_min": float(min(scores)), "ms_max": float(max(scores)),
            "btvr_mean": float(np.mean(btvrs)) if btvrs else None,
            "n_degenerate": len(degen),
        }
        for r in rs:
            if r.get("score") and r.get("baseline_tvr") is not None:
                gap_runs.append((r["baseline_tvr"], r["score"]["pct"]))

print("\n=== Table 8 (multi-suite): mutation score mean +- SD per cell ===")
print(f"{'Model':<24}" + "".join(f"{L:<14}" for L in LEVELS) + "Mean")
table8 = {}
for m in CLOUD:
    cellstrs, means = [], []
    for L in LEVELS:
        c = cells.get((m, L))
        if c:
            cellstrs.append(f"{c['ms_mean']:.1f}±{c['ms_sd']:.1f}")
            means.append(c['ms_mean'])
            table8[(m, L)] = c
        else:
            cellstrs.append("n/a")
    rowmean = f"{np.mean(means):.1f}" if means else "n/a"
    print(f"{m:<24}" + "".join(f"{s:<14}" for s in cellstrs) + rowmean)

old = json.load(open(OLD, encoding="utf-8"))
NAME_FIX = {"DeepSeek-V4": "DeepSeek-V4-Flash", "Mistral Large 2411": "Mistral Large 3",
            "Qwen 2.5-coder 32b": "Qwen 2.5-Coder 32B", "DeepSeek-R1 32b": "DeepSeek-R1 32B",
            "Gemma4 31b": "Gemma4 31B"}
oss_cells = {}
for c in old:
    m = NAME_FIX.get(c.get("model"), c.get("model"))
    if m in ("Qwen 2.5-Coder 32B", "DeepSeek-R1 32B", "Gemma4 31B"):
        s = c.get("score")
        if s and isinstance(s.get("pct"), (int, float)):
            oss_cells[(m, c["level"])] = {"ms_mean": float(s["pct"]), "ms_sd": 0.0,
                                          "n_runs": 1, "btvr_mean": c.get("baseline_tvr"),
                                          "single_suite": True}
print("\n=== open-weight (single-suite, from prior matrix) ===")
for m in ["Qwen 2.5-Coder 32B", "DeepSeek-R1 32B", "Gemma4 31B"]:
    cs = [f"{oss_cells[(m,L)]['ms_mean']:.1f}" if (m,L) in oss_cells else "n/a" for L in LEVELS]
    print(f"{m:<24}" + "".join(f"{c:<8}" for c in cs))

print("\n=== Figure 7 (per-model mean across levels) ===")
fig7 = {}
for m in CLOUD:
    vals = [cells[(m, L)]["ms_mean"] for L in LEVELS if (m, L) in cells]
    if vals:
        fig7[m] = (float(np.mean(vals)), float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0)
for m in ["Qwen 2.5-Coder 32B", "DeepSeek-R1 32B", "Gemma4 31B"]:
    vals = [oss_cells[(m, L)]["ms_mean"] for L in LEVELS if (m, L) in oss_cells]
    if vals:
        fig7[m] = (float(np.mean(vals)), float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0)
for m, (mean, sd) in sorted(fig7.items(), key=lambda x: -x[1][0]):
    print(f"  {m:<24} {mean:5.1f} +- {sd:4.1f}")

print("\n=== TVR-MS gap (multi-suite, all cloud runs) ===")
gaps = [tvr - ms for tvr, ms in gap_runs]
print(f"N run-pairs: {len(gaps)}")
ci_lo = ci_hi = None
if gaps:
    print(f"mean gap = {np.mean(gaps):.2f} pp, median = {np.median(gaps):.2f} pp, sd = {np.std(gaps, ddof=1):.2f}")
    rng = np.random.default_rng(42)
    boot = [np.mean(rng.choice(gaps, len(gaps), replace=True)) for _ in range(10000)]
    ci_lo, ci_hi = round(float(np.percentile(boot, 2.5)), 2), round(float(np.percentile(boot, 97.5)), 2)
    print(f"bootstrap 95% CI mean gap: [{ci_lo}, {ci_hi}] pp")

out = {
    "cloud_cells": {f"{m}::{L}": cells[(m, L)] for (m, L) in cells},
    "oss_cells": {f"{m}::{L}": oss_cells[(m, L)] for (m, L) in oss_cells},
    "fig7_per_model": {m: {"mean": v[0], "sd": v[1]} for m, v in fig7.items()},
    "gap": {"n": len(gaps), "mean": round(float(np.mean(gaps)), 2) if gaps else None,
            "median": round(float(np.median(gaps)), 2) if gaps else None,
            "ci_lo": ci_lo, "ci_hi": ci_hi},
    "n_files": nfiles,
}
OUT.write_text(json.dumps(out, indent=2), encoding="utf-8")
print(f"\nSaved -> {OUT}")
