# Statistical validation

* `scripts/stats_validation.py` — Friedman tests + Kendall W, Holm step-down,
  Wilcoxon signed-rank (rank-biserial), Mann-Whitney U + Cliff's delta,
  Fisher exact, 10k bootstrap CIs; writes `results/stats_results.md`.
* `scripts/stats_nemenyi.py` — Nemenyi post-hoc pairwise model comparisons;
  writes `results/stats_nemenyi_results.md`.
* `results/fig5_stats.json` — temperature-axis statistics accompanying
  manuscript Fig. 6 (collectable-suite Friedman, cohort Mann-Whitney +
  Cliff's delta, generation-failure counts).
