# Statistical validation — manuscript v7 supporting evidence

## 1. Temperature axis (L1 × 6 temps × 3 runs × 7 models)

### 1.1 Per-cell 95% bootstrap CI on mean validity rate

| Model | t=0.0 | t=0.2 | t=0.4 | t=0.6 | t=0.8 | t=1.0 |
|---|---|---|---|---|---|---|
| Gemini 3.1 Flash Lite | 83.3 [80.0, 90.0] | 91.1 [86.7, 93.3] | 75.6 [40.0, 96.7] | 92.2 [90.0, 93.3] | 90.0 | — |
| DeepSeek-Chat | 100.0 [100.0, 100.0] | 100.0 [100.0, 100.0] | 98.9 [96.7, 100.0] | 100.0 [100.0, 100.0] | 100.0 [100.0, 100.0] | 86.7 [63.3, 100.0] |
| Mistral Large 2512 | 98.9 [96.7, 100.0] | 98.9 [96.7, 100.0] | 100.0 [100.0, 100.0] | 98.9 [96.7, 100.0] | 100.0 [100.0, 100.0] | 76.7 [30.0, 100.0] |
| DeepSeek-V4-Flash | 96.2 [95.2, 96.7] | 95.6 [93.3, 100.0] | 97.8 [96.7, 100.0] | 100.0 [100.0, 100.0] | 71.1 [20.0, 96.7] | 96.7 [96.7, 96.7] |
| Qwen 2.5-coder 32b | 33.3 [33.3, 33.3] | 47.8 [46.7, 50.0] | 28.2 [23.3, 34.5] | 32.6 [26.7, 40.0] | 10.0 [0.0, 23.3] | 32.2 [20.0, 43.3] |
| DeepSeek-R1 32b | 2.2 [0.0, 6.7] | 11.2 [0.0, 26.8] | 29.9 [27.6, 32.1] | 7.1 [0.0, 21.4] | 6.7 [0.0, 16.7] | 32.4 [27.3, 37.5] |
| Gemma4 31b | 0.0 [0.0, 0.0] | 10.7 [0.0, 22.2] | 9.4 [0.0, 20.0] | 8.6 [7.1, 10.0] | 12.1 [0.0, 27.3] | 2.2 [0.0, 6.7] |

### 1.2 Friedman test across models (block=temperature, n=6 temps)

- Models tested (full L1×6 temps available): 6 (DeepSeek-Chat, Mistral Large 2512, DeepSeek-V4-Flash, Qwen 2.5-coder 32b, DeepSeek-R1 32b, Gemma4 31b)
- Friedman χ² = 24.976, p = 0.000141
- Conclusion: Models differ significantly across temperatures (reject H0)

### 1.3 Cloud vs OSS validity gap effect size

- Cloud cohort: n=67 runs, mean TVR = 93.5%, median = 100.0%
- OSS cohort:   n=52 runs, mean TVR = 17.5%, median = 18.3%
- Mann-Whitney U: U = 3441, one-sided p = 1.38e-20
- Cliff's δ = 0.975  (large effect; cloud > OSS)

## 2. Mutation matrix (model × level × t=0.4)

### 2.1 Friedman test across models (block=level, n=5 levels)

- Models with full L0-L4 mutation data: 5 (DeepSeek-Chat, DeepSeek-V4, Mistral Large 2411, Gemini 3.1 Flash Lite, Gemma4 31b)
- Friedman χ² = 12.043, p = 0.017031
- Conclusion: Models differ significantly in detection capability (reject H0)

### 2.2 Per-model mutation score summary

| Model | L0 | L1 | L2 | L3 | L4 | Mean |
|---|---|---|---|---|---|---|
| Claude Haiku 4.5 | 30.8 | 38.5 | 46.2 | 53.8 | — | 42.3 |
| DeepSeek-Chat | 23.1 | 53.8 | 53.8 | 46.2 | 46.2 | 44.6 |
| DeepSeek-V4 | 30.8 | 30.8 | 30.8 | 53.8 | 53.8 | 40.0 |
| Mistral Large 2411 | 30.8 | 46.2 | 30.8 | 46.2 | 46.2 | 40.0 |
| Gemini 3.1 Flash Lite | 30.8 | 30.8 | 38.5 | 30.8 | 30.8 | 32.3 |
| Qwen 2.5-coder 32b | 7.7 | 15.4 | 23.1 | — | 23.1 | 17.3 |
| Gemma4 31b | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| DeepSeek-R1 32b | — | 23.1 | — | 7.7 | 0.0 | 10.3 |

## 3. Instruction-Following Compliance (ISBN probe) — Qwen L1 vs L2

- Qwen 2.5-coder 32b L1: 1/18 = 5.6% adherence
- Qwen 2.5-coder 32b L2: 10/18 = 55.6% adherence
- Fisher's exact test (one-sided H1: L1 < L2): odds ratio = 0.0471, p = 0.001364
- Conclusion: L2 significantly improves IFC adherence (p < 0.05)

## 4. TVR-vs-Mutation gap (semantic vs syntactic correctness)

- N = 35 (model, level) cells
- Mean (TVR − mutation score) = 49.3 pp
- Median = 53.8 pp
- Min = 9.0 pp, Max = 73.6 pp
- 95% bootstrap CI on mean gap: [42.9, 55.2] pp

Conclusion: Across the (model, level) matrix, TVR systematically overstates test-suite quality
by an average of 49.3 percentage points. The gap is robust across model families
and context levels — empirical evidence that TVR alone is insufficient as a quality metric.
