# Friedman + Nemenyi post-hoc — pairwise model comparisons

Generated: 2026-05-12

## 1. Temperature axis (n=6 temperatures, models with all temps)

Models: DSChat, Mistral2512, DSV4, ClaudeHaiku, Qwen32b, DSR1_32b, Gemma4_31b

Friedman χ² = 28.825, p = 0.000066

Nemenyi pairwise p-values:

| | DSChat | Mistral2512 | DSV4 | ClaudeHaiku | Qwen32b | DSR1_32b | Gemma4_31b |
|---|---|---|---|---|---|---|---|
| DSChat | — | 0.9968 | 0.9772 | 0.9943 | 0.0512 | 0.0147 | 0.0035 |
| Mistral2512 | 0.9968 | — | 1.0000 | 1.0000 | 0.2256 | 0.0887 | 0.0281 |
| DSV4 | 0.9772 | 1.0000 | — | 1.0000 | 0.3699 | 0.1694 | 0.0619 |
| ClaudeHaiku | 0.9943 | 1.0000 | 1.0000 | — | 0.2578 | 0.1052 | 0.0345 |
| Qwen32b | 0.0512 | 0.2256 | 0.3699 | 0.2578 | — | 0.9997 | 0.9849 |
| DSR1_32b | 0.0147 | 0.0887 | 0.1694 | 0.1052 | 0.9997 | — | 0.9997 |
| Gemma4_31b | 0.0035 | 0.0281 | 0.0619 | 0.0345 | 0.9849 | 0.9997 | — |

**Significant pairs (p < 0.05):**
- DSChat vs DSR1_32b: p = 0.0147
- DSChat vs Gemma4_31b: p = 0.0035
- Mistral2512 vs Gemma4_31b: p = 0.0281
- ClaudeHaiku vs Gemma4_31b: p = 0.0345

## 2. Mutation matrix (n=5 levels, models with full L0-L4)

Models: DeepSeek-Chat, DeepSeek-V4, Mistral Large 2411, Gemini 3.1 Flash Lite, Gemma4 31b

Friedman χ² = 12.043, p = 0.017031

Nemenyi pairwise p-values:

| | DeepSeek-Chat | DeepSeek-V4 | Mistral Large 2411 | Gemini 3.1 Flash Lite | Gemma4 31b |
|---|---|---|---|---|---|
| DeepSeek-Chat | — | 1.0000 | 0.9982 | 0.8970 | 0.0409 |
| DeepSeek-V4 | 1.0000 | — | 0.9982 | 0.8970 | 0.0409 |
| Mistral Large 2411 | 0.9982 | 0.9982 | — | 0.9751 | 0.0906 |
| Gemini 3.1 Flash Lite | 0.8970 | 0.8970 | 0.9751 | — | 0.3172 |
| Gemma4 31b | 0.0409 | 0.0409 | 0.0906 | 0.3172 | — |

**Significant pairs (p < 0.05):**
- DeepSeek-Chat vs Gemma4 31b: p = 0.0409
- DeepSeek-V4 vs Gemma4 31b: p = 0.0409