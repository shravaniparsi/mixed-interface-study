"""Nemenyi post-hoc pairwise model comparisons."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats as scstats
import scikit_posthocs as sp

ROOT = Path(__file__).parent.parent
RESULTS = ROOT / "results"
OUT = ROOT / "v_temp" / "stats_nemenyi_results.md"


def gget(d, *keys, default=0):
    for k in keys:
        if not isinstance(d, dict): return default
        d = d.get(k, {})
    return d if d not in ({}, None) else default


TEMPS = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
sources = [
    ("Gemini",       RESULTS / "experiment_temp_gemini_20260415_105537.json"),
    ("DSChat",       RESULTS / "experiment_temp_deepseek_chat_20260428_062426.json"),
    ("Mistral2512",  RESULTS / "experiment_temp_mistral_20260505_213959.json"),
    ("DSV4",         RESULTS / "experiment_temp_deepseek_v4_20260505_205646.json"),
    ("ClaudeHaiku",  RESULTS / "experiment_temp_claude_haiku_20260506_201948.json"),
    ("Qwen32b",      RESULTS / "experiment_temp_qwen_20260415_075716.json"),
    ("DSR1_32b",     RESULTS / "experiment_temp_deepseek_20260415_084630.json"),
    ("Gemma4_31b",   RESULTS / "experiment_temp_gemma_20260416_003100.json"),
]
data = defaultdict(dict)
for label, p in sources:
    if not p.exists(): continue
    runs = json.load(open(p, encoding="utf-8"))
    by_temp = defaultdict(list)
    for r in runs:
        if "metrics" in r:
            t = round(r["temperature"], 2)
            v = gget(r, "metrics", "test_validity", "validity_rate_pct")
            if v is not None and t in TEMPS:
                by_temp[t].append(v)
    for t, vs in by_temp.items():
        data[label][t] = float(np.mean(vs))

models_full = [m for m in data if len(data[m]) == len(TEMPS)]
matrix = np.array([[data[m][t] for m in models_full] for t in TEMPS])
df = pd.DataFrame(matrix, index=TEMPS, columns=models_full)

print("Temperature axis matrix (rows=temps, cols=models):")
print(df.round(1))

stat, pval = scstats.friedmanchisquare(*matrix.T)
print(f"\nFriedman χ² = {stat:.3f}, p = {pval:.6f}")

nemenyi_temp = sp.posthoc_nemenyi_friedman(matrix)
nemenyi_temp.index = models_full
nemenyi_temp.columns = models_full
print("\nNemenyi pairwise p-values (temperature axis):")
print(nemenyi_temp.round(4))


agg = json.load(open(RESULTS / "mutation_matrix_aggregate.json", encoding="utf-8"))
mut_data = defaultdict(dict)
for c in agg:
    s = c.get("score")
    if s and isinstance(s.get("pct"), (int, float)):
        mut_data[c["model"]][c["level"]] = float(s["pct"])

LEVELS = ["L0", "L1", "L2", "L3", "L4"]
mut_models_full = [m for m in mut_data if len(mut_data[m]) == len(LEVELS)]
mut_matrix = np.array([[mut_data[m][L] for m in mut_models_full] for L in LEVELS])

mut_stat, mut_pval = scstats.friedmanchisquare(*mut_matrix.T)
print(f"\n\nMutation matrix Friedman χ² = {mut_stat:.3f}, p = {mut_pval:.6f}")

nemenyi_mut = sp.posthoc_nemenyi_friedman(mut_matrix)
nemenyi_mut.index = mut_models_full
nemenyi_mut.columns = mut_models_full
print("\nNemenyi pairwise p-values (mutation matrix):")
print(nemenyi_mut.round(4))


lines = []
lines.append("# Friedman + Nemenyi post-hoc - pairwise model comparisons")
lines.append("")
lines.append(f"Generated: 2026-05-12")
lines.append("")

lines.append("## 1. Temperature axis (n=6 temperatures, models with all temps)")
lines.append("")
lines.append(f"Models: {', '.join(models_full)}")
lines.append("")
lines.append(f"Friedman χ² = {stat:.3f}, p = {pval:.6f}")
lines.append("")
lines.append("Nemenyi pairwise p-values:")
lines.append("")
lines.append("| | " + " | ".join(models_full) + " |")
lines.append("|---|" + "|".join(["---"] * len(models_full)) + "|")
for r in models_full:
    row = [f"{nemenyi_temp.loc[r, c]:.4f}" if r != c else "-" for c in models_full]
    lines.append(f"| {r} | " + " | ".join(row) + " |")
lines.append("")
lines.append("**Significant pairs (p < 0.05):**")
for i, m1 in enumerate(models_full):
    for j, m2 in enumerate(models_full):
        if i < j:
            p = nemenyi_temp.loc[m1, m2]
            if p < 0.05:
                lines.append(f"- {m1} vs {m2}: p = {p:.4f}")
lines.append("")

lines.append("## 2. Mutation matrix (n=5 levels, models with full L0-L4)")
lines.append("")
lines.append(f"Models: {', '.join(mut_models_full)}")
lines.append("")
lines.append(f"Friedman χ² = {mut_stat:.3f}, p = {mut_pval:.6f}")
lines.append("")
lines.append("Nemenyi pairwise p-values:")
lines.append("")
lines.append("| | " + " | ".join(mut_models_full) + " |")
lines.append("|---|" + "|".join(["---"] * len(mut_models_full)) + "|")
for r in mut_models_full:
    row = [f"{nemenyi_mut.loc[r, c]:.4f}" if r != c else "-" for c in mut_models_full]
    lines.append(f"| {r} | " + " | ".join(row) + " |")
lines.append("")
lines.append("**Significant pairs (p < 0.05):**")
significant_count = 0
for i, m1 in enumerate(mut_models_full):
    for j, m2 in enumerate(mut_models_full):
        if i < j:
            p = nemenyi_mut.loc[m1, m2]
            if p < 0.05:
                lines.append(f"- {m1} vs {m2}: p = {p:.4f}")
                significant_count += 1
if significant_count == 0:
    lines.append("- (no pairs reach α = 0.05 after Nemenyi correction)")

OUT.write_text("\n".join(lines), encoding="utf-8")
print(f"\n\nSaved -> {OUT}")
