# Temperature axis

L1 context, temperatures 0.0 / 0.2 / 0.4 / 0.6 / 0.8 / 1.0, 3 runs per cell,
7 models (4 cloud + 3 open-weight) + an additional Qwen L2 sweep.

`results/` holds one JSON per sweep (file name carries the model; the
DeepSeek-R1 32B sweep is `experiment_temp_deepseek_20260415_084630.json`).

## Retained generated suites

| Folder | Files |
|---|---|
| `generated_suites/deepseek-chat_L1/` | 54 files |
| `generated_suites/gemini_L1/` | 54 files |
| `generated_suites/qwen_L1/` | 54 files |
| `generated_suites/qwen_L2/` | 54 files |

Suites of the remaining sweeps (Claude Haiku 4.5, Mistral Large 3,
DeepSeek-V4-Flash, DeepSeek-R1 32B, Gemma4 31B) could not be retrieved before
the compute host was decommissioned; their complete per-run metrics,
diagnostics and token accounting are preserved in `results/`.
