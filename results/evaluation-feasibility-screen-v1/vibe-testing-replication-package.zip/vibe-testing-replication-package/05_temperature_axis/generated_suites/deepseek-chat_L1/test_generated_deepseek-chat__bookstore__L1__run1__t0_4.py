# The main error is likely that the API requires X-API-Key header for some endpoints, and the helpers don't include it.
# Also, ISBN must be exactly 13 characters, and the unique function may generate strings that exceed field length limits.
# We need to add the API key header to all requests and ensure ISBN is exactly 13 characters.

import uuid
import requests
import io

BASE_URL = "http://127.0.0.1:8000"
API_KEY = "test-api-key"

def unique(prefix: str) -> str:
    return f'{prefix}_{uuid.uuid4().hex[:8]}'

def create_author(session, name=None, bio=None, born_year=None):
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    headers = {"X-API-Key": API_KEY}
    r = session.post(f"{BASE_URL}/authors", json=payload, headers=headers, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(session, name=None, description=None):
    if name is None:
        name = unique("cat")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    headers = {"X-API-Key": API_KEY}
    r = session.post(f"{BASE_URL}/categories", json=payload, headers=headers, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(session, author_id, category_id, title=None, isbn=None, price=10.0, published_year=2020, stock=10):
    if title is None:
        title = unique("book")
    if isbn is None:
        # Ensure ISBN is exactly 13 characters
        isbn = uuid.uuid4().hex[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    headers = {"X-API-Key": API_KEY}
    r = session.post(f"{BASE_URL}/books", json=payload, headers=headers, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(session, name=None):
    if name is None:
        name = unique("tag")
    headers = {"X-API-Key": API_KEY}
    r = session.post(f"{BASE_URL}/tags", json={"name": name}, headers=headers, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=30)
    assert r.status_code == 200

def test_create_author_success():
    s = requests.Session()
    name = unique("author")
    r = s.post(f"{BASE_URL}/authors", json={"name": name}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name_returns_422():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/authors", json={}, timeout=30)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_authors_with_pagination():
    s = requests.Session()
    create_author(s)
    r = s.get(f"{BASE_URL}/authors", params={"skip": 0, "limit": 100}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_get_author_by_id_success():
    s = requests.Session()
    author = create_author(s)
    r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == author["id"]

def test_get_author_not_found_returns_404():
    s = requests.Session()
    r = s.get(f"{BASE_URL}/authors/999999", timeout=30)
    assert r.status_code == 404

def test_update_author_with_valid_etag():
    s = requests.Session()
    author = create_author(s)
    get_r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    etag = get_r.headers.get("etag")
    new_name = unique("updated")
    r = s.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, headers={"If-Match": etag}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["name"] == new_name

def test_update_author_etag_mismatch_returns_412():
    s = requests.Session()
    author = create_author(s)
    r = s.put(f"{BASE_URL}/authors/{author['id']}", json={"name": unique("x")}, headers={"If-Match": '"stale-etag"'}, timeout=30)
    assert r.status_code == 412

def test_delete_author_without_books_success():
    s = requests.Session()
    author = create_author(s)
    r = s.delete(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 204

def test_create_category_success():
    s = requests.Session()
    name = unique("cat")
    r = s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_duplicate_category_returns_409():
    s = requests.Session()
    name = unique("cat")
    s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    r = s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    assert r.status_code == 409

def test_create_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    r = s.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["title"] == title
    assert data["isbn"] == isbn

def test_create_book_duplicate_isbn_returns_409():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    isbn = unique("isbn")[:13]
    payload = {
        "title": unique("book"),
        "isbn": isbn,
        "price": 10.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    s.post(f"{BASE_URL}/books", json=payload, timeout=30)
    r = s.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code == 409

def test_list_books_with_filters():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    create_book(s, author["id"], cat["id"], title=unique("filter"), price=25.0, published_year=2020)
    r = s.get(f"{BASE_URL}/books", params={"search": "filter", "min_price": 20, "max_price": 30}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_book_by_id_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]

def test_get_soft_deleted_book_returns_410():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 410

def test_soft_delete_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204
    get_r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert get_r.status_code == 410

def test_restore_soft_deleted_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = s.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]

def test_create_review_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    reviewer = unique("rev")
    payload = {"rating": 5, "reviewer_name": reviewer, "comment": "Great!"}
    r = s.post(f"{BASE_URL}/books/{book['id']}/reviews", json=payload, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["reviewer_name"] == reviewer
    assert data["rating"] == 5

def test_get_book_rating_with_reviews():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    s.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 4, "reviewer_name": unique("r")}, timeout=30)
    s.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 2, "reviewer_name": unique("r")}, timeout=30)
    r = s.get(f"{BASE_URL}/books/{book['id']}/rating", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "average_rating" in data
    assert data["review_count"] == 2

def test_apply_discount_to_old_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], price=100.0, published_year=2020)
    r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["discounted_price"] == 80.0

def test_apply_discount_to_new_book_returns_400():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], price=100.0, published_year=2026)
    r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=30)
    assert r.status_code == 400

def test_update_stock_positive_delta_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=5", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 15

def test_update_stock_insufficient_returns_400():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=3)
    r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-10", timeout=30)
    assert r.status_code == 400


def test_create_tag_success():
    session = requests.Session()
    tag_name = unique("tag")
    r = session.post(f"{BASE_URL}/tags", json={"name": tag_name}, timeout=30)
    assert r.status_code in (200, 201)
    data = r.json()
    assert data["name"] == tag_name
    assert "id" in data

def test_list_tags_pagination():
    session = requests.Session()
    for _ in range(3):
        create_tag(session)
    r = session.get(f"{BASE_URL}/tags?skip=0&limit=2", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert len(data) <= 2

def test_get_tag_by_id_not_found_returns_404():
    session = requests.Session()
    fake_id = 99999
    r = session.get(f"{BASE_URL}/tags/{fake_id}", timeout=30)
    assert r.status_code == 404

def test_delete_tag_success():
    session = requests.Session()
    tag = create_tag(session)
    tag_id = tag["id"]
    r = session.delete(f"{BASE_URL}/tags/{tag_id}", timeout=30)
    assert r.status_code == 204
    r2 = session.get(f"{BASE_URL}/tags/{tag_id}", timeout=30)
    assert r2.status_code == 404

def test_create_book_with_tags_success():
    session = requests.Session()
    author = create_author(session)
    category = create_category(session)
    tag1 = create_tag(session)
    tag2 = create_tag(session)
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": category["id"],
        "tag_ids": [tag1["id"], tag2["id"]]
    }
    r = session.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code in (200, 201)
    data = r.json()
    assert data["title"] == title
    assert len(data["tags"]) == 2

def test_get_book_rating_no_reviews_returns_zero():
    session = requests.Session()
    author = create_author(session)
    category = create_category(session)
    book = create_book(session, author["id"], category["id"])
    r = session.get(f"{BASE_URL}/books/{book['id']}/rating", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["average_rating"] == 0.0
    assert data["reviews_count"] == 0