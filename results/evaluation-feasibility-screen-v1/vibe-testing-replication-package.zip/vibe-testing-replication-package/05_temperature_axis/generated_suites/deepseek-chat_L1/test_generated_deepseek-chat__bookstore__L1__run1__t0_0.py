import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30

def unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(session: requests.Session, name: str = None, bio: str = None, born_year: int = None) -> dict:
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = session.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(session: requests.Session, name: str = None, description: str = None) -> dict:
    if name is None:
        name = unique("category")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = session.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(session: requests.Session, author_id: int, category_id: int, title: str = None, isbn: str = None, price: float = 10.0, published_year: int = 2020, stock: int = 10) -> dict:
    if title is None:
        title = unique("book")
    if isbn is None:
        isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = session.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(session: requests.Session, name: str = None) -> dict:
    if name is None:
        name = unique("tag")
    r = session.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200

def test_create_author_success():
    s = requests.Session()
    name = unique("author")
    r = s.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name_returns_422():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/authors", json={}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_authors_with_pagination():
    s = requests.Session()
    create_author(s)
    r = s.get(f"{BASE_URL}/authors", params={"skip": 0, "limit": 100}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_get_author_by_id_success():
    s = requests.Session()
    author = create_author(s)
    r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert "ETag" in r.headers

def test_get_author_not_found_returns_404():
    s = requests.Session()
    r = s.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404

def test_update_author_with_valid_etag():
    s = requests.Session()
    author = create_author(s)
    r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    etag = r.headers.get("ETag")
    new_name = unique("updated")
    r2 = s.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, headers={"If-Match": etag}, timeout=TIMEOUT)
    assert r2.status_code == 200
    data = r2.json()
    assert data["name"] == new_name

def test_update_author_etag_mismatch_returns_412():
    s = requests.Session()
    author = create_author(s)
    r = s.put(f"{BASE_URL}/authors/{author['id']}", json={"name": unique("x")}, headers={"If-Match": '"wrong-etag"'}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_delete_author_without_books_success():
    s = requests.Session()
    author = create_author(s)
    r = s.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_create_category_success():
    s = requests.Session()
    name = unique("cat")
    r = s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_get_category_by_id_success():
    s = requests.Session()
    cat = create_category(s)
    r = s.get(f"{BASE_URL}/categories/{cat['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data

def test_create_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    r = s.post(f"{BASE_URL}/books", json={
        "title": unique("book"),
        "isbn": unique("isbn")[:13],
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_create_book_duplicate_isbn_returns_409():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    isbn = unique("isbn")[:13]
    s.post(f"{BASE_URL}/books", json={
        "title": unique("book"),
        "isbn": isbn,
        "price": 10.0,
        "published_year": 2020,
        "stock": 1,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    r2 = s.post(f"{BASE_URL}/books", json={
        "title": unique("book2"),
        "isbn": isbn,
        "price": 12.0,
        "published_year": 2020,
        "stock": 2,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    assert r2.status_code == 409

def test_list_books_with_filters():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    create_book(s, author["id"], cat["id"])
    r = s.get(f"{BASE_URL}/books", params={"search": "book", "min_price": 5.0, "max_price": 50.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data

def test_get_book_by_id_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert "ETag" in r.headers

def test_get_soft_deleted_book_returns_410():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_soft_delete_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_restore_soft_deleted_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = s.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]

def test_apply_discount_to_old_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], published_year=2020, price=100.0)
    r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "discounted_price" in data
    assert data["original_price"] == 100.0
    assert data["discount_percent"] == 20.0

def test_apply_discount_to_new_book_returns_400():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], published_year=2026, price=50.0)
    r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_stock_positive_delta_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=5)
    r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=3", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 8

def test_update_stock_insufficient_returns_400():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=2)
    r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-5", timeout=TIMEOUT)
    assert r.status_code == 400

def test_upload_cover_valid_image_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    files = {"file": ("test.jpg", b"fake_jpeg_data", "image/jpeg")}
    r = s.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "filename" in data

def test_upload_cover_unsupported_type_returns_415():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    files = {"file": ("test.txt", b"some text", "text/plain")}
    r = s.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 415

def test_create_review_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 5, "reviewer_name": unique("rev")}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["rating"] == 5

def test_create_tag_success():
    s = requests.Session()
    name = unique("tag")
    r = s.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_add_tags_to_book_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    tag = create_tag(s)
    r = s.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [tag["id"]]}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert any(t["id"] == tag["id"] for t in data["tags"])

def test_create_order_success():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10, price=25.0)
    r = s.post(f"{BASE_URL}/orders", json={
        "customer_name": unique("cust"),
        "customer_email": "test@example.com",
        "items": [{"book_id": book["id"], "quantity": 2}]
    }, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["total_price"] == 50.0

def test_create_order_insufficient_stock_returns_400():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=1)
    r = s.post(f"{BASE_URL}/orders", json={
        "customer_name": unique("cust"),
        "customer_email": "test@example.com",
        "items": [{"book_id": book["id"], "quantity": 5}]
    }, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_order_status_valid_transition():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    order_resp = s.post(f"{BASE_URL}/orders", json={
        "customer_name": unique("cust"),
        "customer_email": "test@example.com",
        "items": [{"book_id": book["id"], "quantity": 1}]
    }, timeout=TIMEOUT)
    order = order_resp.json()
    r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "confirmed"