import pytest
import requests
import uuid

BASE_URL = "http://127.0.0.1:8000"

def unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name: str = None, bio: str = None, born_year: int = None):
    if name is None:
        name = unique("author")
    body = {"name": name}
    if bio is not None:
        body["bio"] = bio
    if born_year is not None:
        body["born_year"] = born_year
    r = requests.post(f"{BASE_URL}/authors", json=body, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name: str = None, description: str = None):
    if name is None:
        name = unique("cat")
    body = {"name": name}
    if description is not None:
        body["description"] = description
    r = requests.post(f"{BASE_URL}/categories", json=body, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title: str = None, isbn: str = None, price: float = 10.0, published_year: int = 2020, stock: int = 10, author_id: int = None, category_id: int = None):
    if title is None:
        title = unique("book")
    if isbn is None:
        isbn = unique("isbn")[:13]
    if author_id is None:
        author_id = create_author()["id"]
    if category_id is None:
        category_id = create_category()["id"]
    body = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=body, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name: str = None):
    if name is None:
        name = unique("tag")
    body = {"name": name}
    r = requests.post(f"{BASE_URL}/tags", json=body, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(customer_name: str = None, customer_email: str = None, items: list = None):
    if customer_name is None:
        customer_name = unique("cust")
    if customer_email is None:
        customer_email = f"{uuid.uuid4().hex[:8]}@example.com"
    if items is None:
        book = create_book(stock=5)
        items = [{"book_id": book["id"], "quantity": 1}]
    body = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items
    }
    r = requests.post(f"{BASE_URL}/orders", json=body, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

# ---- /health ----
def test_health_check_ok():
    r = requests.get(f"{BASE_URL}/health", timeout=30)
    assert r.status_code == 200

# ---- /authors POST ----
def test_create_author_success():
    name = unique("author")
    bio = "Sample bio"
    born_year = 1980
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": bio, "born_year": born_year}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == name
    assert data["bio"] == bio
    assert data["born_year"] == born_year
    assert "id" in data

# ---- /authors GET ----
def test_list_authors_with_skip_limit():
    create_author()
    create_author()
    r = requests.get(f"{BASE_URL}/authors?skip=0&limit=1", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert len(data) >= 0

# ---- /authors/{author_id} GET ----
def test_get_author_not_found():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

# ---- /authors/{author_id} PUT ----
def test_update_author_with_etag_mismatch():
    author = create_author()
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": "Updated"}, headers={"If-Match": '"wrongetag"'}, timeout=30)
    assert r.status_code == 412
    assert "detail" in r.json()

# ---- /authors/{author_id} DELETE ----
def test_delete_author_with_books_conflict():
    author = create_author()
    cat = create_category()
    requests.post(f"{BASE_URL}/books", json={"title": "Test Book", "isbn": unique("isbn")[:13], "price": 10.0, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": cat["id"]}, timeout=30)
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 409
    assert "detail" in r.json()

# ---- /categories POST ----
def test_create_category_success():
    name = unique("cat")
    r = requests.post(f"{BASE_URL}/categories", json={"name": name, "description": "desc"}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == name
    assert data["description"] == "desc"
    assert "id" in data

# ---- /categories GET ----
def test_list_categories_empty():
    r = requests.get(f"{BASE_URL}/categories", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

# ---- /categories/{category_id} PUT ----
def test_update_category_duplicate_name():
    cat1 = create_category()
    cat2 = create_category()
    r = requests.put(f"{BASE_URL}/categories/{cat2['id']}", json={"name": cat1["name"]}, timeout=30)
    assert r.status_code == 409
    assert "detail" in r.json()

# ---- /books POST ----
def test_create_book_success():
    author = create_author()
    cat = create_category()
    title = unique("book")
    isbn = unique("isbn")[:13]
    r = requests.post(f"{BASE_URL}/books", json={"title": title, "isbn": isbn, "price": 15.0, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": cat["id"]}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["title"] == title
    assert data["isbn"] == isbn
    assert "id" in data

# ---- /books GET ----
def test_list_books_with_filters():
    author = create_author()
    cat = create_category()
    create_book(author_id=author["id"], category_id=cat["id"], price=12.0)
    r = requests.get(f"{BASE_URL}/books?search={unique('test')[:5]}&min_price=5&max_price=20&author_id={author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data
    assert "page" in data
    assert "page_size" in data
    assert "total_pages" in data

# ---- /books/{book_id} GET ----
def test_get_deleted_book_returns_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()

# ---- /books/{book_id} GET with ETag ----
def test_get_book_etag_unchanged_304():
    book = create_book()
    r1 = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    etag = r1.headers.get("ETag")
    if etag:
        r2 = requests.get(f"{BASE_URL}/books/{book['id']}", headers={"If-None-Match": etag}, timeout=30)
        assert r2.status_code == 304

# ---- /books/{book_id} PUT ----
def test_update_book_wrong_etag_412():
    book = create_book()
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": "New"}, headers={"If-Match": '"wrong"'}, timeout=30)
    assert r.status_code == 412
    assert "detail" in r.json()

# ---- /books/{book_id} DELETE ----
def test_delete_book_soft_delete_ok():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204

# ---- /books/{book_id} PUT on deleted ----
def test_update_deleted_book_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": "New"}, timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()

# ---- /books/{book_id}/restore ----
def test_restore_not_deleted_book_400():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

# ---- /books/{book_id}/discount ----
def test_apply_discount_to_new_book_400():
    book = create_book(published_year=2026, price=20.0)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

# ---- /books/{book_id}/discount rate limit ----
def test_apply_discount_rate_limited():
    book = create_book(published_year=2020, price=20.0)
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=30)
    # At least one should be 429
    assert r.status_code == 429

# ---- /books/{book_id}/stock negative ----
def test_update_stock_negative_result_400():
    book = create_book(stock=2)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-5", timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

# ---- /books/{book_id}/stock positive ----
def test_update_stock_positive_delta():
    book = create_book(stock=2)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=3", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 5

# ---- /books/{book_id}/cover POST unsupported ----
def test_upload_cover_unsupported_type_415():
    book = create_book()
    files = {"file": ("test.txt", b"test", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=30)
    assert r.status_code == 415
    assert "detail" in r.json()

# ---- /books/{book_id}/cover POST too large ----
def test_upload_cover_file_too_large_413():
    book = create_book()
    files = {"file": ("test.jpg", b"x" * (2_097_152 + 1), "image/jpeg")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=30)
    assert r.status_code == 413
    assert "detail" in r.json()

# ---- /books/{book_id}/reviews POST ----
def test_create_review_success():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 4, "comment": "Good", "reviewer_name": "John"}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["rating"] == 4
    assert data["reviewer_name"] == "John"
    assert "id" in data

# ---- /books/{book_id}/reviews GET on deleted ----
def test_list_reviews_for_deleted_book_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.get(f"{BASE_URL}/books/{book['id']}/reviews", timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()

# ---- /tags POST ----
def test_create_tag_duplicate_name_409():
    tag_name = unique("tag")
    create_tag(tag_name)
    r = requests.post(f"{BASE_URL}/tags", json={"name": tag_name}, timeout=30)
    assert r.status_code == 409
    assert "detail" in r.json()

# ---- /books/bulk POST no API key ----
def test_bulk_create_no_api_key_401():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=30)
    assert r.status_code == 401
    assert "detail" in r.json()

# ---- /orders POST insufficient stock ----
def test_create_order_insufficient_stock_400():
    book = create_book(stock=0)
    r = requests.post(f"{BASE_URL}/orders", json={"customer_name": "Test", "customer_email": "test@example.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

# ---- /orders/{order_id}/status invalid transition ----
def test_update_order_status_invalid_transition_400():
    order = create_order()
    book = create_book(stock=5)
    items = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(items=items)
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

# ---- /orders/{order_id}/invoice for pending ----
def test_get_invoice_for_pending_order_403():
    order = create_order()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=30)
    assert r.status_code == 403
    assert "detail" in r.json()