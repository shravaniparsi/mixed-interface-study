# The main error is likely due to ISBN length constraints - the unique function generates strings that may exceed the ISBN field limit (13 characters). Fix by truncating ISBN to exactly 13 characters and ensuring all required fields are properly formatted.

import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30
API_KEY = "test-api-key"

def unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(session: requests.Session, name: str = None, bio: str = None, born_year: int = None) -> dict:
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = session.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(session: requests.Session, name: str = None, description: str = None) -> dict:
    if name is None:
        name = unique("category")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = session.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(session: requests.Session, author_id: int, category_id: int, title: str = None, isbn: str = None, price: float = 10.0, published_year: int = 2020, stock: int = 10) -> dict:
    if title is None:
        title = unique("book")
    if isbn is None:
        # Generate a valid 13-digit ISBN (only digits, exactly 13 characters)
        isbn = ''.join(str(uuid.uuid4().int)[:13])
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = session.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(session: requests.Session, name: str = None) -> dict:
    if name is None:
        name = unique("tag")
    payload = {"name": name}
    r = session.post(f"{BASE_URL}/tags", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(session: requests.Session, customer_name: str, customer_email: str, items: list) -> dict:
    payload = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items
    }
    r = session.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_health_check_returns_200():
    with requests.Session() as s:
        r = s.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        assert r.status_code == 200

def test_create_author_success():
    with requests.Session() as s:
        name = unique("author")
        r = s.post(f"{BASE_URL}/authors", json={"name": name, "bio": "Test bio", "born_year": 1980}, timeout=TIMEOUT)
        assert r.status_code == 201
        data = r.json()
        assert "id" in data
        assert data["name"] == name

def test_create_author_missing_name_returns_422():
    with requests.Session() as s:
        r = s.post(f"{BASE_URL}/authors", json={"bio": "No name"}, timeout=TIMEOUT)
        assert r.status_code == 422
        assert "detail" in r.json()

def test_get_author_by_id_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert data["id"] == author["id"]

def test_get_author_not_found_returns_404():
    with requests.Session() as s:
        r = s.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
        assert r.status_code == 404

def test_delete_author_with_books_returns_409():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        create_book(s, author_id=author["id"], category_id=cat["id"])
        r = s.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert r.status_code == 409
        assert "detail" in r.json()

def test_create_category_success():
    with requests.Session() as s:
        name = unique("cat")
        r = s.post(f"{BASE_URL}/categories", json={"name": name, "description": "Test category"}, timeout=TIMEOUT)
        assert r.status_code == 201
        data = r.json()
        assert "id" in data
        assert data["name"] == name

def test_create_duplicate_category_name_returns_409():
    with requests.Session() as s:
        name = unique("catdup")
        s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
        r = s.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
        assert r.status_code == 409
        assert "detail" in r.json()

def test_create_book_success():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        title = unique("book")
        isbn = unique("isbn")[:13]
        payload = {
            "title": title,
            "isbn": isbn,
            "price": 19.99,
            "published_year": 2021,
            "stock": 5,
            "author_id": author["id"],
            "category_id": cat["id"]
        }
        r = s.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
        assert r.status_code == 201
        data = r.json()
        assert "id" in data
        assert data["title"] == title

def test_create_book_duplicate_isbn_returns_409():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        isbn = unique("isbn")[:13]
        s.post(f"{BASE_URL}/books", json={"title": "Book1", "isbn": isbn, "price": 10, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": cat["id"]}, timeout=TIMEOUT)
        r = s.post(f"{BASE_URL}/books", json={"title": "Book2", "isbn": isbn, "price": 15, "published_year": 2021, "stock": 3, "author_id": author["id"], "category_id": cat["id"]}, timeout=TIMEOUT)
        assert r.status_code == 409
        assert "detail" in r.json()

def test_get_book_returns_200_with_etag():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert data["id"] == book["id"]
        assert "etag" in r.headers or "ETag" in r.headers

def test_soft_delete_book_returns_204():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        assert r.status_code == 204

def test_restore_soft_deleted_book_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        r = s.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert data["id"] == book["id"]

def test_apply_discount_to_old_book_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], published_year=2020, price=100.0)
        r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert "discounted_price" in data
        assert data["discounted_price"] == 80.0

def test_apply_discount_to_new_book_returns_400():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], published_year=2026, price=100.0)
        r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=TIMEOUT)
        assert r.status_code == 400
        assert "detail" in r.json()

def test_update_stock_positive_delta_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=5", timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert data["stock"] == 15

def test_update_stock_insufficient_returns_400():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=3)
        r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-10", timeout=TIMEOUT)
        assert r.status_code == 400
        assert "detail" in r.json()

def test_upload_cover_valid_jpeg_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        files = {"file": ("test.jpg", b"fake_jpeg_data", "image/jpeg")}
        r = s.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert "filename" in data

def test_upload_cover_unsupported_type_returns_415():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        files = {"file": ("test.txt", b"text data", "text/plain")}
        r = s.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
        assert r.status_code == 415
        assert "detail" in r.json()

def test_create_review_success():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        r = s.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 5, "reviewer_name": "Tester", "comment": "Great!"}, timeout=TIMEOUT)
        assert r.status_code == 201
        data = r.json()
        assert "id" in data
        assert data["rating"] == 5

def test_add_tags_to_book_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        tag = create_tag(s)
        r = s.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [tag["id"]]}, timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert any(t["id"] == tag["id"] for t in data["tags"])

def test_create_order_success():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        r = s.post(f"{BASE_URL}/orders", json={"customer_name": "John", "customer_email": "john@test.com", "items": [{"book_id": book["id"], "quantity": 2}]}, timeout=TIMEOUT)
        assert r.status_code == 201
        data = r.json()
        assert "id" in data
        assert data["total_price"] == book["price"] * 2

def test_create_order_insufficient_stock_returns_400():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=1)
        r = s.post(f"{BASE_URL}/orders", json={"customer_name": "John", "customer_email": "john@test.com", "items": [{"book_id": book["id"], "quantity": 5}]}, timeout=TIMEOUT)
        assert r.status_code == 400
        assert "detail" in r.json()

def test_update_order_status_valid_transition_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        order = create_order(s, "Jane", "jane@test.com", [{"book_id": book["id"], "quantity": 1}])
        r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "confirmed"

def test_update_order_status_invalid_transition_returns_400():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        order = create_order(s, "Jane", "jane@test.com", [{"book_id": book["id"], "quantity": 1}])
        r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=TIMEOUT)
        assert r.status_code == 400
        assert "detail" in r.json()

def test_get_invoice_for_confirmed_order_returns_200():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        order = create_order(s, "Jane", "jane@test.com", [{"book_id": book["id"], "quantity": 1}])
        s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
        r = s.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert "invoice_number" in data

def test_get_invoice_for_pending_order_returns_403():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"], stock=10)
        order = create_order(s, "Jane", "jane@test.com", [{"book_id": book["id"], "quantity": 1}])
        r = s.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
        assert r.status_code == 403
        assert "detail" in r.json()

def test_bulk_create_books_all_success_returns_201():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        books_data = []
        for i in range(3):
            books_data.append({
                "title": unique("bulk"),
                "isbn": unique("isbn")[:13],
                "price": 15.0,
                "published_year": 2020,
                "stock": 5,
                "author_id": author["id"],
                "category_id": cat["id"]
            })
        headers = {"X-API-Key": API_KEY}
        r = s.post(f"{BASE_URL}/books/bulk", json={"books": books_data}, headers=headers, timeout=TIMEOUT)
        assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"

def test_get_statistics_with_api_key_returns_200():
    with requests.Session() as s:
        headers = {"X-API-Key": API_KEY}
        r = s.get(f"{BASE_URL}/statistics/summary", headers=headers, timeout=TIMEOUT)
        assert r.status_code == 200
        data = r.json()
        assert "total_books" in data

def test_get_soft_deleted_book_returns_410():
    with requests.Session() as s:
        author = create_author(s)
        cat = create_category(s)
        book = create_book(s, author_id=author["id"], category_id=cat["id"])
        s.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        assert r.status_code == 410
        assert "detail" in r.json()