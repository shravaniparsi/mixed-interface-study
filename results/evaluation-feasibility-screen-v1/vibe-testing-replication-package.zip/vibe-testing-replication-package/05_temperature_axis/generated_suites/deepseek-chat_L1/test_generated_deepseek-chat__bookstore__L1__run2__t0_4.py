import uuid
import requests
import time

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30

def unique(prefix: str) -> str:
    return f'{prefix}_{uuid.uuid4().hex[:8]}'

def create_author(name: str = None, bio: str = "Test bio", born_year: int = 1980) -> dict:
    if name is None:
        name = unique("author")
    payload = {"name": name, "bio": bio, "born_year": born_year}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name: str = None, description: str = "Test category") -> dict:
    if name is None:
        name = unique("cat")
    payload = {"name": name, "description": description}
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(author_id: int, category_id: int, title: str = None, isbn: str = None, price: float = 19.99, published_year: int = 2020, stock: int = 10) -> dict:
    if title is None:
        title = unique("book")
    if isbn is None:
        isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name: str = None) -> dict:
    if name is None:
        name = unique("tag")
    payload = {"name": name}
    r = requests.post(f"{BASE_URL}/tags", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(customer_name: str = None, customer_email: str = "test@example.com", items: list = None) -> dict:
    if customer_name is None:
        customer_name = unique("cust")
    if items is None:
        items = []
    payload = {"customer_name": customer_name, "customer_email": customer_email, "items": items}
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def test_health_check_success():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200

def test_create_author_valid():
    name = unique("author")
    payload = {"name": name, "bio": "Some bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name():
    payload = {"bio": "No name"}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_authors_default_pagination():
    create_author()
    r = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_get_author_by_id_success():
    author = create_author()
    author_id = author["id"]
    r = requests.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == author_id
    assert "ETag" in r.headers

def test_get_author_not_found():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404

def test_update_author_with_valid_if_match():
    author = create_author()
    author_id = author["id"]
    get_r = requests.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    etag = get_r.headers.get("ETag", "")
    new_name = unique("updated")
    payload = {"name": new_name}
    r = requests.put(f"{BASE_URL}/authors/{author_id}", json=payload, headers={"If-Match": etag}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["name"] == new_name

def test_update_author_etag_mismatch():
    author = create_author()
    author_id = author["id"]
    payload = {"name": unique("mismatch")}
    r = requests.put(f"{BASE_URL}/authors/{author_id}", json=payload, headers={"If-Match": '"wrong-etag"'}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_delete_author_without_books():
    author = create_author()
    author_id = author["id"]
    r = requests.delete(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_create_category_valid():
    name = unique("cat")
    payload = {"name": name, "description": "Test description"}
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_category_duplicate_name():
    name = unique("catdup")
    payload = {"name": name}
    r1 = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r1.status_code == 201
    r2 = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r2.status_code == 409

def test_get_category_not_modified():
    cat = create_category()
    cat_id = cat["id"]
    get_r = requests.get(f"{BASE_URL}/categories/{cat_id}", timeout=TIMEOUT)
    etag = get_r.headers.get("ETag", "")
    r = requests.get(f"{BASE_URL}/categories/{cat_id}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r.status_code == 304

def test_create_book_valid():
    author = create_author()
    category = create_category()
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 25.50,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": category["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert data["title"] == title
    assert data["isbn"] == isbn

def test_create_book_duplicate_isbn():
    author = create_author()
    category = create_category()
    isbn = unique("isbn")[:13]
    payload1 = {
        "title": unique("book1"),
        "isbn": isbn,
        "price": 10.0,
        "published_year": 2020,
        "stock": 1,
        "author_id": author["id"],
        "category_id": category["id"]
    }
    r1 = requests.post(f"{BASE_URL}/books", json=payload1, timeout=TIMEOUT)
    assert r1.status_code == 201
    payload2 = {
        "title": unique("book2"),
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 2,
        "author_id": author["id"],
        "category_id": category["id"]
    }
    r2 = requests.post(f"{BASE_URL}/books", json=payload2, timeout=TIMEOUT)
    assert r2.status_code == 409

def test_create_book_nonexistent_author():
    category = create_category()
    payload = {
        "title": unique("book"),
        "isbn": unique("isbn")[:13],
        "price": 10.0,
        "published_year": 2020,
        "stock": 1,
        "author_id": 999999,
        "category_id": category["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 404

def test_list_books_with_filters():
    author = create_author()
    category = create_category()
    create_book(author["id"], category["id"], title=unique("filterbook"), price=15.0, published_year=2022)
    r = requests.get(f"{BASE_URL}/books?min_price=10&max_price=20&category_id={category['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data

def test_get_soft_deleted_book():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_soft_delete_book():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    r = requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    assert r.status_code == 204
    get_r = requests.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    assert get_r.status_code == 410

def test_restore_soft_deleted_book():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{book_id}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book_id

def test_restore_not_deleted_book():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    r = requests.post(f"{BASE_URL}/books/{book_id}/restore", timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_review_valid():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    payload = {"rating": 4, "reviewer_name": unique("reviewer"), "comment": "Great book"}
    r = requests.post(f"{BASE_URL}/books/{book_id}/reviews", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert data["book_id"] == book_id
    assert data["rating"] == 4

def test_apply_discount_old_book():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], published_year=2020, price=100.0)
    book_id = book["id"]
    payload = {"discount_percent": 20}
    r = requests.post(f"{BASE_URL}/books/{book_id}/discount", json=payload, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["discounted_price"] == 80.0

def test_apply_discount_new_book():
    author = create_author()
    category = create_category()
    current_year = 2026
    book = create_book(author["id"], category["id"], published_year=current_year, price=50.0)
    book_id = book["id"]
    payload = {"discount_percent": 10}
    r = requests.post(f"{BASE_URL}/books/{book_id}/discount", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_stock_positive_delta():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], stock=5)
    book_id = book["id"]
    r = requests.patch(f"{BASE_URL}/books/{book_id}/stock?quantity=10", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 15

def test_update_stock_insufficient():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], stock=3)
    book_id = book["id"]
    r = requests.patch(f"{BASE_URL}/books/{book_id}/stock?quantity=-10", timeout=TIMEOUT)
    assert r.status_code == 400

def test_upload_cover_valid_jpeg():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    files = {"file": ("test.jpg", b"fake_jpeg_data", "image/jpeg")}
    r = requests.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["book_id"] == book_id
    assert data["content_type"] == "image/jpeg"

def test_upload_cover_unsupported_type():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"])
    book_id = book["id"]
    files = {"file": ("test.txt", b"fake_text_data", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 415

def test_create_order_sufficient_stock():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], stock=10, price=20.0)
    book_id = book["id"]
    customer_name = unique("cust")
    payload = {
        "customer_name": customer_name,
        "customer_email": "cust@test.com",
        "items": [{"book_id": book_id, "quantity": 2}]
    }
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert data["customer_name"] == customer_name
    assert data["total_price"] == 40.0

def test_create_order_insufficient_stock():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], stock=1, price=10.0)
    book_id = book["id"]
    payload = {
        "customer_name": unique("cust"),
        "customer_email": "cust@test.com",
        "items": [{"book_id": book_id, "quantity": 5}]
    }
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_order_status_valid_transition():
    author = create_author()
    category = create_category()
    book = create_book(author["id"], category["id"], stock=5, price=30.0)
    book_id = book["id"]
    order = create_order(items=[{"book_id": book_id, "quantity": 1}])
    order_id = order["id"]
    payload = {"status": "confirmed"}
    r = requests.patch(f"{BASE_URL}/orders/{order_id}/status", json=payload, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "confirmed"