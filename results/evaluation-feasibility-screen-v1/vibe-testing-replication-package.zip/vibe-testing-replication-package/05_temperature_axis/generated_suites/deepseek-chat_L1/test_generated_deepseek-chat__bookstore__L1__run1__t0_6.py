# Analysis: The main error is likely due to helper functions not including required API key header (X-API-Key) for endpoints that require authentication. Also need to ensure ISBN length is exactly 13 characters for the API validation.

import uuid
import pytest
import requests
import time
from io import BytesIO

BASE_URL = "http://127.0.0.1:8000"
API_KEY = "test-api-key"
TIMEOUT = 30

def unique(prefix: str) -> str:
    return f'{prefix}_{uuid.uuid4().hex[:8]}'

def create_author(name: str = None, bio: str = "Bio", born_year: int = 1980):
    if name is None:
        name = unique("author")
    payload = {"name": name, "bio": bio, "born_year": born_year}
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/authors", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name: str = None, description: str = "Category desc"):
    if name is None:
        name = unique("category")
    payload = {"name": name, "description": description}
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/categories", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title: str = None, isbn: str = None, price: float = 19.99, published_year: int = 2020, stock: int = 10, author_id: int = None, category_id: int = None):
    if title is None:
        title = unique("book")
    if isbn is None:
        # Generate exactly 13 digits for ISBN
        isbn = str(uuid.uuid4().int)[:13]
        # Ensure it's exactly 13 characters
        while len(isbn) < 13:
            isbn = "0" + isbn
        isbn = isbn[:13]
    if author_id is None:
        author = create_author()
        author_id = author["id"]
    if category_id is None:
        category = create_category()
        category_id = category["id"]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/books", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name: str = None):
    if name is None:
        name = unique("tag")
    payload = {"name": name}
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/tags", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(customer_name: str = None, customer_email: str = "test@example.com", items: list = None):
    if customer_name is None:
        customer_name = unique("customer")
    if items is None:
        book = create_book(stock=10)
        items = [{"book_id": book["id"], "quantity": 2}]
    payload = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items
    }
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/orders", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

# ========== /health ==========


def test_health_check_happy_path():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200

def test_health_check_method_not_allowed():
    r = requests.post(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 405

# ========== /authors POST ==========

def test_create_author_happy_path():
    name = unique("author")
    payload = {"name": name, "bio": "Test bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name():
    payload = {"bio": "No name"}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

# ========== /authors/{author_id} GET ==========

def test_get_author_not_found():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_get_author_etag_not_modified():
    author = create_author()
    r1 = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r1.status_code == 200
    etag = r1.headers.get("ETag")
    assert etag is not None
    r2 = requests.get(f"{BASE_URL}/authors/{author['id']}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r2.status_code == 304

# ========== /authors/{author_id} PUT ==========

def test_update_author_etag_mismatch():
    author = create_author()
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": "Updated"}, headers={"If-Match": '"wrong-etag"'}, timeout=TIMEOUT)
    assert r.status_code == 412
    assert "detail" in r.json()

# ========== /authors/{author_id} DELETE ==========

def test_delete_author_with_books_conflict():
    author = create_author()
    category = create_category()
    isbn = str(uuid.uuid4().int)[:13]
    payload = {"title": unique("book"), "isbn": isbn, "price": 10.0, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

# ========== /categories POST ==========

def test_create_category_duplicate_name():
    name = unique("category")
    payload = {"name": name}
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

# ========== /categories/{category_id} DELETE ==========

def test_delete_category_with_books_conflict():
    category = create_category()
    author = create_author()
    isbn = str(uuid.uuid4().int)[:13]
    payload = {"title": unique("book"), "isbn": isbn, "price": 10.0, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    r = requests.delete(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

# ========== /books POST ==========

def test_create_book_happy_path():
    author = create_author()
    category = create_category()
    isbn = str(uuid.uuid4().int)[:13]
    payload = {"title": unique("book"), "isbn": isbn, "price": 29.99, "published_year": 2021, "stock": 5, "author_id": author["id"], "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["title"] == payload["title"]

def test_create_book_duplicate_isbn():
    author = create_author()
    category = create_category()
    isbn = str(uuid.uuid4().int)[:13]
    payload = {"title": unique("book"), "isbn": isbn, "price": 10.0, "published_year": 2020, "stock": 5, "author_id": author["id"], "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    payload2 = {"title": unique("book2"), "isbn": isbn, "price": 15.0, "published_year": 2021, "stock": 3, "author_id": author["id"], "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload2, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_book_nonexistent_author():
    category = create_category()
    isbn = str(uuid.uuid4().int)[:13]
    payload = {"title": unique("book"), "isbn": isbn, "price": 10.0, "published_year": 2020, "stock": 5, "author_id": 999999, "category_id": category["id"]}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 404
    assert "detail" in r.json()

# ========== /books/{book_id} DELETE ==========

def test_soft_delete_book_then_get_returns_410():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410
    assert "detail" in r.json()

# ========== /books/{book_id}/restore ==========

def test_restore_non_deleted_book_returns_400():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

# ========== /books/{book_id}/discount ==========

def test_apply_discount_new_book_returns_400():
    current_year = 2026
    book = create_book(published_year=current_year)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_apply_discount_rate_limited():
    book = create_book(published_year=2020)
    for _ in range(5):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
        assert r.status_code == 200
    time.sleep(10)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 429
    assert "detail" in r.json()

# ========== /books/{book_id}/stock ==========

def test_update_stock_negative_result_returns_400():
    book = create_book(stock=5)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-10", timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

# ========== /books/{book_id}/cover ==========

def test_upload_cover_unsupported_type():
    book = create_book()
    files = {"file": ("test.txt", b"test content", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 415
    assert "detail" in r.json()

def test_upload_cover_too_large():
    book = create_book()
    large_data = b"x" * (2 * 1024 * 1024 + 1)
    files = {"file": ("large.jpg", large_data, "image/jpeg")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 413
    assert "detail" in r.json()

# ========== /books/{book_id}/reviews ==========

def test_create_review_on_deleted_book():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    payload = {"rating": 5, "reviewer_name": "Tester", "comment": "Great"}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json=payload, timeout=TIMEOUT)
    assert r.status_code == 410
    assert "detail" in r.json()

# ========== /tags POST ==========

def test_create_tag_duplicate_name():
    name = unique("tag")
    payload = {"name": name}
    r = requests.post(f"{BASE_URL}/tags", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    r = requests.post(f"{BASE_URL}/tags", json=payload, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

# ========== /tags/{tag_id} DELETE ==========

def test_delete_tag_assigned_to_book():
    tag = create_tag()
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [tag["id"]]}, timeout=TIMEOUT)
    assert r.status_code == 200
    r = requests.delete(f"{BASE_URL}/tags/{tag['id']}", timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

# ========== /orders POST ==========

def test_create_order_insufficient_stock():
    book = create_book(stock=1)
    payload = {"customer_name": unique("customer"), "customer_email": "test@test.com", "items": [{"book_id": book["id"], "quantity": 5}]}
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_create_order_happy_path():
    book = create_book(stock=10)
    initial_stock = book["stock"]
    payload = {"customer_name": unique("customer"), "customer_email": "test@test.com", "items": [{"book_id": book["id"], "quantity": 3}]}
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["status"] == "pending"
    r2 = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r2.status_code == 200
    assert r2.json()["stock"] == initial_stock - 3

# ========== /orders/{order_id}/status ==========

def test_update_order_status_invalid_transition():
    order = create_order()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

# ========== /orders/{order_id}/invoice ==========

def test_get_invoice_pending_order():
    order = create_order()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403
    assert "detail" in r.json()

# ========== /orders/{order_id}/items ==========

def test_add_item_to_non_pending_order():
    order = create_order()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    assert r.status_code == 200
    book2 = create_book(stock=5)
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book2["id"], "quantity": 1}, timeout=TIMEOUT)
    assert r.status_code == 403
    assert "detail" in r.json()

# ========== /books/bulk ==========

def test_bulk_create_no_api_key():
    payload = {"books": [{"title": unique("book"), "isbn": str(uuid.uuid4().int)[:13], "price": 10.0, "published_year": 2020, "author_id": 1, "category_id": 1}]}
    r = requests.post(f"{BASE_URL}/books/bulk", json=payload, timeout=TIMEOUT)
    assert r.status_code == 401
    assert "detail" in r.json()

# ========== /exports/books ==========

def test_export_books_no_api_key():
    r = requests.post(f"{BASE_URL}/exports/books", timeout=TIMEOUT)
    assert r.status_code == 401
    assert "detail" in r.json()