import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"
API_KEY = "test-api-key"

def unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name=None, bio=None, born_year=None):
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name=None, description=None):
    if name is None:
        name = unique("cat")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title=None, isbn=None, price=10.0, published_year=2020, stock=10, author_id=None, category_id=None):
    if title is None:
        title = unique("book")
    if isbn is None:
        isbn = unique("isbn")[:13]
    if author_id is None:
        author_id = create_author()["id"]
    if category_id is None:
        category_id = create_category()["id"]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id,
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def test_health_check_success():
    r = requests.get(f"{BASE_URL}/health", timeout=30)
    assert r.status_code == 200

def test_create_author_valid():
    name = unique("author")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": "test bio", "born_year": 1980}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name
    assert data["bio"] == "test bio"
    assert data["born_year"] == 1980

def test_list_authors_with_pagination():
    author1 = create_author()
    author2 = create_author()
    r = requests.get(f"{BASE_URL}/authors", params={"skip": 0, "limit": 100}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    ids = [a["id"] for a in data]
    assert author1["id"] in ids
    assert author2["id"] in ids

def test_get_author_by_id_success():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == author["id"]
    assert "etag" in r.headers or "ETag" in r.headers

def test_get_author_not_found():
    r = requests.get(f"{BASE_URL}/authors/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_update_author_etag_match():
    author = create_author()
    get_resp = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    etag = get_resp.headers.get("ETag") or get_resp.headers.get("etag")
    new_name = unique("updated")
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, headers={"If-Match": etag}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["name"] == new_name

def test_update_author_etag_mismatch():
    author = create_author()
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": unique("bad")}, headers={"If-Match": "w/\"wrongetag\""}, timeout=30)
    assert r.status_code == 412
    assert "detail" in r.json()

def test_delete_author_with_books_conflict():
    author = create_author()
    cat = create_category()
    create_book(author_id=author["id"], category_id=cat["id"])
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_category_duplicate_name():
    name = unique("catdup")
    create_category(name=name)
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_book_valid():
    author = create_author()
    cat = create_category()
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert data["title"] == title
    assert data["isbn"] == isbn
    assert data["price"] == 15.0
    assert data["stock"] == 5

def test_create_book_missing_required_field():
    r = requests.post(f"{BASE_URL}/books", json={"isbn": "1234567890", "price": 10.0, "published_year": 2020, "author_id": 1, "category_id": 1}, timeout=30)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_books_with_filters():
    book = create_book(price=25.0, stock=10)
    r = requests.get(f"{BASE_URL}/books", params={"page": 1, "page_size": 10, "min_price": 20.0, "max_price": 30.0}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data
    ids = [b["id"] for b in data["items"]]
    assert book["id"] in ids

def test_get_book_soft_deleted():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()

def test_soft_delete_book_success():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204

def test_restore_soft_deleted_book():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]

def test_restore_not_deleted_book():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_apply_discount_on_old_book():
    book = create_book(published_year=2020, price=100.0)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["discount_percent"] == 20
    assert data["original_price"] == 100.0
    assert data["discounted_price"] == 80.0

def test_apply_discount_rate_limit():
    book = create_book(published_year=2020)
    statuses = []
    for _ in range(7):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=30)
        statuses.append(r.status_code)
    assert 429 in statuses

def test_update_stock_positive_delta():
    book = create_book(stock=10)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=5", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 15

def test_update_stock_insufficient():
    book = create_book(stock=3)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-10", timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_upload_cover_unsupported_type():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files={"file": ("test.txt", b"test", "text/plain")}, timeout=30)
    assert r.status_code == 415
    assert "detail" in r.json()

def test_create_review_on_deleted_book():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 5, "reviewer_name": "Test"}, timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()

def test_create_order_insufficient_stock():
    book = create_book(stock=0)
    r = requests.post(f"{BASE_URL}/orders", json={"customer_name": "Test", "customer_email": "test@test.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_update_order_status_invalid_transition():
    book = create_book(stock=10)
    order_resp = requests.post(f"{BASE_URL}/orders", json={"customer_name": "Test", "customer_email": "test@test.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30)
    assert order_resp.status_code == 201
    order_id = order_resp.json()["id"]
    r = requests.patch(f"{BASE_URL}/orders/{order_id}/status", json={"status": "delivered"}, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_get_invoice_for_pending_order():
    book = create_book(stock=10)
    order_resp = requests.post(f"{BASE_URL}/orders", json={"customer_name": "Test", "customer_email": "test@test.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30)
    assert order_resp.status_code == 201
    order_id = order_resp.json()["id"]
    r = requests.get(f"{BASE_URL}/orders/{order_id}/invoice", timeout=30)
    assert r.status_code == 403
    assert "detail" in r.json()

def test_bulk_create_no_api_key():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=30)
    assert r.status_code == 401
    assert "detail" in r.json()

def test_statistics_summary_no_api_key():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=30)
    assert r.status_code == 401
    assert "detail" in r.json()

def test_toggle_maintenance_enable():
    r = requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": True}, headers={"X-API-Key": API_KEY}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["maintenance_mode"] is True
    # Always disable maintenance mode after test
    requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": False}, headers={"X-API-Key": API_KEY}, timeout=30)

def test_deprecated_catalog_redirect():
    r = requests.get(f"{BASE_URL}/catalog", timeout=30, allow_redirects=False)
    assert r.status_code == 301
    assert "location" in r.headers or "Location" in r.headers

def test_update_book_soft_deleted():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": "new title"}, timeout=30)
    assert r.status_code == 410
    assert "detail" in r.json()