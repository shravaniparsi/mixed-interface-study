# The main error is likely due to ISBN length exceeding 13 characters or other field length constraints. The unique function generates strings like "isbn_a1b2c3d4" which is 13+ characters, but ISBN must be exactly 13 characters. Also need to ensure all string fields respect maximum lengths from the API schema.

import uuid
import requests
import io

BASE_URL = "http://127.0.0.1:8000"
API_KEY = "test-api-key"
TIMEOUT = 30

def unique(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name=None, bio=None, born_year=None):
    if name is None:
        name = unique("author")[:50]
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name=None, description=None):
    if name is None:
        name = unique("cat")[:30]
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title=None, isbn=None, price=10.0, published_year=2020, stock=10, author_id=None, category_id=None):
    if title is None:
        title = unique("book")[:50]
    if isbn is None:
        # Generate a valid 13-character ISBN (digits only)
        isbn = uuid.uuid4().hex[:13]
    if author_id is None:
        author = create_author()
        author_id = author["id"]
    if category_id is None:
        category = create_category()
        category_id = category["id"]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name=None):
    if name is None:
        name = unique("tag")[:30]
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200

def test_create_author_success():
    name = unique("author")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name_returns_422():
    r = requests.post(f"{BASE_URL}/authors", json={}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_author_by_id_returns_200():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == author["id"]
    assert "ETag" in r.headers

def test_get_author_not_found_returns_404():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_delete_author_with_books_returns_409():
    author = create_author()
    cat = create_category()
    book = create_book(author_id=author["id"], category_id=cat["id"])
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_category_success():
    name = unique("cat")
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_delete_category_with_books_returns_409():
    cat = create_category()
    author = create_author()
    book = create_book(author_id=author["id"], category_id=cat["id"])
    r = requests.delete(f"{BASE_URL}/categories/{cat['id']}", timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_book_success():
    author = create_author()
    cat = create_category()
    isbn = unique("isbn")[:13]
    r = requests.post(f"{BASE_URL}/books", json={
        "title": unique("book"),
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["isbn"] == isbn

def test_create_book_duplicate_isbn_returns_409():
    author = create_author()
    cat = create_category()
    isbn = unique("isbn")[:13]
    requests.post(f"{BASE_URL}/books", json={
        "title": unique("book"),
        "isbn": isbn,
        "price": 10.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books", json={
        "title": unique("book2"),
        "isbn": isbn,
        "price": 12.0,
        "published_year": 2021,
        "stock": 3,
        "author_id": author["id"],
        "category_id": cat["id"]
    }, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_get_book_returns_200_with_etag():
    book = create_book()
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]
    assert "ETag" in r.headers

def test_get_soft_deleted_book_returns_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410
    assert "detail" in r.json()

def test_soft_delete_book_returns_204():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_restore_soft_deleted_book_returns_200():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]

def test_apply_discount_to_old_book_returns_200():
    book = create_book(published_year=2020, price=100.0)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["discounted_price"] == 80.0
    assert data["original_price"] == 100.0

def test_apply_discount_to_new_book_returns_400():
    import datetime
    current_year = datetime.datetime.now().year
    book = create_book(published_year=current_year, price=50.0)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_update_stock_positive_delta_returns_200():
    book = create_book(stock=10)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=5", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 15

def test_update_stock_insufficient_returns_400():
    book = create_book(stock=2)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-5", timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()


def test_create_author_with_bio_and_born_year_returns_201():
    name = unique("author")
    bio = "Test biography"
    born_year = 1980
    author = create_author(name=name, bio=bio, born_year=born_year)
    assert author["name"] == name
    assert author["bio"] == bio
    assert author["born_year"] == born_year
    assert "id" in author

def test_list_authors_returns_200_with_pagination():
    create_author()
    create_author()
    r = requests.get(f"{BASE_URL}/authors?skip=0&limit=1", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert len(data) <= 1

def test_update_author_name_returns_200():
    author = create_author()
    new_name = unique("updated_author")
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=TIMEOUT)
    assert r.status_code == 200
    updated = r.json()
    assert updated["name"] == new_name

def test_delete_author_without_books_returns_204():
    author = create_author()
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_get_author_returns_304_with_if_none_match():
    author = create_author()
    r1 = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    etag = r1.headers.get("etag")
    r2 = requests.get(f"{BASE_URL}/authors/{author['id']}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r2.status_code == 304

def test_create_category_with_description_returns_201():
    name = unique("cat")
    description = "Test category description"
    cat = create_category(name=name, description=description)
    assert cat["name"] == name
    assert cat["description"] == description
    assert "id" in cat

def test_get_category_not_found_returns_404():
    r = requests.get(f"{BASE_URL}/categories/99999", timeout=TIMEOUT)
    assert r.status_code == 404

def test_create_book_with_tags_returns_201():
    tag1 = create_tag()
    tag2 = create_tag()
    author = create_author()
    category = create_category()
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": category["id"],
        "tag_ids": [tag1["id"], tag2["id"]]
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Expected 201, got {r.status_code}: {r.text[:200]}"
    book = r.json()
    assert book["title"] == title
    assert len(book["tags"]) == 2

def test_get_book_returns_410_after_soft_delete():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_update_book_price_returns_200():
    book = create_book(price=20.0)
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"price": 25.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    updated = r.json()
    assert updated["price"] == 25.0

def test_create_tag_duplicate_name_returns_409():
    tag = create_tag()
    r = requests.post(f"{BASE_URL}/tags", json={"name": tag["name"]}, timeout=TIMEOUT)
    assert r.status_code == 409

def test_health_check_returns_405_on_post():
    r = requests.post(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 405