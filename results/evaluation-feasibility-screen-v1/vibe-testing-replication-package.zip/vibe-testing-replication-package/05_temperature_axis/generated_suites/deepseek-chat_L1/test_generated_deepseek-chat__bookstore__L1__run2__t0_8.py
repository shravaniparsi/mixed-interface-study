# The main error likely involves string length limits for fields like ISBN (must be exactly 13 characters) or other validation issues.
# Fix: ensure ISBN is exactly 13 characters, use proper unique generation, and handle all edge cases.

import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30
API_KEY = "test-api-key"

def unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name: str = None, bio: str = None, born_year: int = None) -> dict:
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name: str = None, description: str = None) -> dict:
    if name is None:
        name = unique("cat")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name: str = None) -> dict:
    if name is None:
        name = unique("tag")
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title: str = None, isbn: str = None, price: float = 10.0, published_year: int = 2020, stock: int = 10, author_id: int = None, category_id: int = None) -> dict:
    if title is None:
        title = unique("book")
    if isbn is None:
        # ISBN must be exactly 13 characters (ISBN-13 format)
        isbn = uuid.uuid4().hex[:13]
    if author_id is None:
        author = create_author()
        author_id = author["id"]
    if category_id is None:
        cat = create_category()
        category_id = cat["id"]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(customer_name: str = None, customer_email: str = None, items: list = None) -> dict:
    if customer_name is None:
        customer_name = unique("cust")
    if customer_email is None:
        customer_email = f"{uuid.uuid4().hex[:8]}@test.com"
    if items is None:
        book = create_book(stock=5)
        items = [{"book_id": book["id"], "quantity": 1}]
    payload = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items
    }
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_create_author_success():
    name = unique("author")
    bio = "Some bio"
    born_year = 1980
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": bio, "born_year": born_year}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == name
    assert data["bio"] == bio
    assert data["born_year"] == born_year

# Test 2: POST /authors - create_author_missing_name (error, 422)
def test_create_author_missing_name():
    r = requests.post(f"{BASE_URL}/authors", json={"bio": "no name"}, timeout=TIMEOUT)
    assert r.status_code == 422, f"Expected 422, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 3: GET /authors/{author_id} - get_author_not_found (error, 404)
def test_get_author_not_found():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 4: PUT /authors/{author_id} - update_author_etag_mismatch (error, 412)
def test_update_author_etag_mismatch():
    author = create_author()
    author_id = author["id"]
    r = requests.put(f"{BASE_URL}/authors/{author_id}", json={"name": unique("updated")}, headers={"If-Match": '"wrong-etag"'}, timeout=TIMEOUT)
    assert r.status_code == 412, f"Expected 412, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 5: POST /categories - create_category_duplicate_name (error, 409)
def test_create_category_duplicate_name():
    name = unique("catdup")
    create_category(name=name)
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409, f"Expected 409, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 6: POST /books - create_book_success (happy_path, 201)
def test_create_book_success():
    author = create_author()
    cat = create_category()
    title = unique("book")
    isbn = uuid.uuid4().hex[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.99,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["title"] == title
    assert data["isbn"] == isbn
    assert data["price"] == 15.99

# Test 7: POST /books - create_book_nonexistent_author (error, 404)
def test_create_book_nonexistent_author():
    cat = create_category()
    payload = {
        "title": unique("book"),
        "isbn": uuid.uuid4().hex[:13],
        "price": 10.0,
        "published_year": 2020,
        "author_id": 999999,
        "category_id": cat["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 8: GET /books/{book_id} - get_soft_deleted_book_returns_410 (error, 410)
def test_get_soft_deleted_book_returns_410():
    book = create_book()
    book_id = book["id"]
    requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    assert r.status_code == 410, f"Expected 410, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 9: DELETE /books/{book_id} - soft_delete_book_success (happy_path, 204)
def test_soft_delete_book_success():
    book = create_book()
    book_id = book["id"]
    r = requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    assert r.status_code == 204, f"Expected 204, got {r.status_code}: {r.text[:200]}"

# Test 10: POST /books/{book_id}/restore - restore_alive_book_returns_400 (error, 400)
def test_restore_alive_book_returns_400():
    book = create_book()
    book_id = book["id"]
    r = requests.post(f"{BASE_URL}/books/{book_id}/restore", timeout=TIMEOUT)
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 11: POST /books/{book_id}/reviews - create_review_on_deleted_book_returns_410 (error, 410)
def test_create_review_on_deleted_book_returns_410():
    book = create_book()
    book_id = book["id"]
    requests.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
    payload = {"rating": 5, "reviewer_name": unique("rev")}
    r = requests.post(f"{BASE_URL}/books/{book_id}/reviews", json=payload, timeout=TIMEOUT)
    assert r.status_code == 410, f"Expected 410, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 12: POST /books/{book_id}/discount - discount_recent_book_returns_400 (error, 400)
def test_discount_recent_book_returns_400():
    book = create_book(published_year=2026)
    book_id = book["id"]
    payload = {"discount_percent": 10}
    r = requests.post(f"{BASE_URL}/books/{book_id}/discount", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 13: PATCH /books/{book_id}/stock - update_stock_negative_result_returns_400 (error, 400)
def test_update_stock_negative_result_returns_400():
    book = create_book(stock=2)
    book_id = book["id"]
    r = requests.patch(f"{BASE_URL}/books/{book_id}/stock?quantity=-5", timeout=TIMEOUT)
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 14: POST /books/{book_id}/cover - upload_cover_unsupported_type_returns_415 (error, 415)
def test_upload_cover_unsupported_type_returns_415():
    book = create_book()
    book_id = book["id"]
    files = {"file": ("test.txt", b"fake image content", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 415, f"Expected 415, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 15: POST /tags - create_tag_success (happy_path, 201)
def test_create_tag_success():
    name = unique("tag")
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == name

# Test 16: POST /books/{book_id}/tags - add_tags_to_book_success (happy_path, 200)
def test_add_tags_to_book_success():
    book = create_book()
    tag = create_tag()
    book_id = book["id"]
    r = requests.post(f"{BASE_URL}/books/{book_id}/tags", json={"tag_ids": [tag["id"]]}, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "tags" in data
    tag_ids = [t["id"] for t in data["tags"]]
    assert tag["id"] in tag_ids

# Test 17: POST /orders - create_order_insufficient_stock_returns_400 (error, 400)
def test_create_order_insufficient_stock_returns_400():
    book = create_book(stock=0)
    payload = {
        "customer_name": unique("cust"),
        "customer_email": f"{uuid.uuid4().hex[:8]}@test.com",
        "items": [{"book_id": book["id"], "quantity": 1}]
    }
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 18: PATCH /orders/{order_id}/status - update_order_status_invalid_transition (error, 400)
def test_update_order_status_invalid_transition():
    book = create_book(stock=5)
    order = create_order(items=[{"book_id": book["id"], "quantity": 1}])
    order_id = order["id"]
    payload = {"status": "delivered"}
    r = requests.patch(f"{BASE_URL}/orders/{order_id}/status", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 19: POST /orders/{order_id}/items - add_item_to_non_pending_order_returns_403 (error, 403)
def test_add_item_to_non_pending_order_returns_403():
    book = create_book(stock=10)
    order = create_order(items=[{"book_id": book["id"], "quantity": 1}])
    order_id = order["id"]
    # Confirm order
    requests.patch(f"{BASE_URL}/orders/{order_id}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    book2 = create_book(stock=5)
    r = requests.post(f"{BASE_URL}/orders/{order_id}/items", json={"book_id": book2["id"], "quantity": 1}, timeout=TIMEOUT)
    assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 20: GET /orders/{order_id}/invoice - get_invoice_pending_order_returns_403 (error, 403)
def test_get_invoice_pending_order_returns_403():
    book = create_book(stock=5)
    order = create_order(items=[{"book_id": book["id"], "quantity": 1}])
    order_id = order["id"]
    r = requests.get(f"{BASE_URL}/orders/{order_id}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 21: POST /books/bulk - bulk_create_partial_success_returns_207 (edge_case, 207)
def test_bulk_create_partial_success_returns_207():
    author = create_author()
    cat = create_category()
    valid_book = {
        "title": unique("book"),
        "isbn": uuid.uuid4().hex[:13],
        "price": 10.0,
        "published_year": 2020,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    invalid_book = {
        "title": "",
        "isbn": "123",
        "price": -5,
        "published_year": 3000,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    payload = {"books": [valid_book, invalid_book]}
    headers = {"X-API-Key": API_KEY}
    r = requests.post(f"{BASE_URL}/books/bulk", json=payload, headers=headers, timeout=TIMEOUT)
    assert r.status_code == 207, f"Expected 207, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "results" in data

# Test 22: POST /books/bulk - bulk_create_missing_api_key_returns_401 (error, 401)
def test_bulk_create_missing_api_key_returns_401():
    payload = {"books": []}
    r = requests.post(f"{BASE_URL}/books/bulk", json=payload, timeout=TIMEOUT)
    assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 23: POST /books/{book_id}/clone - clone_book_duplicate_isbn_returns_409 (error, 409)
def test_clone_book_duplicate_isbn_returns_409():
    book = create_book()
    book_id = book["id"]
    isbn = book["isbn"]
    payload = {"new_isbn": isbn}
    r = requests.post(f"{BASE_URL}/books/{book_id}/clone", json=payload, timeout=TIMEOUT)
    assert r.status_code == 409, f"Expected 409, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 24: POST /exports/books - export_books_no_api_key_returns_401 (error, 401)
def test_export_books_no_api_key_returns_401():
    r = requests.post(f"{BASE_URL}/exports/books", timeout=TIMEOUT)
    assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 25: GET /exports/{job_id} - get_export_job_not_found_returns_404 (error, 404)
def test_get_export_job_not_found_returns_404():
    r = requests.get(f"{BASE_URL}/exports/nonexistent_job_id", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 26: GET /statistics/summary - statistics_summary_success (happy_path, 200)
def test_statistics_summary_success():
    headers = {"X-API-Key": API_KEY}
    r = requests.get(f"{BASE_URL}/statistics/summary", headers=headers, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "total_books" in data
    assert "total_authors" in data

# Test 27: POST /admin/maintenance - toggle_maintenance_no_api_key_returns_401 (error, 401)
def test_toggle_maintenance_no_api_key_returns_401():
    payload = {"enabled": True}
    r = requests.post(f"{BASE_URL}/admin/maintenance", json=payload, timeout=TIMEOUT)
    assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()

# Test 28: GET /health - health_check_returns_200 (happy_path, 200)
def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"

# Test 29: GET /catalog - catalog_redirects_to_books_returns_301 (edge_case, 301)
def test_catalog_redirects_to_books_returns_301():
    r = requests.get(f"{BASE_URL}/catalog", timeout=TIMEOUT, allow_redirects=False)
    assert r.status_code == 301, f"Expected 301, got {r.status_code}: {r.text[:200]}"
    assert "location" in r.headers or "Location" in r.headers

# Test 30: DELETE /authors/{author_id} - delete_author_with_books_returns_409 (error, 409)
def test_delete_author_with_books_returns_409():
    author = create_author()
    cat = create_category()
    create_book(author_id=author["id"], category_id=cat["id"])
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 409, f"Expected 409, got {r.status_code}: {r.text[:200]}"
    assert "detail" in r.json()