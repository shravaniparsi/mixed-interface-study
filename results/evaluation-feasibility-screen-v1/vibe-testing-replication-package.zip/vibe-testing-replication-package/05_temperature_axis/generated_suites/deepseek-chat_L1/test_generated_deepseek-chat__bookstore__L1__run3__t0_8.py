import requests
import uuid
import time

BASE_URL = "http://127.0.0.1:8000"
API_KEY = "test-api-key"

def unique(prefix: str) -> str:
    return f'{prefix}_{uuid.uuid4().hex[:8]}'

def create_author(session, name=None, bio=None, born_year=None):
    if name is None:
        name = unique("author")
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = session.post(f"{BASE_URL}/authors", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(session, name=None, description=None):
    if name is None:
        name = unique("cat")
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = session.post(f"{BASE_URL}/categories", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(session, name=None):
    if name is None:
        name = unique("tag")
    payload = {"name": name}
    r = session.post(f"{BASE_URL}/tags", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(session, author_id, category_id, title=None, isbn=None, price=10.0, published_year=2020, stock=10):
    if title is None:
        title = unique("book")
    if isbn is None:
        isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id
    }
    r = session.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(session, customer_name, customer_email, items):
    payload = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items
    }
    r = session.post(f"{BASE_URL}/orders", json=payload, timeout=30)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=30)
    assert r.status_code == 200

def test_create_author_happy_path():
    name = unique("author")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_missing_name():
    r = requests.post(f"{BASE_URL}/authors", json={}, timeout=30)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_list_authors_with_skip_limit():
    s = requests.Session()
    name1 = unique("author")
    name2 = unique("author")
    create_author(s, name=name1)
    create_author(s, name=name2)
    r = s.get(f"{BASE_URL}/authors", params={"skip": 0, "limit": 100}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    names = [a["name"] for a in data]
    assert name1 in names
    assert name2 in names

def test_get_author_by_id_found():
    s = requests.Session()
    author = create_author(s)
    r = s.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == author["id"]

def test_get_author_by_id_not_found():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=30)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_author_with_books_conflict():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 409
    data = r.json()
    assert "detail" in data

def test_create_category_happy_path():
    name = unique("cat")
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_list_categories_returns_array():
    s = requests.Session()
    name = unique("cat")
    create_category(s, name=name)
    r = s.get(f"{BASE_URL}/categories", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    names = [c["name"] for c in data]
    assert name in names

def test_get_category_etag_header():
    s = requests.Session()
    cat = create_category(s)
    r = s.get(f"{BASE_URL}/categories/{cat['id']}", timeout=30)
    assert r.status_code == 200
    assert "ETag" in r.headers or "etag" in r.headers

def test_create_book_happy_path():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    title = unique("book")
    isbn = unique("isbn")[:13]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": 15.0,
        "published_year": 2021,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    r = s.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["title"] == title

def test_create_book_duplicate_isbn():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    isbn = unique("isbn")[:13]
    create_book(s, author["id"], cat["id"], isbn=isbn)
    payload = {
        "title": unique("book"),
        "isbn": isbn,
        "price": 20.0,
        "published_year": 2022,
        "stock": 3,
        "author_id": author["id"],
        "category_id": cat["id"]
    }
    r = s.post(f"{BASE_URL}/books", json=payload, timeout=30)
    assert r.status_code == 409
    data = r.json()
    assert "detail" in data

def test_list_books_pagination_and_filters():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    title = unique("book")
    create_book(s, author["id"], cat["id"], title=title)
    r = s.get(f"{BASE_URL}/books", params={"page": 1, "page_size": 10, "search": title}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data
    assert data["total"] >= 1

def test_get_book_soft_deleted_returns_410():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204
    r2 = s.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r2.status_code == 410
    data = r2.json()
    assert "detail" in data

def test_update_book_etag_mismatch():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    etag = r.headers.get("ETag") or r.headers.get("etag", "")
    wrong_etag = '"wrong"'
    update_payload = {"title": unique("book")}
    r2 = s.put(f"{BASE_URL}/books/{book['id']}", json=update_payload, headers={"If-Match": wrong_etag}, timeout=30)
    assert r2.status_code == 412
    data = r2.json()
    assert "detail" in data

def test_soft_delete_book_returns_204():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204

def test_restore_book_not_deleted():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_create_review_on_deleted_book():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    r = s.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204
    review_payload = {"rating": 5, "reviewer_name": "Test"}
    r2 = s.post(f"{BASE_URL}/books/{book['id']}/reviews", json=review_payload, timeout=30)
    assert r2.status_code == 410
    data = r2.json()
    assert "detail" in data

def test_apply_discount_recent_book():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], published_year=2026)
    r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_apply_discount_rate_limit():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], published_year=2020)
    status_codes = []
    for _ in range(6):
        r = s.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=30)
        status_codes.append(r.status_code)
        if r.status_code == 429:
            break
    assert 429 in status_codes

def test_update_stock_insufficient():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=0)
    r = s.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-1", timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_upload_cover_unsupported_type():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"])
    files = {"file": ("test.txt", b"test content", "text/plain")}
    r = s.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=30)
    assert r.status_code == 415
    data = r.json()
    assert "detail" in data

def test_create_tag_duplicate_name():
    s = requests.Session()
    name = unique("tag")
    create_tag(s, name=name)
    r = s.post(f"{BASE_URL}/tags", json={"name": name}, timeout=30)
    assert r.status_code == 409
    data = r.json()
    assert "detail" in data

def test_create_order_insufficient_stock():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=0)
    r = s.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test",
        "customer_email": "test@test.com",
        "items": [{"book_id": book["id"], "quantity": 1}]
    }, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_list_orders_status_filter():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    order = create_order(s, "Test", "test@test.com", [{"book_id": book["id"], "quantity": 1}])
    r = s.get(f"{BASE_URL}/orders", params={"status": "pending"}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    order_ids = [o["id"] for o in data["items"]]
    assert order["id"] in order_ids

def test_delete_non_pending_order():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    order = create_order(s, "Test", "test@test.com", [{"book_id": book["id"], "quantity": 1}])
    r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=30)
    assert r.status_code == 200
    r2 = s.delete(f"{BASE_URL}/orders/{order['id']}", timeout=30)
    assert r2.status_code == 400
    data = r2.json()
    assert "detail" in data

def test_update_order_status_invalid_transition():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    order = create_order(s, "Test", "test@test.com", [{"book_id": book["id"], "quantity": 1}])
    r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_add_item_to_non_pending_order():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book1 = create_book(s, author["id"], cat["id"], stock=10)
    book2 = create_book(s, author["id"], cat["id"], stock=10)
    order = create_order(s, "Test", "test@test.com", [{"book_id": book1["id"], "quantity": 1}])
    r = s.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=30)
    assert r.status_code == 200
    r2 = s.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book2["id"], "quantity": 1}, timeout=30)
    assert r2.status_code == 403
    data = r2.json()
    assert "detail" in data

def test_get_invoice_for_pending_order():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    book = create_book(s, author["id"], cat["id"], stock=10)
    order = create_order(s, "Test", "test@test.com", [{"book_id": book["id"], "quantity": 1}])
    r = s.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=30)
    assert r.status_code == 403
    data = r.json()
    assert "detail" in data

def test_bulk_create_missing_api_key():
    s = requests.Session()
    author = create_author(s)
    cat = create_category(s)
    payload = {
        "books": [{
            "title": unique("book"),
            "isbn": unique("isbn")[:13],
            "price": 10.0,
            "published_year": 2020,
            "stock": 1,
            "author_id": author["id"],
            "category_id": cat["id"]
        }]
    }
    r = s.post(f"{BASE_URL}/books/bulk", json=payload, timeout=30)
    assert r.status_code == 401
    data = r.json()
    assert "detail" in data