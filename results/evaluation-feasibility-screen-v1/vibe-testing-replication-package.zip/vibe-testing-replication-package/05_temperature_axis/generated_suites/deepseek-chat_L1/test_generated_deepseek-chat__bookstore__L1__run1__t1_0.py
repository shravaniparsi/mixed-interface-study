# The main issue: unique() generates strings with prefix + underscore + 8 hex chars which can exceed field length limits.
# Also helper functions must match API schema exactly - using correct field names, types and required fields.

import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30

def unique(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name=None, bio=None, born_year=None):
    if name is None:
        name = unique("author")
    # Truncate name if too long for API (max 100 chars typically)
    if len(name) > 100:
        name = name[:100]
    payload = {"name": name}
    if bio is not None:
        payload["bio"] = bio
    if born_year is not None:
        payload["born_year"] = born_year
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name=None, description=None):
    if name is None:
        name = unique("category")
    if len(name) > 100:
        name = name[:100]
    payload = {"name": name}
    if description is not None:
        payload["description"] = description
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(title=None, isbn=None, price=10.0, published_year=2020, stock=10, author_id=None, category_id=None):
    if title is None:
        title = unique("book")
    if len(title) > 200:
        title = title[:200]
    if isbn is None:
        isbn = f"978{uuid.uuid4().hex[:9]}"
    if author_id is None:
        author_id = create_author()["id"]
    if category_id is None:
        category_id = create_category()["id"]
    payload = {
        "title": title,
        "isbn": isbn,
        "price": price,
        "published_year": published_year,
        "stock": stock,
        "author_id": author_id,
        "category_id": category_id,
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_tag(name=None):
    if name is None:
        name = unique("tag")
    if len(name) > 50:
        name = name[:50]
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_order(customer_name=None, customer_email=None, items=None):
    if customer_name is None:
        customer_name = unique("cust")
    if len(customer_name) > 100:
        customer_name = customer_name[:100]
    if customer_email is None:
        customer_email = f"{unique('email')}@example.com"
    if len(customer_email) > 100:
        customer_email = customer_email[:100]
    if items is None:
        book = create_book(stock=5)
        items = [{"book_id": book["id"], "quantity": 2}]
    payload = {
        "customer_name": customer_name,
        "customer_email": customer_email,
        "items": items,
    }
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_health_check_returns_200():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200
    assert isinstance(r.json(), dict)

def test_create_author_minimal_fields():
    name = unique("author")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_get_author_success():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert data["id"] == author["id"]

def test_get_nonexistent_author_returns_404():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_create_author_missing_name_returns_422():
    r = requests.post(f"{BASE_URL}/authors", json={}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_authors_with_default_pagination():
    create_author()
    r = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_delete_author_with_no_books_returns_204():
    author = create_author()
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 204
    r_get = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 404

def test_create_category_success():
    name = unique("cat")
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_duplicate_category_name_returns_409():
    name = unique("catdup")
    requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_get_category_with_etag_returns_200():
    cat = create_category()
    r = requests.get(f"{BASE_URL}/categories/{cat['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    assert "ETag" in r.headers or "etag" in r.headers

def test_get_category_not_modified_returns_304():
    cat = create_category()
    r = requests.get(f"{BASE_URL}/categories/{cat['id']}", timeout=TIMEOUT)
    etag = r.headers.get("ETag") or r.headers.get("etag")
    r2 = requests.get(f"{BASE_URL}/categories/{cat['id']}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r2.status_code == 304

def test_create_book_valid_data():
    author = create_author()
    cat = create_category()
    payload = {
        "title": unique("book"),
        "isbn": f"978{uuid.uuid4().hex[:9]}",
        "price": 15.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["title"] == payload["title"]

def test_create_book_duplicate_isbn_returns_409():
    author = create_author()
    cat = create_category()
    isbn = f"978{uuid.uuid4().hex[:9]}"
    payload1 = {
        "title": unique("book1"),
        "isbn": isbn,
        "price": 10.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    requests.post(f"{BASE_URL}/books", json=payload1, timeout=TIMEOUT)
    payload2 = {
        "title": unique("book2"),
        "isbn": isbn,
        "price": 20.0,
        "published_year": 2021,
        "stock": 3,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    r = requests.post(f"{BASE_URL}/books", json=payload2, timeout=TIMEOUT)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_get_active_book_returns_200():
    book = create_book()
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert data["id"] == book["id"]

def test_soft_delete_book_returns_204():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_get_soft_deleted_book_returns_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410
    assert "detail" in r.json()

def test_restore_soft_deleted_book_returns_200():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["id"] == book["id"]
    r_get = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 200

def test_restore_active_book_returns_400():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_apply_discount_old_book_returns_200():
    author = create_author()
    cat = create_category()
    payload = {
        "title": unique("oldbook"),
        "isbn": f"978{uuid.uuid4().hex[:9]}",
        "price": 100.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    book = r.json()
    r_disc = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 20}, timeout=TIMEOUT)
    assert r_disc.status_code == 200
    data = r_disc.json()
    assert "discounted_price" in data
    assert data["original_price"] == 100.0
    assert data["discount_percent"] == 20

def test_apply_discount_new_book_returns_400():
    author = create_author()
    cat = create_category()
    payload = {
        "title": unique("newbook"),
        "isbn": f"978{uuid.uuid4().hex[:9]}",
        "price": 50.0,
        "published_year": 2026,
        "stock": 5,
        "author_id": author["id"],
        "category_id": cat["id"],
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    book = r.json()
    r_disc = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r_disc.status_code == 400
    assert "detail" in r_disc.json()

def test_update_stock_positive_quantity():
    book = create_book(stock=5)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=3", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["stock"] == 8

def test_update_stock_negative_quantity_insufficient():
    book = create_book(stock=2)
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-5", timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_create_review_valid():
    book = create_book()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 5, "reviewer_name": unique("rev")}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["rating"] == 5

def test_create_review_soft_deleted_book_returns_410():
    book = create_book()
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 3, "reviewer_name": unique("rev")}, timeout=TIMEOUT)
    assert r.status_code == 410
    assert "detail" in r.json()

def test_create_tag_success():
    name = unique("tag")
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_add_tags_to_book():
    book = create_book()
    tag = create_tag()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [tag["id"]]}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "tags" in data
    tag_ids = [t["id"] for t in data["tags"]]
    assert tag["id"] in tag_ids

def test_create_order_valid():
    book = create_book(stock=10)
    r = requests.post(f"{BASE_URL}/orders", json={"customer_name": unique("cust"), "customer_email": f"{unique('email')}@test.com", "items": [{"book_id": book["id"], "quantity": 2}]}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert data["status"] == "pending"

def test_update_order_status_pending_to_confirmed():
    order = create_order()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "confirmed"

def test_update_order_status_invalid_transition():
    order = create_order()
    requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "pending"}, timeout=TIMEOUT)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_delete_pending_order():
    book = create_book(stock=10)
    order = create_order(items=[{"book_id": book["id"], "quantity": 2}])
    r = requests.delete(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    assert r.status_code == 204
    r_get = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 404
    r_book = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r_book.json()["stock"] == 10