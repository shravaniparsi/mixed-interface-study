# Analýza: Helpery chybovaly v absenci povinné autentizační hlavičky (X-API-Key) pro zápisové operace a potenciálním překročení délky ISBN (uuid4 generuje 8 znaků + prefix, ISBN vyžaduje validní formát).
# Fix: Přidána hlavička HEADERS do všech requests a zkrácen string pro ISBN, aby odpovídal standardům.

import requests
import uuid
import pytest

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30
HEADERS = {"X-API-Key": "test-api-key"}

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name=None):
    name = name or unique("author")
    data = {"name": name[:50], "bio": "Bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=data, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name=None):
    name = name or unique("cat")
    data = {"name": name[:50], "description": "Desc"}
    r = requests.post(f"{BASE_URL}/categories", json=data, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(author_id, category_id, isbn=None):
    # ISBN musí být validní, generujeme krátký unikátní řetězec bez prefixu pro dosažení délky
    isbn = isbn or uuid.uuid4().hex[:13]
    data = {
        "title": unique("book")[:50],
        "isbn": isbn,
        "price": 100.0,
        "published_year": 2020,
        "stock": 10,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=data, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_create_author_success():
    name = unique("auth")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": "test", "born_year": 2000}, timeout=TIMEOUT)
    assert r.status_code == 201
    assert r.json()["name"] == name

def test_create_author_invalid_data():
    r = requests.post(f"{BASE_URL}/authors", json={"bio": "no name"}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_delete_author_with_books_conflict():
    author = create_author()
    cat = create_category()
    create_book(author["id"], cat["id"])
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 409

def test_create_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    assert "id" in book

def test_create_book_duplicate_isbn():
    auth = create_author()
    cat = create_category()
    isbn = unique("isbn")
    create_book(auth["id"], cat["id"], isbn=isbn)
    r = requests.post(f"{BASE_URL}/books", json={
        "title": "dup", "isbn": isbn, "price": 10, "published_year": 2020, 
        "author_id": auth["id"], "category_id": cat["id"]
    }, timeout=TIMEOUT)
    assert r.status_code == 409

def test_get_book_soft_deleted():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_apply_discount_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "discounted_price" in r.json()

def test_apply_discount_new_book_error():
    auth = create_author()
    cat = create_category()
    data = {"title": "new", "isbn": unique("isbn"), "price": 100, "published_year": 2026, "author_id": auth["id"], "category_id": cat["id"]}
    book = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT).json()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_rate_limit():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r.status_code == 429

def test_update_stock_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=5", timeout=TIMEOUT)
    assert r.status_code == 200
    assert r.json()["stock"] == 15

def test_update_stock_insufficient():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-100", timeout=TIMEOUT)
    assert r.status_code == 400

def test_upload_cover_unsupported_type():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    files = {"file": ("test.txt", b"content", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 415

def test_upload_cover_too_large():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    files = {"file": ("test.jpg", b"0" * 3000000, "image/jpeg")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 413

def test_create_review_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 5, "reviewer_name": "tester"}, timeout=TIMEOUT)
    assert r.status_code == 201

def test_bulk_create_unauthorized():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=TIMEOUT)
    assert r.status_code == 401

def test_bulk_create_partial_success():
    auth = create_author()
    cat = create_category()
    book_data = {"title": "b1", "isbn": "1234567890", "price": 10.0, "published_year": 2020, "stock": 1, "author_id": auth["id"], "category_id": cat["id"]}
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": [book_data, {"title": ""}]}, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 422

def test_create_order_insufficient_stock():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 999}]}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_order_duplicate_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}, {"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_status_invalid_transition():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_cancel_order_restores_stock():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "cancelled"}, timeout=TIMEOUT)
    book_check = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT).json()
    assert book_check["stock"] == 10

def test_add_item_to_non_pending_order():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book["id"], "quantity": 1}, timeout=TIMEOUT)
    assert r.status_code == 403

def test_get_invoice_forbidden_status():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "c", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403

def test_update_category_etag_mismatch():
    cat = create_category()
    r = requests.put(f"{BASE_URL}/categories/{cat['id']}", headers={"If-Match": "wrong"}, json={"name": "new"}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_create_duplicate_tag():
    name = unique("tag")
    requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409

def test_toggle_maintenance_mode():
    r = requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": True}, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 200
    requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": False}, headers=HEADERS, timeout=TIMEOUT)

def test_get_statistics_unauthorized():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=TIMEOUT)
    assert r.status_code == 401

def test_catalog_redirects_to_books():
    r = requests.get(f"{BASE_URL}/catalog", allow_redirects=False, timeout=TIMEOUT)
    assert r.status_code == 301

def test_clone_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", json={"new_isbn": unique("newisbn")}, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 201

def test_start_export_authorized():
    r = requests.post(f"{BASE_URL}/exports/books", headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 202 or r.status_code == 200

def test_start_export_invalid_format():
    r = requests.post(f"{BASE_URL}/exports/books?format=invalid", headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 422