# Analýza: Chyby v helperech byly způsobeny kolizemi v unikátních datech (ISBN) a potenciálně chybějícími hlavičkami. 
# Fix: ISBN generuji pomocí unikátního řetězce, aby nedocházelo k 422/409 chybám při opakovaném spuštění testů.

import requests
import uuid
import pytest

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author(name=None):
    if name is None: name = unique("author")
    # API vyžaduje validní data, přidána unikátnost pro jméno
    payload = {"name": name, "bio": "bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(name=None):
    if name is None: name = unique("cat")
    payload = {"name": name, "description": "desc"}
    r = requests.post(f"{BASE_URL}/categories", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(author_id, category_id, isbn=None):
    # ISBN musí být unikátní, jinak API vrací 422/409
    if isbn is None: 
        isbn = str(uuid.uuid4().int)[:13]
    payload = {
        "title": unique("book"), 
        "isbn": isbn, 
        "price": 100.0, 
        "published_year": 2020, 
        "stock": 10,
        "author_id": author_id, 
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201, f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()


def test_create_author_success():
    name = unique("auth")
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": "test", "born_year": 2000}, timeout=TIMEOUT)
    assert r.status_code == 201
    data = r.json()
    assert data["name"] == name
    assert "id" in data

def test_create_author_invalid_data():
    r = requests.post(f"{BASE_URL}/authors", json={"bio": "missing_name"}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_update_author_etag_mismatch():
    auth = create_author()
    r = requests.put(f"{BASE_URL}/authors/{auth['id']}", json={"name": unique("new")}, headers={"If-Match": "wrong-etag"}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_create_book_success():
    auth = create_author()
    cat = create_category()
    r = requests.post(f"{BASE_URL}/books", json={
        "title": "Test Book", "isbn": "1234567890", "price": 10.0, "published_year": 2020, "stock": 5,
        "author_id": auth['id'], "category_id": cat['id']
    }, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_book_duplicate_isbn():
    auth = create_author()
    cat = create_category()
    isbn = "1111111111"
    create_book(auth['id'], cat['id'], isbn=isbn)
    r = requests.post(f"{BASE_URL}/books", json={
        "title": "Dup", "isbn": isbn, "price": 10.0, "published_year": 2020, "author_id": auth['id'], "category_id": cat['id']
    }, timeout=TIMEOUT)
    assert r.status_code == 409

def test_list_books_pagination():
    r = requests.get(f"{BASE_URL}/books?page=1&page_size=1", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert data["page"] == 1

def test_list_books_filter_price():
    r = requests.get(f"{BASE_URL}/books?min_price=0&max_price=1000", timeout=TIMEOUT)
    assert r.status_code == 200
    assert isinstance(r.json()["items"], list)

def test_get_soft_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_restore_active_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 422

def test_apply_discount_new_book():
    auth = create_author()
    cat = create_category()
    r = requests.post(f"{BASE_URL}/books", json={
        "title": "New", "isbn": "9876543210", "price": 100, "published_year": 2026, "author_id": auth['id'], "category_id": cat['id']
    }, timeout=TIMEOUT)
    book_id = r.json()['id']
    r_disc = requests.post(f"{BASE_URL}/books/{book_id}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r_disc.status_code == 400

def test_apply_discount_rate_limit():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10}, timeout=TIMEOUT)
    assert r.status_code == 429

def test_update_stock_insufficient():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock", json={"quantity": -999}, timeout=TIMEOUT)
    assert r.status_code == 422

def test_upload_cover_invalid_type():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    files = {"file": ("test.txt", "content", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 422

def test_create_review_invalid_rating():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json={"rating": 10, "reviewer_name": "Test"}, timeout=TIMEOUT)
    assert r.status_code == 422

def test_bulk_create_unauthorized():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=TIMEOUT)
    assert r.status_code == 401

def test_create_order_insufficient_stock():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test", "customer_email": "a@b.cz", "items": [{"book_id": book['id'], "quantity": 999}]
    }, timeout=TIMEOUT)
    assert r.status_code == 422

def test_create_order_duplicate_items():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test", "customer_email": "a@b.cz", "items": [{"book_id": book['id'], "quantity": 1}, {"book_id": book['id'], "quantity": 1}]
    }, timeout=TIMEOUT)
    assert r.status_code == 422

def test_invalid_status_transition():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    order = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test", "customer_email": "a@b.cz", "items": [{"book_id": book['id'], "quantity": 1}]
    }, timeout=TIMEOUT).json()
    requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "pending"}, timeout=TIMEOUT)
    assert r.status_code == 422

def test_get_invoice_forbidden_status():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    order = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test", "customer_email": "a@b.cz", "items": [{"book_id": book['id'], "quantity": 1}]
    }, timeout=TIMEOUT).json()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403

def test_add_item_to_non_pending_order():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    order = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": "Test", "customer_email": "a@b.cz", "items": [{"book_id": book['id'], "quantity": 1}]
    }, timeout=TIMEOUT).json()
    requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book['id'], "quantity": 1}, timeout=TIMEOUT)
    assert r.status_code == 403

def test_start_export_success():
    r = requests.post(f"{BASE_URL}/exports/books", headers={"X-API-Key": "admin-secret-key"}, timeout=TIMEOUT)
    assert r.status_code == 202

def test_get_nonexistent_export():
    r = requests.get(f"{BASE_URL}/exports/nonexistent", timeout=TIMEOUT)
    assert r.status_code == 404

def test_toggle_maintenance_success():
    r = requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": True}, headers={"X-API-Key": "test-api-key"}, timeout=TIMEOUT)
    assert r.status_code == 200
    requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": False}, headers={"X-API-Key": "test-api-key"}, timeout=TIMEOUT)

def test_get_stats_unauthorized():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=TIMEOUT)
    assert r.status_code == 401

def test_create_duplicate_tag():
    name = unique("tag")
    requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409

def test_clone_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth['id'], cat['id'])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", json={"new_isbn": "1234567899"}, timeout=TIMEOUT)
    assert r.status_code == 201

def test_delete_category_with_books():
    auth = create_author()
    cat = create_category()
    create_book(auth['id'], cat['id'])
    r = requests.delete(f"{BASE_URL}/categories/{cat['id']}", timeout=TIMEOUT)
    assert r.status_code == 409

def test_health_check_success():
    r = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert r.status_code == 200

def test_catalog_redirect():
    r = requests.get(f"{BASE_URL}/catalog", allow_redirects=False, timeout=TIMEOUT)
    assert r.status_code == 301

def test_get_reviews_malformed_id():
    r = requests.get(f"{BASE_URL}/books/abc/reviews", timeout=TIMEOUT)
    assert r.status_code == 422