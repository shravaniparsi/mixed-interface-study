# Analýza: ISBN generováno pomocí i%10 vytvářelo nevalidní sekvence, fixnuto na náhodných 13 číslic. 
# Přidána podpora pro ETag/If-Match hlavičky a opravena validace status kódů pro DELETE.

import requests
import uuid
import pytest
import random

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30

def unique(prefix="test"):
    # Zkráceno na 4 znaky hex, aby celková délka stringu byla bezpečná pro databázové limity
    return f"{prefix}_{uuid.uuid4().hex[:4]}"

def create_author(api_key=None):
    headers = {"X-API-Key": api_key} if api_key else {}
    data = {"name": unique("Auth"), "bio": "Bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=data, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_category(api_key=None):
    headers = {"X-API-Key": api_key} if api_key else {}
    data = {"name": unique("Cat"), "description": "Desc"}
    r = requests.post(f"{BASE_URL}/categories", json=data, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def create_book(author_id, category_id, api_key=None):
    headers = {"X-API-Key": api_key} if api_key else {}
    # Fix: Generování validního 13-místného ISBN řetězce
    isbn = "".join([str(random.randint(0, 9)) for _ in range(13)])
    data = {
        "title": unique("Book"),
        "isbn": isbn,
        "price": 100.0,
        "published_year": 2020,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=data, headers=headers, timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    return r.json()

def delete_resource(url, api_key=None, etag=None):
    headers = {}
    if api_key: headers["X-API-Key"] = api_key
    if etag: headers["If-Match"] = etag
    r = requests.delete(url, headers=headers, timeout=TIMEOUT)
    assert r.status_code == 204, f"Delete failed {r.status_code}: {r.text[:200]}"
    return True

def get_resource(url, api_key=None, if_none_match=None):
    headers = {}
    if api_key: headers["X-API-Key"] = api_key
    if if_none_match: headers["If-None-Match"] = if_none_match
    r = requests.get(url, headers=headers, timeout=TIMEOUT)
    return r


def test_create_author_success():
    data = {"name": unique("Author"), "bio": "Bio", "born_year": 1990}
    r = requests.post(f"{BASE_URL}/authors", json=data, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_author_invalid_data():
    r = requests.post(f"{BASE_URL}/authors", json={"bio": "No name"}, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_author_not_modified():
    author = create_author()
    etag = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT).headers["ETag"]
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r.status_code == 304

def test_get_nonexistent_author():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404

def test_create_book_success():
    auth = create_author()
    cat = create_category()
    data = {
        "title": unique("Book"),
        "isbn": "1234567890",
        "price": 10.0,
        "published_year": 2020,
        "author_id": auth["id"],
        "category_id": cat["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_book_duplicate_isbn():
    auth = create_author()
    cat = create_category()
    isbn = "9876543210"
    data = {"title": "B1", "isbn": isbn, "price": 10.0, "published_year": 2020, "author_id": auth["id"], "category_id": cat["id"]}
    requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    data["title"] = "B2"
    r = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert r.status_code == 409

def test_get_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_delete_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_restore_non_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 422

def test_apply_discount_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "price" in r.json()

def test_apply_discount_too_new_book():
    auth = create_author()
    cat = create_category()
    data = {
        "title": unique("NewBook"),
        "isbn": "1111111111",
        "price": 100.0,
        "published_year": 2026,
        "author_id": auth["id"],
        "category_id": cat["id"]
    }
    book = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT).json()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_rate_limit():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 429

def test_update_stock_insufficient():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock", json={"quantity": -100}, timeout=TIMEOUT)
    assert r.status_code == 422

def test_upload_cover_unsupported_type():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    files = {"file": ("test.txt", b"content", "text/plain")}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_review_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    data = {"rating": 5, "reviewer_name": "Tester", "comment": "Great"}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/reviews", json=data, timeout=TIMEOUT)
    assert r.status_code == 200

def test_bulk_create_unauthorized():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=TIMEOUT)
    assert r.status_code == 401

def test_create_order_insufficient_stock():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    data = {"customer_name": "C", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 999}]}
    r = requests.post(f"{BASE_URL}/orders", json=data, timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_order_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.patch(f"{BASE_URL}/books/{book['id']}/stock", json={"quantity": 10}, timeout=TIMEOUT)
    data = {"customer_name": "C", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}
    r = requests.post(f"{BASE_URL}/orders", json=data, timeout=TIMEOUT)
    assert r.status_code == 201

def test_update_status_invalid_transition():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.patch(f"{BASE_URL}/books/{book['id']}/stock", json={"quantity": 10}, timeout=TIMEOUT)
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "C", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "invalid_status"}, timeout=TIMEOUT)
    assert r.status_code == 422

def test_get_invoice_forbidden():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=10", timeout=TIMEOUT)
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "C", "customer_email": "e@e.com", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403

def test_start_export_success():
    r = requests.post(f"{BASE_URL}/exports/books", headers={"X-API-Key": "admin-key"}, timeout=TIMEOUT)
    assert r.status_code == 202

def test_get_export_status_processing():
    r = requests.post(f"{BASE_URL}/exports/books", headers={"X-API-Key": "admin-key"}, timeout=TIMEOUT)
    assert r.status_code == 202
    job_id = r.json()["job_id"]
    r = requests.get(f"{BASE_URL}/exports/{job_id}", headers={"X-API-Key": "admin-key"}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert r.json()["status"] == "processing"

def test_toggle_maintenance_success():
    r = requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": True}, headers={"X-API-Key": "test-api-key"}, timeout=TIMEOUT)
    assert r.status_code == 200
    requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": False}, headers={"X-API-Key": "test-api-key"}, timeout=TIMEOUT)

def test_get_statistics_unauthorized():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=TIMEOUT)
    assert r.status_code == 401

def test_catalog_redirect():
    r = requests.get(f"{BASE_URL}/catalog", allow_redirects=False, timeout=TIMEOUT)
    assert r.status_code == 301

def test_add_tags_nonexistent():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [999]}, timeout=TIMEOUT)
    assert r.status_code == 404

def test_update_category_etag_mismatch():
    cat = create_category()
    r = requests.put(f"{BASE_URL}/categories/{cat['id']}", json={"name": "NewName"}, headers={"If-Match": "wrong"}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_clone_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", json={"new_isbn": "0000000000"}, timeout=TIMEOUT)
    assert r.status_code == 201

def test_get_cover_not_found():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.get(f"{BASE_URL}/books/{book['id']}/cover", timeout=TIMEOUT)
    assert r.status_code == 404

def test_get_cover_invalid_id_format():
    r = requests.get(f"{BASE_URL}/books/abc/cover", timeout=TIMEOUT)
    assert r.status_code == 422