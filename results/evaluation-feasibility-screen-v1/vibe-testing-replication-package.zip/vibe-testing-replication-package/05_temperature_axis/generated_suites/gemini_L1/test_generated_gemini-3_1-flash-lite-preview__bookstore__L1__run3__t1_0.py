import requests
import uuid
import time

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30
HEADERS = {"X-API-Key": "test-api-key"}

def create_author():
    name = f"Author_{uuid.uuid4().hex[:8]}"
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": "Bio", "born_year": 1990}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Failed create author: {r.text}"
    return r.json()["id"]

def create_category():
    name = f"Cat_{uuid.uuid4().hex[:8]}"
    r = requests.post(f"{BASE_URL}/categories", json={"name": name, "description": "Desc"}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Failed create category: {r.text}"
    return r.json()["id"]

def create_book(author_id, category_id):
    isbn = f"978{uuid.uuid4().hex[:7]}"
    data = {
        "title": f"Book_{uuid.uuid4().hex[:8]}",
        "isbn": isbn,
        "price": 100.0,
        "published_year": 2020,
        "stock": 10,
        "author_id": author_id,
        "category_id": category_id
    }
    r = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert r.status_code == 201, f"Failed create book: {r.text}"
    return r.json()["id"]

def test_create_book_success():
    a_id = create_author()
    c_id = create_category()
    isbn = f"978{uuid.uuid4().hex[:7]}"
    payload = {"title": "Title", "isbn": isbn, "price": 10.0, "published_year": 2020, "author_id": a_id, "category_id": c_id}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_book_invalid_isbn():
    a_id = create_author()
    c_id = create_category()
    payload = {"title": "Title", "isbn": "123", "price": 10.0, "published_year": 2020, "author_id": a_id, "category_id": c_id}
    r = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_list_books_pagination_default():
    r = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    assert r.status_code == 200
    assert "items" in r.json()

def test_list_books_filter_price():
    r = requests.get(f"{BASE_URL}/books?min_price=0", timeout=TIMEOUT)
    assert r.status_code == 200
    assert isinstance(r.json()["items"], list)

def test_list_books_invalid_page_number():
    r = requests.get(f"{BASE_URL}/books?page=-1", timeout=TIMEOUT)
    assert r.status_code == 422

def test_get_book_not_modified():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r1 = requests.get(f"{BASE_URL}/books/{b_id}", timeout=TIMEOUT)
    etag = r1.headers.get("ETag")
    r2 = requests.get(f"{BASE_URL}/books/{b_id}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert r2.status_code == 304

def test_get_soft_deleted_book():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    requests.delete(f"{BASE_URL}/books/{b_id}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{b_id}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_delete_book_soft_success():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r = requests.delete(f"{BASE_URL}/books/{b_id}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_restore_deleted_book():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    requests.delete(f"{BASE_URL}/books/{b_id}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{b_id}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    assert r.json()["id"] == b_id

def test_restore_active_book():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r = requests.post(f"{BASE_URL}/books/{b_id}/restore", timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_valid():
    a_id = create_author()
    c_id = create_category()
    isbn = f"978{uuid.uuid4().hex[:7]}"
    b_id = requests.post(f"{BASE_URL}/books", json={"title": "OldBook", "isbn": isbn, "price": 100.0, "published_year": 2000, "author_id": a_id, "category_id": c_id}, timeout=TIMEOUT).json()["id"]
    r = requests.post(f"{BASE_URL}/books/{b_id}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "discounted_price" in r.json()

def test_apply_discount_new_book():
    a_id = create_author()
    c_id = create_category()
    isbn = f"978{uuid.uuid4().hex[:7]}"
    b_id = requests.post(f"{BASE_URL}/books", json={"title": "NewBook", "isbn": isbn, "price": 100.0, "published_year": 2026, "author_id": a_id, "category_id": c_id}, timeout=TIMEOUT).json()["id"]
    r = requests.post(f"{BASE_URL}/books/{b_id}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_rate_limit():
    a_id = create_author()
    c_id = create_category()
    isbn = f"978{uuid.uuid4().hex[:7]}"
    b_id = requests.post(f"{BASE_URL}/books", json={"title": "OldBook", "isbn": isbn, "price": 100.0, "published_year": 2000, "author_id": a_id, "category_id": c_id}, timeout=TIMEOUT).json()["id"]
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{b_id}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 429

def test_update_stock_success():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r = requests.patch(f"{BASE_URL}/books/{b_id}/stock?quantity=5", timeout=TIMEOUT)
    assert r.status_code == 200
    assert r.json()["stock"] == 15

def test_update_stock_insufficient():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r = requests.patch(f"{BASE_URL}/books/{b_id}/stock?quantity=-100", timeout=TIMEOUT)
    assert r.status_code == 400

def test_bulk_create_partial_success():
    a_id = create_author()
    c_id = create_category()
    payload = {
        "books": [
            {"title": f"B1_{uuid.uuid4().hex[:8]}", "isbn": f"978{uuid.uuid4().hex[:7]}", "price": 10.0, "published_year": 2020, "stock": 1, "author_id": a_id, "category_id": c_id},
            {"title": "B2", "isbn": "bad", "price": 10.0, "published_year": 2020, "stock": 1, "author_id": a_id, "category_id": c_id}
        ]
    }
    r = requests.post(f"{BASE_URL}/books/bulk", json=payload, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 207, f"Expected 207, got {r.status_code}: {r.text}"

def test_create_author_success():
    name = f"Author_{uuid.uuid4().hex[:8]}"
    r = requests.post(f"{BASE_URL}/authors", json={"name": name, "bio": "B", "born_year": 1990}, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_update_author_etag_mismatch():
    a_id = create_author()
    r = requests.put(f"{BASE_URL}/authors/{a_id}", json={"name": "New"}, headers={"If-Match": "wrong-etag"}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_create_duplicate_category():
    name = f"Cat_{uuid.uuid4().hex[:8]}"
    requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409

def test_create_order_insufficient_stock():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    payload = {"customer_name": "Name", "customer_email": "e@e.cz", "items": [{"book_id": b_id, "quantity": 999}]}
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_order_success():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    payload = {"customer_name": "Name", "customer_email": "e@e.cz", "items": [{"book_id": b_id, "quantity": 1}]}
    r = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_update_status_invalid_transition():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    o_id = requests.post(f"{BASE_URL}/orders", json={"customer_name": "N", "customer_email": "e@e.cz", "items": [{"book_id": b_id, "quantity": 1}]}, timeout=TIMEOUT).json()["id"]
    r = requests.patch(f"{BASE_URL}/orders/{o_id}/status", json={"status": "shipped"}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_add_item_to_confirmed_order():
    a_id = create_author()
    c_id = create_category()
    b1_id = create_book(a_id, c_id)
    b2_id = create_book(a_id, c_id)
    o_id = requests.post(f"{BASE_URL}/orders", json={"customer_name": "N", "customer_email": "e@e.cz", "items": [{"book_id": b1_id, "quantity": 1}]}, timeout=TIMEOUT).json()["id"]
    requests.patch(f"{BASE_URL}/orders/{o_id}/status", json={"status": "confirmed"}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/orders/{o_id}/items", json={"book_id": b2_id, "quantity": 1}, timeout=TIMEOUT)
    assert r.status_code == 403

def test_export_unauthorized():
    r = requests.post(f"{BASE_URL}/exports/books", timeout=TIMEOUT)
    assert r.status_code == 401

def test_get_export_status_polling():
    r_start = requests.post(f"{BASE_URL}/exports/books", headers=HEADERS, timeout=TIMEOUT)
    assert r_start.status_code in (200, 202), f"Failed to start export: {r_start.text}"
    job_id = r_start.json()["job_id"]
    r = requests.get(f"{BASE_URL}/exports/{job_id}", headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code in (200, 202), f"Expected 200 or 202, got {r.status_code}: {r.text}"

def test_toggle_maintenance_mode():
    r = requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": True}, headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 200
    requests.post(f"{BASE_URL}/admin/maintenance", json={"enabled": False}, headers=HEADERS, timeout=TIMEOUT)

def test_get_statistics_success():
    r = requests.get(f"{BASE_URL}/statistics/summary", headers=HEADERS, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "total_books" in r.json()

def test_get_statistics_forbidden():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=TIMEOUT)
    assert r.status_code == 401

def test_upload_cover_invalid_type():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    r = requests.post(f"{BASE_URL}/books/{b_id}/cover", files={"file": ("test.txt", "content")}, timeout=TIMEOUT)
    assert r.status_code == 415

def test_add_tags_success():
    a_id = create_author()
    c_id = create_category()
    b_id = create_book(a_id, c_id)
    t_id = requests.post(f"{BASE_URL}/tags", json={"name": f"Tag_{uuid.uuid4().hex[:8]}"}, timeout=TIMEOUT).json()["id"]
    r = requests.post(f"{BASE_URL}/books/{b_id}/tags", json={"tag_ids": [t_id]}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert len(r.json()["tags"]) == 1