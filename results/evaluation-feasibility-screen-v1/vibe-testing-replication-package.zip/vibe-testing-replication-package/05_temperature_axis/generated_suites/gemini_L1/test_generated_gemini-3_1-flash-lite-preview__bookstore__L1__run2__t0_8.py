# Analýza: ISBN v helperu generuje náhodné číslo, které často neodpovídá formátu (musí být 13 číslic, uuid4().int může být kratší). Přidán API_KEY do hlaviček dle specifikace a oprava ISBN na string o 13 znacích.

import requests
import uuid
import pytest

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 30
API_KEY = "test-api-key"
HEADERS = {"X-API-Key": API_KEY}

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_author():
    name = unique("Author")
    resp = requests.post(
        f"{BASE_URL}/authors", 
        json={"name": name, "bio": "Bio", "born_year": 1990}, 
        headers=HEADERS, 
        timeout=TIMEOUT
    )
    assert resp.status_code == 201, f"Helper failed {resp.status_code}: {resp.text[:200]}"
    return resp.json()

def create_category():
    name = unique("Cat")
    resp = requests.post(
        f"{BASE_URL}/categories", 
        json={"name": name, "description": "Desc"}, 
        headers=HEADERS, 
        timeout=TIMEOUT
    )
    assert resp.status_code == 201, f"Helper failed {resp.status_code}: {resp.text[:200]}"
    return resp.json()

def create_book(author_id, category_id):
    # Generování 13-místného ISBN jako stringu pro validaci Pydantic
    isbn = str(uuid.uuid4().int)[:13].zfill(13)
    data = {
        "title": unique("Book"),
        "isbn": isbn,
        "price": 100.0,
        "published_year": 2020,
        "stock": 10,
        "author_id": author_id,
        "category_id": category_id
    }
    resp = requests.post(
        f"{BASE_URL}/books", 
        json=data, 
        headers=HEADERS, 
        timeout=TIMEOUT
    )
    assert resp.status_code == 201, f"Helper failed {resp.status_code}: {resp.text[:200]}"
    return resp.json()


def test_create_book_success():
    auth = create_author()
    cat = create_category()
    data = {
        "title": unique("Book"),
        "isbn": "1234567890123",
        "price": 50.0,
        "published_year": 2020,
        "stock": 5,
        "author_id": auth["id"],
        "category_id": cat["id"]
    }
    r = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_book_invalid_isbn():
    auth = create_author()
    cat = create_category()
    data = {"title": "Test", "isbn": "123", "price": 50.0, "published_year": 2020, "author_id": auth["id"], "category_id": cat["id"]}
    r = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_book_not_found():
    r = requests.get(f"{BASE_URL}/books/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_get_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_delete_book_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204

def test_restore_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 200
    assert r.json()["id"] == book["id"]

def test_restore_non_deleted_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_success():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "discounted_price" in r.json()

def test_apply_discount_new_book():
    auth = create_author()
    cat = create_category()
    data = {
        "title": unique("NewBook"),
        "isbn": "1111111111111",
        "price": 100.0,
        "published_year": 2026,
        "author_id": auth["id"],
        "category_id": cat["id"]
    }
    book = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT).json()
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 10.0}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_apply_discount_rate_limit():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    for _ in range(6):
        r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"discount_percent": 5.0}, timeout=TIMEOUT)
    assert r.status_code == 429

def test_update_stock_insufficient():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=-100", timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_stock_invalid_format():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.patch(f"{BASE_URL}/books/{book['id']}/stock?quantity=abc", timeout=TIMEOUT)
    assert r.status_code == 422

def test_upload_cover_invalid_type():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files={"file": ("test.txt", b"dummy")}, timeout=TIMEOUT)
    assert r.status_code == 415

def test_create_author_success():
    r = requests.post(f"{BASE_URL}/authors", json={"name": unique("Auth"), "bio": "B", "born_year": 2000}, timeout=TIMEOUT)
    assert r.status_code == 201
    assert "id" in r.json()

def test_create_duplicate_category():
    name = unique("Cat")
    requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 409

def test_create_order_insufficient_stock():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    data = {"customer_name": "C", "customer_email": "e@e.cz", "items": [{"book_id": book["id"], "quantity": 999}]}
    r = requests.post(f"{BASE_URL}/orders", json=data, timeout=TIMEOUT)
    assert r.status_code == 400

def test_create_order_duplicate_book():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    data = {"customer_name": "C", "customer_email": "e@e.cz", "items": [{"book_id": book["id"], "quantity": 1}, {"book_id": book["id"], "quantity": 1}]}
    r = requests.post(f"{BASE_URL}/orders", json=data, timeout=TIMEOUT)
    assert r.status_code == 400

def test_update_status_invalid_transition():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "C", "customer_email": "e@e.cz", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=TIMEOUT)
    assert r.status_code == 400

def test_get_invoice_forbidden():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"customer_name": "C", "customer_email": "e@e.cz", "items": [{"book_id": book["id"], "quantity": 1}]}, timeout=TIMEOUT).json()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    assert r.status_code == 403

def test_bulk_create_unauthorized():
    r = requests.post(f"{BASE_URL}/books/bulk", json={"books": []}, timeout=TIMEOUT)
    assert r.status_code == 401

def test_bulk_create_partial_success():
    auth = create_author()
    cat = create_category()
    books = [
        {"title": unique("B1"), "isbn": str(uuid.uuid4().int)[:13], "price": 10.0, "published_year": 2020, "stock": 1, "author_id": auth["id"], "category_id": cat["id"]},
        {"title": "", "isbn": "1", "price": 10.0, "published_year": 2020, "stock": 1, "author_id": auth["id"], "category_id": cat["id"]}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", headers={"X-API-Key": API_KEY}, json=books, timeout=TIMEOUT)
    assert r.status_code == 422

def test_start_export_authorized():
    r = requests.post(f"{BASE_URL}/exports/books", headers={"X-API-Key": API_KEY}, timeout=TIMEOUT)
    assert r.status_code in (202, 201)

def test_get_export_not_found():
    r = requests.get(f"{BASE_URL}/exports/abc12345", timeout=TIMEOUT)
    assert r.status_code == 404

def test_toggle_maintenance_success():
    r = requests.post(f"{BASE_URL}/admin/maintenance", headers={"X-API-Key": API_KEY}, json={"enabled": True}, timeout=TIMEOUT)
    assert r.status_code == 200
    requests.post(f"{BASE_URL}/admin/maintenance", headers={"X-API-Key": API_KEY}, json={"enabled": False}, timeout=TIMEOUT)

def test_get_stats_forbidden():
    r = requests.get(f"{BASE_URL}/statistics/summary", timeout=TIMEOUT)
    assert r.status_code == 401

def test_get_stats_large_data():
    r = requests.get(f"{BASE_URL}/statistics/summary", headers={"X-API-Key": API_KEY}, timeout=TIMEOUT)
    assert r.status_code == 200
    assert "total_books" in r.json()

def test_update_tag_etag_mismatch():
    tag = requests.post(f"{BASE_URL}/tags", json={"name": unique("Tag")}, timeout=TIMEOUT).json()
    r = requests.put(f"{BASE_URL}/tags/{tag['id']}", headers={"If-Match": "wrong"}, json={"name": unique("Tag2")}, timeout=TIMEOUT)
    assert r.status_code == 412

def test_add_nonexistent_tag():
    auth = create_author()
    cat = create_category()
    book = create_book(auth["id"], cat["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_ids": [99999]}, timeout=TIMEOUT)
    assert r.status_code == 404

def test_catalog_deprecated_redirect():
    r = requests.get(f"{BASE_URL}/catalog", allow_redirects=False, timeout=TIMEOUT)
    assert r.status_code == 301
    assert "Location" in r.headers

def test_catalog_invalid_query_params():
    r = requests.get(f"{BASE_URL}/books", params={"invalid": "param"}, timeout=TIMEOUT)
    assert r.status_code == 422