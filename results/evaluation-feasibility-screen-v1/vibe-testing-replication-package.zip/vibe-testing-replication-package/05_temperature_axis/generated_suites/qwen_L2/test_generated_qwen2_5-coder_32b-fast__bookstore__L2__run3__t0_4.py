# The main error seems to be related to string length limits for names and ISBNs. I will ensure that the generated strings do not exceed the expected limits by reducing the length of the unique suffix.
# Additionally, I will check if any required headers are missing and add them where necessary.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def unique_name(prefix):
    return f'{prefix}_{uuid.uuid4().hex[:6]}'  # Reduced length to ensure it fits within expected limits

def create_author(name):
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    response = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_book(title, author_id, category_id):
    isbn = unique_name("ISBN")
    response = requests.post(f"{BASE_URL}/books", json={"title": title, "author_id": author_id, "category_id": category_id, "isbn": isbn}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name):
    response = requests.post(f"{BASE_URL}/orders", json={"customer_name": customer_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, book_id):
    response = requests.post(f"{BASE_URL}/orders/{order_id}/add_item", json={"book_id": book_id}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_authors():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_create_author_happy_path():
    name = unique_name("Author")
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["name"] == name

def test_create_author_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/authors", json={"name": ""}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_categories():
    response = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_create_category_happy_path():
    name = unique_name("Category")
    response = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["name"] == name

def test_create_category_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/categories", json={"name": ""}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_books():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_create_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    title = unique_name("Book")
    book = create_book(title, author["id"], category["id"])
    assert book["title"] == title
    assert book["author_id"] == author["id"]
    assert book["category_id"] == category["id"]

def test_create_book_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/books", json={"title": "", "author_id": 1, "category_id": 1, "isbn": "1234567890"}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_book_by_id_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book = create_book(unique_name("Book"), author["id"], category["id"])
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data
    assert data["title"] == book["title"]

def test_get_nonexistent_book_error():
    response = requests.get(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_update_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book = create_book(unique_name("Book"), author["id"], category["id"])
    new_title = unique_name("Updated Book")
    response = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert data["title"] == new_title

def test_update_nonexistent_book_error():
    response = requests.put(f"{BASE_URL}/books/99999", json={"title": "Updated Book", "author_id": 1, "category_id": 1}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_delete_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book = create_book(unique_name("Book"), author["id"], category["id"])
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_delete_nonexistent_book_error():
    response = requests.delete(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    assert response.status_code == 404

def test_clone_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book = create_book(unique_name("Book"), author["id"], category["id"])
    clone_data = {"new_title": unique_name("Cloned Book")}
    response = requests.post(f"{BASE_URL}/books/{book['id']}/clone", json=clone_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["title"] == clone_data["new_title"]

def test_clone_nonexistent_book_error():
    response = requests.post(f"{BASE_URL}/books/99999/clone", json={"new_title": "Cloned Book"}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_get_all_orders():
    response = requests.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_create_order_happy_path():
    customer_name = unique_name("Customer")
    order = create_order(customer_name)
    assert order["customer_name"] == customer_name

def test_create_order_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/orders", json={"customer_name": ""}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_order_by_id_happy_path():
    order = create_order(unique_name("Customer"))
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data
    assert data["customer_name"] == order["customer_name"]

def test_get_nonexistent_order_error():
    response = requests.get(f"{BASE_URL}/orders/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_add_item_to_order_happy_path():
    book = create_book(unique_name("Book"), 1, 1)  # Assuming there's at least one author and category with IDs 1
    order = create_order(unique_name("Customer"))
    add_item_to_order(order["id"], book["id"])
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert len(data["items"]) == 1

def test_add_item_to_nonexistent_order_error():
    book_id = 1  # Assuming there's at least one book with ID 1
    response = requests.post(f"{BASE_URL}/orders/99999/add_item", json={"book_id": book_id}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_get_statistics():
    response = requests.get(f"{BASE_URL}/statistics", timeout=TIMEOUT)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)

def test_get_statistics_by_category():
    category = create_category(unique_name("Category"))
    response = requests.get(f"{BASE_URL}/statistics/{category['id']}", timeout=TIMEOUT)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, dict)


def test_update_author_happy_path():
    author = create_author(unique_name("Author"))
    updated_name = unique_name("Updated Author")
    response = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": updated_name}, timeout=TIMEOUT)
    assert response.status_code == 200
    updated_author = response.json()
    assert updated_author["name"] == updated_name

def test_update_nonexistent_author_error():
    non_existent_id = 999999
    response = requests.put(f"{BASE_URL}/authors/{non_existent_id}", json={"name": unique_name("Author")}, timeout=TIMEOUT)
    assert response.status_code == 404

def test_create_book_with_missing_fields_error():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    response = requests.post(f"{BASE_URL}/books", json={"author_id": author['id'], "category_id": category['id']}, timeout=TIMEOUT)
    assert response.status_code == 422
    error_response = response.json()
    assert any(error["loc"][-1] == "title" for error in error_response["detail"])

def test_get_author_with_if_none_match_header():
    author = create_author(unique_name("Author"))
    first_response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert first_response.status_code == 200
    etag = first_response.headers["ETag"]
    headers = {"If-None-Match": etag}
    second_response = requests.get(f"{BASE_URL}/authors/{author['id']}", headers=headers, timeout=TIMEOUT)
    assert second_response.status_code == 304