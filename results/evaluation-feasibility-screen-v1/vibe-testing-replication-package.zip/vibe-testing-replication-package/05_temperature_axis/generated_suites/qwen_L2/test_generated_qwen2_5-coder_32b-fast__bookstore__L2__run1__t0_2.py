# Main error seems to be related to string length limits for names and titles. Truncating unique names to fit within expected limits.
# Also, some endpoints might require additional headers like ETag or API key which are currently missing.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def unique_name(prefix):
    return f'{prefix}_{uuid.uuid4().hex[:6]}'  # Truncated to fit within expected limits

def create_book(title, author_id, category_id, tags=None):
    url = f"{BASE_URL}/books/"
    data = {
        "title": title[:255],  # Ensure title does not exceed character limit
        "author_id": author_id,
        "category_id": category_id,
        "tags": tags or []
    }
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    url = f"{BASE_URL}/authors/"
    data = {"name": name[:255]}  # Ensure name does not exceed character limit
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    url = f"{BASE_URL}/categories/"
    data = {"name": name[:255]}  # Ensure name does not exceed character limit
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(name):
    url = f"{BASE_URL}/tags/"
    data = {"name": name[:255]}  # Ensure name does not exceed character limit
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name):
    url = f"{BASE_URL}/orders/"
    data = {"customer_name": customer_name[:255]}  # Ensure name does not exceed character limit
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, book_id, quantity):
    url = f"{BASE_URL}/orders/{order_id}/add_item/"
    data = {"book_id": book_id, "quantity": quantity}
    response = requests.post(url, json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books():
    r = requests.get(f"{BASE_URL}/books/", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book_data = create_book(unique_name("Book"), author["id"], category["id"])
    assert "id" in book_data
    assert "title" in book_data

def test_create_book_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/books/", json={}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_book_by_id_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book_data = create_book(unique_name("Book"), author["id"], category["id"])
    r = requests.get(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "title" in data

def test_get_nonexistent_book_error():
    r = requests.get(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_update_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book_data = create_book(unique_name("Book"), author["id"], category["id"])
    new_title = unique_name("Updated Book")
    r = requests.put(f"{BASE_URL}/books/{book_data['id']}", json={"title": new_title}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "title" in data
    assert data["title"] == new_title

def test_update_nonexistent_book_error():
    r = requests.put(f"{BASE_URL}/books/99999", json={"title": unique_name("Updated Book")}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_delete_book_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book_data = create_book(unique_name("Book"), author["id"], category["id"])
    r = requests.delete(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT)
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_delete_nonexistent_book_error():
    r = requests.delete(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    assert r.status_code == 404

def test_get_all_authors_happy_path():
    r = requests.get(f"{BASE_URL}/authors/", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert isinstance(data, list)

def test_create_author_happy_path():
    author_data = create_author(unique_name("Author"))
    assert "id" in author_data
    assert "name" in author_data

def test_create_author_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/authors/", json={}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_author_by_id_happy_path():
    author_data = create_author(unique_name("Author"))
    r = requests.get(f"{BASE_URL}/authors/{author_data['id']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "name" in data

def test_get_nonexistent_author_error():
    r = requests.get(f"{BASE_URL}/authors/99999", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_get_all_categories_happy_path():
    r = requests.get(f"{BASE_URL}/categories/", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert isinstance(data, list)

def test_create_category_happy_path():
    category_data = create_category(unique_name("Category"))
    assert "id" in category_data
    assert "name" in category_data

def test_create_category_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/categories/", json={}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_category_by_id_happy_path():
    category_data = create_category(unique_name("Category"))
    r = requests.get(f"{BASE_URL}/categories/{category_data['id']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "name" in data

def test_get_nonexistent_category_error():
    r = requests.get(f"{BASE_URL}/categories/99999", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_get_all_tags_happy_path():
    r = requests.get(f"{BASE_URL}/tags/", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert isinstance(data, list)

def test_create_tag_happy_path():
    tag_data = create_tag(unique_name("Tag"))
    assert "id" in tag_data
    assert "name" in tag_data

def test_create_tag_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/tags/", json={}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_tag_by_id_happy_path():
    tag_data = create_tag(unique_name("Tag"))
    r = requests.get(f"{BASE_URL}/tags/{tag_data['id']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "name" in data

def test_get_nonexistent_tag_error():
    r = requests.get(f"{BASE_URL}/tags/99999", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_get_all_orders_happy_path():
    r = requests.get(f"{BASE_URL}/orders/", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_order_happy_path():
    order_data = create_order(unique_name("Customer"))
    assert "id" in order_data
    assert "customer_name" in order_data

def test_create_order_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/orders/", json={}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_order_by_id_happy_path():
    order_data = create_order(unique_name("Customer"))
    r = requests.get(f"{BASE_URL}/orders/{order_data['id']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "customer_name" in data

def test_get_nonexistent_order_error():
    r = requests.get(f"{BASE_URL}/orders/99999", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_add_item_to_order_happy_path():
    author = create_author(unique_name("Author"))
    category = create_category(unique_name("Category"))
    book_data = create_book(unique_name("Book"), author["id"], category["id"])
    order_data = create_order(unique_name("Customer"))
    item_data = add_item_to_order(order_data["id"], book_data["id"], 2)
    assert "order_id" in item_data
    assert "book_id" in item_data
