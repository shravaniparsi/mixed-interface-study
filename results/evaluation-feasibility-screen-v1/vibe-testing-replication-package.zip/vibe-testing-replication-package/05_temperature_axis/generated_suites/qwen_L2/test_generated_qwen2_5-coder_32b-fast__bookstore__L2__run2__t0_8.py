# The errors are likely due to string length issues for names exceeding API constraints. Additionally, some endpoints might require headers like X-API-Key or ETag which are missing.

import uuid
import requests

BASE_URL = "http://localhost:8000"
API_KEY = "your_api_key_here"  # Replace with actual API key if needed

def create_book(name=None, author_id=None, category_id=None, isbn=None):
    name = f"Book_{uuid.uuid4().hex[:6]}" if name is None else name  # Shortened unique string to ensure length constraints
    isbn = f"978316{uuid.uuid4().hex[:5]}" if isbn is None else isbn
    data = {
        "name": name,
        "author_id": author_id,
        "category_id": category_id,
        "isbn": isbn
    }
    headers = {"X-API-Key": API_KEY} if API_KEY else {}
    response = requests.post(f"{BASE_URL}/books", json=data, headers=headers, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=None):
    name = f"Author_{uuid.uuid4().hex[:6]}" if name is None else name  # Shortened unique string to ensure length constraints
    data = {"name": name}
    headers = {"X-API-Key": API_KEY} if API_KEY else {}
    response = requests.post(f"{BASE_URL}/authors", json=data, headers=headers, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name=None):
    name = f"Category_{uuid.uuid4().hex[:6]}" if name is None else name  # Shortened unique string to ensure length constraints
    data = {"name": name}
    headers = {"X-API-Key": API_KEY} if API_KEY else {}
    response = requests.post(f"{BASE_URL}/categories", json=data, headers=headers, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name=None):
    customer_name = f"Customer_{uuid.uuid4().hex[:6]}" if customer_name is None else customer_name  # Shortened unique string to ensure length constraints
    data = {"customer_name": customer_name}
    headers = {"X-API-Key": API_KEY} if API_KEY else {}
    response = requests.post(f"{BASE_URL}/orders", json=data, headers=headers, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    r = requests.get(f"{BASE_URL}/books", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data

def test_get_book_by_id_happy_path():
    book = create_book()
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "name" in data
    assert "author_id" in data

def test_get_nonexistent_book_error():
    r = requests.get(f"{BASE_URL}/books/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_create_new_book_happy_path():
    author = create_author()
    category = create_category()
    book_data = {
        "name": f"Book_{uuid.uuid4().hex[:8]}",
        "author_id": author["id"],
        "category_id": category["id"],
        "isbn": f"978316{uuid.uuid4().hex[:5]}"
    }
    r = requests.post(f"{BASE_URL}/books", json=book_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_update_existing_book_happy_path():
    book = create_book()
    update_data = {"name": f"Updated_{uuid.uuid4().hex[:8]}"}
    headers = {'If-Match': book['etag']}
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json=update_data, headers=headers, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert data["name"] == update_data["name"]

def test_update_nonexistent_book_error():
    update_data = {"name": f"Updated_{uuid.uuid4().hex[:8]}"}
    r = requests.put(f"{BASE_URL}/books/99999", json=update_data, timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_delete_existing_book_happy_path():
    book = create_book()
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204

def test_delete_nonexistent_book_error():
    r = requests.delete(f"{BASE_URL}/books/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_get_all_authors_happy_path():
    r = requests.get(f"{BASE_URL}/authors", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_get_author_by_id_happy_path():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "name" in data

def test_get_nonexistent_author_error():
    r = requests.get(f"{BASE_URL}/authors/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_create_new_author_happy_path():
    author_data = {"name": f"Author_{uuid.uuid4().hex[:8]}"}
    r = requests.post(f"{BASE_URL}/authors", json=author_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_get_all_categories_happy_path():
    r = requests.get(f"{BASE_URL}/categories", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_get_category_by_id_happy_path():
    category = create_category()
    r = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "name" in data

def test_get_nonexistent_category_error():
    r = requests.get(f"{BASE_URL}/categories/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_create_new_category_happy_path():
    category_data = {"name": f"Category_{uuid.uuid4().hex[:8]}"}
    r = requests.post(f"{BASE_URL}/categories", json=category_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_get_all_orders_happy_path():
    r = requests.get(f"{BASE_URL}/orders", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data

def test_get_order_by_id_happy_path():
    order = create_order()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "customer_name" in data

def test_get_nonexistent_order_error():
    r = requests.get(f"{BASE_URL}/orders/99999", timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_create_new_order_happy_path():
    order_data = {"customer_name": f"Customer_{uuid.uuid4().hex[:8]}"}
    r = requests.post(f"{BASE_URL}/orders", json=order_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_add_item_to_order_happy_path():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_add_invalid_item_to_order_error():
    order = create_order()
    item_data = {"book_id": 99999, "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=30)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_get_statistics_happy_path():
    r = requests.get(f"{BASE_URL}/statistics", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, dict)

def test_clone_existing_book_happy_path():
    book = create_book()
    clone_data = {"new_name": f"Cloned_{uuid.uuid4().hex[:8]}", "isbn": f"978316{uuid.uuid4().hex[:5]}"}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", json=clone_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_clone_nonexistent_book_error():
    clone_data = {"new_name": f"Cloned_{uuid.uuid4().hex[:8]}", "isbn": f"978316{uuid.uuid4().hex[:5]}"}
    r = requests.post(f"{BASE_URL}/books/99999/clone", json=clone_data, timeout=30)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_bulk_create_books_happy_path():
    author = create_author()
    category = create_category()
    books_data = [
        {"name": f"Book_{uuid.uuid4().hex[:8]}", "author_id": author['id'], "category_id": category['id'], "isbn": f"978316{uuid.uuid4().hex[:5]}"},
        {"name": f"Book_{uuid.uuid4().hex[:8]}", "author_id": author['id'], "category_id": category['id'], "isbn": f"978316{uuid.uuid4().hex[:5]}"}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert len(data) == 2

def test_cancel_order_happy_path():
    order = create_order()
    headers = {"X-API-Key": API_KEY} if API_KEY else {}
    r = requests.delete(f"{BASE_URL}/orders/{order['id']}", headers=headers, timeout=30)
    assert r.status_code == 204

def test_bulk_update_categories_happy_path():
    categories_data = [
        {"name": f"Category_{uuid.uuid4().hex[:8]}", "description": "Test Description"},
        {"name": f"Category_{uuid.uuid4().hex[:8]}", "description": "Another Test Description"}
    ]
    r = requests.put(f"{BASE_URL}/categories/bulk", json=categories_data, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 2

def test_create_bulk_orders_happy_path():
    orders_data = [
        {"customer_name": f"Customer_{uuid.uuid4().hex[:8]}", "status": "pending"},
        {"customer_name": f"Customer_{uuid.uuid4().hex[:8]}", "status": "completed"}
    ]
    r = requests.post(f"{BASE_URL}/orders/bulk", json=orders_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert len(data) == 2

def test_bulk_create_books_with_invalid_data_error():
    books_data = [
        {"name": f"Book_{uuid.uuid4().hex[:8]}", "author_id": None, "category_id": None, "isbn": "invalid_isbn"},
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=30)
    assert r.status_code == 422
    assert "detail" in r.json()
