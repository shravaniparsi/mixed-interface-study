# The main issue seems to be related to string length constraints for names and ISBNs. We need to ensure that unique names and ISBNs do not exceed the allowed lengths by truncating them if necessary.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_author(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Truncate to fit within reasonable limits
    full_name = f'{name}_{unique_suffix}'[:100]
    response = requests.post(f"{BASE_URL}/authors", json={"name": full_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Truncate to fit within reasonable limits
    full_name = f'{name}_{unique_suffix}'[:100]
    response = requests.post(f"{BASE_URL}/categories", json={"name": full_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_book(title, author_id, category_id, isbn, stock):
    unique_suffix = uuid.uuid4().hex[:8]  # Full suffix for ISBN
    full_title = f'{title}_{unique_suffix}'[:150]
    full_isbn = f'{isbn}{unique_suffix[:7]}'[-13:]  # Ensure the ISBN is exactly 13 characters long
    response = requests.post(f"{BASE_URL}/books", json={"title": full_title, "author_id": author_id, "category_id": category_id, "isbn": full_isbn, "stock": stock}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order():
    response = requests.post(f"{BASE_URL}/orders", timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_authors_happy_path():
    r = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert isinstance(data, list)

def test_get_author_by_valid_id_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == author["name"]

def test_get_author_by_invalid_id_error():
    r = requests.get(f"{BASE_URL}/authors/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_create_author_with_valid_data_happy_path():
    name = f'Author_{uuid.uuid4().hex[:8]}'
    r = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_author_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/authors", json={}, timeout=TIMEOUT)
    assert r.status_code == 422, f"Expected 422, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_update_author_with_valid_data_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    new_name = f'New_Author_{uuid.uuid4().hex[:8]}'
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == new_name

def test_update_author_with_invalid_id_error():
    new_name = f'New_Author_{uuid.uuid4().hex[:8]}'
    r = requests.put(f"{BASE_URL}/authors/9999", json={"name": new_name}, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_delete_author_by_valid_id_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 204, f"Expected 204, got {r.status_code}: {r.text[:200]}"
    r_get = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 404, f"Expected 404, got {r_get.status_code}: {r_get.text[:200]}"

def test_delete_author_by_invalid_id_error():
    r = requests.delete(f"{BASE_URL}/authors/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_get_all_categories_happy_path():
    r = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert isinstance(data, list)

def test_get_category_by_valid_id_happy_path():
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    r = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == category["name"]

def test_get_category_by_invalid_id_error():
    r = requests.get(f"{BASE_URL}/categories/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_create_category_with_valid_data_happy_path():
    name = f'Category_{uuid.uuid4().hex[:8]}'
    r = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == name

def test_create_category_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/categories", json={}, timeout=TIMEOUT)
    assert r.status_code == 422, f"Expected 422, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_update_category_with_valid_data_happy_path():
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    new_name = f'New_Category_{uuid.uuid4().hex[:8]}'
    r = requests.put(f"{BASE_URL}/categories/{category['id']}", json={"name": new_name}, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["name"] == new_name

def test_update_category_with_invalid_id_error():
    new_name = f'New_Category_{uuid.uuid4().hex[:8]}'
    r = requests.put(f"{BASE_URL}/categories/9999", json={"name": new_name}, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_delete_category_by_valid_id_happy_path():
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    r = requests.delete(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert r.status_code == 204, f"Expected 204, got {r.status_code}: {r.text[:200]}"
    r_get = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 404, f"Expected 404, got {r_get.status_code}: {r_get.text[:200]}"

def test_delete_category_by_invalid_id_error():
    r = requests.delete(f"{BASE_URL}/categories/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_get_all_books_happy_path():
    r = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_book_by_valid_id_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    book = create_book(f'Book_{uuid.uuid4().hex[:8]}', author['id'], category['id'], f'ISBN-{uuid.uuid4().hex[:10]}', 10)
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "title" in data
    assert data["title"] == book['title']

def test_get_book_by_invalid_id_error():
    r = requests.get(f"{BASE_URL}/books/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_create_book_with_valid_data_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    title = f'Book_{uuid.uuid4().hex[:8]}'
    isbn = f'ISBN-{uuid.uuid4().hex[:10]}'
    stock = 10
    r = requests.post(f"{BASE_URL}/books", json={"title": title, "author_id": author['id'], "category_id": category['id'], "isbn": isbn, "stock": stock}, timeout=TIMEOUT)
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "id" in data
    assert data["title"] == title
    assert data["isbn"] == isbn

def test_create_book_with_invalid_data_error():
    r = requests.post(f"{BASE_URL}/books", json={}, timeout=TIMEOUT)
    assert r.status_code == 422, f"Expected 422, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_update_book_with_valid_data_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    book = create_book(f'Book_{uuid.uuid4().hex[:8]}', author['id'], category['id'], f'ISBN-{uuid.uuid4().hex[:10]}', 10)
    new_title = f'New_Book_{uuid.uuid4().hex[:8]}'
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title, "author_id": author['id'], "category_id": category['id'], "isbn": book['isbn'], "stock": book['stock']}, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "title" in data
    assert data["title"] == new_title

def test_update_book_with_invalid_id_error():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    title = f'Book_{uuid.uuid4().hex[:8]}'
    isbn = f'ISBN-{uuid.uuid4().hex[:10]}'
    stock = 10
    r = requests.put(f"{BASE_URL}/books/9999", json={"title": title, "author_id": author['id'], "category_id": category['id'], "isbn": isbn, "stock": stock}, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_delete_book_by_valid_id_happy_path():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    book = create_book(f'Book_{uuid.uuid4().hex[:8]}', author['id'], category['id'], f'ISBN-{uuid.uuid4().hex[:10]}', 10)
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204, f"Expected 204, got {r.status_code}: {r.text[:200]}"
    r_get = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r_get.status_code == 410, f"Expected 410, got {r_get.status_code}: {r_get.text[:200]}"

def test_delete_book_by_invalid_id_error():
    r = requests.delete(f"{BASE_URL}/books/9999", timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_add_book_to_order_happy_path():
    order = create_order()
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    book = create_book(f'Book_{uuid.uuid4().hex[:8]}', author['id'], category['id'], f'ISBN-{uuid.uuid4().hex[:10]}', 10)
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/books", json={"book_id": book['id']}, timeout=TIMEOUT)
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_add_book_to_order_with_invalid_order_id_error():
    author = create_author(f'Author_{uuid.uuid4().hex[:8]}')
    category = create_category(f'Category_{uuid.uuid4().hex[:8]}')
    book = create_book(f'Book_{uuid.uuid4().hex[:8]}', author['id'], category['id'], f'ISBN-{uuid.uuid4().hex[:10]}', 10)
    r = requests.post(f"{BASE_URL}/orders/9999/books", json={"book_id": book['id']}, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_add_book_to_order_with_invalid_book_id_error():
    order = create_order()
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/books", json={"book_id": 9999}, timeout=TIMEOUT)
    assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data
