# Main error seems to be related to string length limits for names and ISBNs. I'll ensure that generated strings do not exceed the expected lengths by using uuid4().hex[:8] for uniqueness.
# Additionally, I will verify that all required fields are present in the payloads.

import uuid
import random
import pytest
from http import HTTPStatus
import requests

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_author(session):
    unique_suffix = uuid.uuid4().hex[:8]  # Ensure total length is within limits using [:8]
    author_name = f"Author_{unique_suffix}"
    response = session.post(f"{BASE_URL}/authors", json={"name": author_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(session):
    unique_suffix = uuid.uuid4().hex[:8]  # Ensure total length is within limits using [:8]
    category_name = f"Category_{unique_suffix}"
    response = session.post(f"{BASE_URL}/categories", json={"name": category_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_book(session, author_id, category_id):
    unique_suffix = uuid.uuid4().hex[:8]  # Ensure total length is within limits using [:8]
    book_title = f"Book_{unique_suffix}"
    isbn = f"978-3-16-{random.randint(10000, 99999)}-{unique_suffix[:2]}"  # Adjusted ISBN format and length
    response = session.post(f"{BASE_URL}/books", json={
        "title": book_title,
        "isbn": isbn,
        "author_id": author_id,
        "category_id": category_id
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(session):
    unique_suffix = uuid.uuid4().hex[:8]  # Ensure total length is within limits using [:8]
    tag_name = f"Tag_{unique_suffix}"
    response = session.post(f"{BASE_URL}/tags", json={"name": tag_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(session):
    unique_suffix = uuid.uuid4().hex[:8]  # Ensure total length is within limits using [:8]
    customer_name = f"Customer_{unique_suffix}"
    response = session.post(f"{BASE_URL}/orders", json={
        "customer_name": customer_name,
        "customer_email": f"customer{unique_suffix}@example.com"
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_review(session, book_id):
    review_text = "Great book!"
    rating = random.randint(1, 5)
    response = session.post(f"{BASE_URL}/books/{book_id}/reviews", json={
        "review": review_text,
        "rating": rating
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_tag_to_book(session, book_id, tag_id):
    response = session.post(f"{BASE_URL}/books/{book_id}/tags", json={"tag_id": tag_id}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(session, order_id, book_id):
    quantity = random.randint(1, 5)
    response = session.post(f"{BASE_URL}/orders/{order_id}/items", json={"book_id": book_id, "quantity": quantity}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


@pytest.mark.timeout(TIMEOUT)
def test_create_author_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        assert "id" in author
        assert "name" in author

@pytest.mark.timeout(TIMEOUT)
def test_create_author_invalid_name_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/authors", json={"name": ""}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_create_category_happy_path():
    with requests.Session() as session:
        category = create_category(session)
        assert "id" in category
        assert "name" in category

@pytest.mark.timeout(TIMEOUT)
def test_create_category_invalid_name_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/categories", json={"name": ""}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_create_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        assert "id" in book
        assert "title" in book

@pytest.mark.timeout(TIMEOUT)
def test_create_book_invalid_isbn_error():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        response = session.post(f"{BASE_URL}/books", json={
            "title": "Invalid ISBN Book",
            "isbn": "invalid-isbn",
            "author_id": author["id"],
            "category_id": category["id"]
        }, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_create_review_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        review = create_review(session, book["id"])
        assert "id" in review
        assert "review" in review

@pytest.mark.timeout(TIMEOUT)
def test_create_review_invalid_rating_error():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        response = session.post(f"{BASE_URL}/books/{book['id']}/reviews", json={
            "review": "Invalid rating",
            "rating": 6
        }, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_add_tag_to_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        tag = create_tag(session)
        response = add_tag_to_book(session, book["id"], tag["id"])
        assert "id" in response
        assert "tag_id" in response

@pytest.mark.timeout(TIMEOUT)
def test_add_nonexistent_tag_to_book_error():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        nonexistent_tag_id = 9999
        response = session.post(f"{BASE_URL}/books/{book['id']}/tags", json={"tag_id": nonexistent_tag_id}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_create_order_happy_path():
    with requests.Session() as session:
        order = create_order(session)
        assert "id" in order
        assert "customer_name" in order

@pytest.mark.timeout(TIMEOUT)
def test_create_order_missing_customer_name_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/orders", json={
            "customer_email": "missing-name@example.com"
        }, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_add_invalid_book_id_to_order_error():
    with requests.Session() as session:
        order = create_order(session)
        nonexistent_book_id = 9999
        response = session.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": nonexistent_book_id, "quantity": 1}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_bulk_create_books_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        books_data = [
            {"title": f"BulkBook_{uuid.uuid4().hex[:8]}", "isbn": f"978-3-16-{random.randint(100000, 999999)}-{uuid.uuid4().hex[:5]}", "author_id": author["id"], "category_id": category["id"]}
            for _ in range(random.randint(2, 5))
        ]
        response = session.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert isinstance(data, list)
        for book in data:
            assert "id" in book
            assert "title" in book

@pytest.mark.timeout(TIMEOUT)
def test_bulk_create_books_invalid_isbn_error():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        books_data = [
            {"title": f"BulkBook_{uuid.uuid4().hex[:8]}", "isbn": "invalid-isbn", "author_id": author["id"], "category_id": category["id"]}
            for _ in range(random.randint(2, 5))
        ]
        response = session.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_get_statistics():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        order = create_order(session)
        add_item_to_order(session, order["id"], book["id"])
        response = session.get(f"{BASE_URL}/statistics", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert "total_books" in data
        assert "total_authors" in data
        assert "total_categories" in data
        assert "total_orders" in data

def test_clone_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        response = session.post(f"{BASE_URL}/books/{book['id']}/clone", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.CREATED
        cloned_book = response.json()
        assert "id" in cloned_book
        assert "title" in cloned_book

def test_clone_nonexistent_book_error():
    with requests.Session() as session:
        nonexistent_book_id = 9999
        response = session.post(f"{BASE_URL}/books/{nonexistent_book_id}/clone", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

def test_get_author_books_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book1 = create_book(session, author["id"], category["id"])
        book2 = create_book(session, author["id"], category["id"])
        response = session.get(f"{BASE_URL}/authors/{author['id']}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        books = response.json()
        assert len(books) == 2
        book_ids = [book["id"] for book in books]
        assert book1["id"] in book_ids
        assert book2["id"] in book_ids

@pytest.mark.timeout(TIMEOUT)
def test_get_author_books_nonexistent_author_error():
    with requests.Session() as session:
        nonexistent_author_id = 9999
        response = session.get(f"{BASE_URL}/authors/{nonexistent_author_id}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

def test_get_books_by_category_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book1 = create_book(session, author["id"], category["id"])
        book2 = create_book(session, author["id"], category["id"])
        response = session.get(f"{BASE_URL}/categories/{category['id']}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        books = response.json()
        assert len(books) == 2
        book_ids = [book["id"] for book in books]
        assert book1["id"] in book_ids
        assert book2["id"] in book_ids

@pytest.mark.timeout(TIMEOUT)
def test_get_books_by_category_nonexistent_category_error():
    with requests.Session() as session:
        nonexistent_category_id = 9999
        response = session.get(f"{BASE_URL}/categories/{nonexistent_category_id}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

def test_get_books_by_tag_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book1 = create_book(session, author["id"], category["id"])
        tag = create_tag(session)
        add_tag_to_book(session, book1["id"], tag["id"])
        response = session.get(f"{BASE_URL}/tags/{tag['id']}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        books = response.json()
        assert len(books) == 1
        book_ids = [book["id"] for book in books]
        assert book1["id"] in book_ids

@pytest.mark.timeout(TIMEOUT)
def test_get_books_by_tag_nonexistent_tag_error():
    with requests.Session() as session:
        nonexistent_tag_id = 9999
        response = session.get(f"{BASE_URL}/tags/{nonexistent_tag_id}/books", timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_update_author_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        unique_suffix = uuid.uuid4().hex[:8]
        new_name = f"NewAuthor_{unique_suffix}"
        response = session.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        updated_author = response.json()
        assert updated_author["name"] == new_name

@pytest.mark.timeout(TIMEOUT)
def test_update_nonexistent_author_error():
    with requests.Session() as session:
        nonexistent_author_id = 9999
        unique_suffix = uuid.uuid4().hex[:8]
        new_name = f"NewAuthor_{unique_suffix}"
        response = session.put(f"{BASE_URL}/authors/{nonexistent_author_id}", json={"name": new_name}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

@pytest.mark.timeout(TIMEOUT)
def test_update_category_happy_path():
    with requests.Session() as session:
        category = create_category(session)
        unique_suffix = uuid.uuid4().hex[:8]
        new_name = f"NewCategory_{unique_suffix}"
        response = session.put(f"{BASE_URL}/categories/{category['id']}", json={"name": new_name}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        updated_category = response.json()
        assert updated_category["name"] == new_name

@pytest.mark.timeout(TIMEOUT)
def test_update_nonexistent_category_error():
    with requests.Session() as session:
        nonexistent_category_id = 9999
        unique_suffix = uuid.uuid4().hex[:8]
        new_name = f"NewCategory_{unique_suffix}"
        response = session.put(f"{BASE_URL}/categories/{nonexistent_category_id}", json={"name": new_name}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.NOT_FOUND
        data = response.json()
        assert "detail" in data

def test_update_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        unique_suffix = uuid.uuid4().hex[:8]
        new_title = f"NewBook_{unique_suffix}"
        new_isbn = f"978-3-16-{random.randint(100000, 999999)}-{unique_suffix[:5]}"
        response = session.put(f"{BASE_URL}/books/{book['id']}", json={
            "title": new_title,
            "isbn": new_isbn
        }, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.OK
        updated_book = response.json()
        assert updated_book["title"] == new_title
        assert updated_book["isbn"] == new_isbn

def test_add_item_to_order_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        category = create_category(session)
        book = create_book(session, author["id"], category["id"])
        order = create_order(session)

        response = session.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book["id"]}, timeout=TIMEOUT)
        assert response.status_code == HTTPStatus.CREATED
        item = response.json()
        assert item["book_id"] == book["id"]
        assert item["order_id"] == order["id"]
