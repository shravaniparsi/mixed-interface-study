# Main errors were due to string length exceeding limits for fields like name and title. Fixed by reducing the unique suffix length.
# Additionally, some endpoints required headers that were missing in the requests.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title, author_id, category_id, stock):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to 6 characters
    title_with_suffix = f"{title}_{unique_suffix}"
    response = requests.post(
        f"{BASE_URL}/books",
        json={"title": title_with_suffix, "author_id": author_id, "category_id": category_id, "stock": stock},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}  # Added API key header if required
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to 6 characters
    name_with_suffix = f"{name}_{unique_suffix}"
    response = requests.post(
        f"{BASE_URL}/authors",
        json={"name": name_with_suffix},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}  # Added API key header if required
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to 6 characters
    name_with_suffix = f"{name}_{unique_suffix}"
    response = requests.post(
        f"{BASE_URL}/categories",
        json={"name": name_with_suffix},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}  # Added API key header if required
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to 6 characters
    customer_name_with_suffix = f"{customer_name}_{unique_suffix}"
    response = requests.post(
        f"{BASE_URL}/orders",
        json={"customer_name": customer_name_with_suffix},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}  # Added API key header if required
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, book_id, quantity):
    response = requests.post(
        f"{BASE_URL}/orders/{order_id}/add_item",
        json={"book_id": book_id, "quantity": quantity},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}  # Added API key header if required
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    data = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_all_books_edge_case_no_books():
    data = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)
    assert len(data["items"]) == 0

def test_create_book_happy_path():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    assert "id" in book_data
    assert "title" in book_data
    assert "author_id" in book_data
    assert "category_id" in book_data
    assert "stock" in book_data

def test_create_book_error_missing_required_fields():
    response = requests.post(f"{BASE_URL}/books", json={}, timeout=TIMEOUT)
    assert response.status_code == 422
    r = response.json()
    assert "detail" in r

def test_get_book_by_id_happy_path():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.get(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT, headers={"X-API-Key": "your_api_key_here"})
    data = response.json()
    assert "id" in data
    assert "title" in data
    assert "author_id" in data
    assert "category_id" in data
    assert "stock" in data

def test_get_book_by_id_error_invalid_id():
    response = requests.get(f"{BASE_URL}/books/9999", timeout=TIMEOUT)
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_update_book_happy_path():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    new_title = f"Updated Title_{uuid.uuid4().hex[:8]}"
    response = requests.put(
        f"{BASE_URL}/books/{book_data['id']}",
        json={"title": new_title, "author_id": book_data["author_id"], "category_id": book_data["category_id"], "stock": book_data["stock"]},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "id" in data
    assert "title" in data
    assert data["title"] == new_title

def test_update_book_error_invalid_id():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.put(
        f"{BASE_URL}/books/9999",
        json={"title": "Updated Title", "author_id": book_data["author_id"], "category_id": book_data["category_id"], "stock": book_data["stock"]},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}
    )
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_delete_book_happy_path():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.delete(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT, headers={"X-API-Key": "your_api_key_here"})
    assert response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_delete_book_error_invalid_id():
    response = requests.delete(f"{BASE_URL}/books/9999", timeout=TIMEOUT)
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_get_all_authors_happy_path():
    create_author("Author")
    data = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_all_authors_edge_case_no_authors():
    data = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)
    assert len(data["items"]) == 0

def test_create_author_happy_path():
    author_data = create_author("Test Author")
    assert "id" in author_data
    assert "name" in author_data

def test_create_author_error_missing_required_fields():
    response = requests.post(f"{BASE_URL}/authors", json={}, timeout=TIMEOUT)
    assert response.status_code == 422
    r = response.json()
    assert "detail" in r

def test_get_author_by_id_happy_path():
    author_data = create_author("Test Author")
    data = requests.get(f"{BASE_URL}/authors/{author_data['id']}", timeout=TIMEOUT).json()
    assert "id" in data
    assert "name" in data

def test_get_author_by_id_error_invalid_id():
    response = requests.get(f"{BASE_URL}/authors/9999", timeout=TIMEOUT)
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_get_all_categories_happy_path():
    create_category("Category")
    data = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_all_categories_edge_case_no_categories():
    data = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)
    assert len(data["items"]) == 0

def test_create_category_happy_path():
    category_data = create_category("Test Category")
    assert "id" in category_data
    assert "name" in category_data

def test_create_category_error_missing_required_fields():
    response = requests.post(f"{BASE_URL}/categories", json={}, timeout=TIMEOUT)
    assert response.status_code == 422
    r = response.json()
    assert "detail" in r

def test_get_category_by_id_happy_path():
    category_data = create_category("Test Category")
    data = requests.get(f"{BASE_URL}/categories/{category_data['id']}", timeout=TIMEOUT).json()
    assert "id" in data
    assert "name" in data

def test_get_category_by_id_error_invalid_id():
    response = requests.get(f"{BASE_URL}/categories/9999", timeout=TIMEOUT)
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_get_all_orders_happy_path():
    data = requests.get(f"{BASE_URL}/orders", timeout=TIMEOUT).json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_create_order_happy_path():
    order_data = create_order("Test Customer")
    assert "id" in order_data
    assert "customer_name" in order_data

def test_create_order_error_missing_required_fields():
    response = requests.post(f"{BASE_URL}/orders", json={}, timeout=TIMEOUT)
    assert response.status_code == 422
    r = response.json()
    assert "detail" in r

def test_add_item_to_order_happy_path():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    order_data = create_order("Test Customer")
    item_data = add_item_to_order(order_data["id"], book_data["id"], 2)
    assert "order_id" in item_data
    assert "book_id" in item_data
    assert "quantity" in item_data

def test_add_item_to_order_error_invalid_book_id():
    order_data = create_order("Test Customer")
    response = requests.post(
        f"{BASE_URL}/orders/{order_data['id']}/add_item",
        json={"book_id": 9999, "quantity": 2},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}
    )
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_add_item_to_order_error_invalid_order_id():
    author = create_author("Author")
    category = create_category("Category")
    book_data = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.post(
        f"{BASE_URL}/orders/9999/add_item",
        json={"book_id": book_data["id"], "quantity": 2},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}
    )
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r


def test_create_author_with_long_name_happy_path():
    long_name = 'a' * 100  # Assuming the name field can handle up to 100 characters
    author_response = create_author(long_name)
    assert author_response['name'] == f"{long_name}_{author_response['id']}"

def test_update_author_with_new_name_happy_path():
    initial_name = 'Initial Name'
    updated_name = 'Updated Name'
    author_response = create_author(initial_name)
    author_id = author_response['id']
    response = requests.put(
        f"{BASE_URL}/authors/{author_id}",
        json={"name": updated_name},
        timeout=TIMEOUT,
        headers={"X-API-Key": "your_api_key_here"}
    )
    assert response.status_code == 200, f"Update failed {response.status_code}: {response.text[:200]}"
    updated_author_response = response.json()
    assert updated_author_response['name'] == f"{updated_name}_{author_id}"