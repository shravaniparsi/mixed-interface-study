# The main errors were due to string length limitations in unique names and ISBNs. Fixed by reducing the length of the prefix or using slicing to ensure compliance with API constraints.
# Additionally, some helpers were missing required fields that caused validation errors.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(session, title=None, isbn=None):
    if title is None:
        title = f"Bk_{uuid.uuid4().hex[:6]}"
    if isbn is None:
        isbn = f"978-3-16-{uuid.uuid4().hex[:5]}X"
    response = session.post(f"{BASE_URL}/books", json={"title": title, "isbn": isbn, "author_id": 1, "category_id": 1, "stock": 5}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(session, name=None):
    if name is None:
        name = f"Auth_{uuid.uuid4().hex[:6]}"
    response = session.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(session, name=None):
    if name is None:
        name = f"Ctg_{uuid.uuid4().hex[:6]}"
    response = session.post(f"{BASE_URL}/categories", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(session, name=None):
    if name is None:
        name = f"Tg_{uuid.uuid4().hex[:6]}"
    response = session.post(f"{BASE_URL}/tags", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(session):
    response = session.post(f"{BASE_URL}/orders", json={"items": [{"book_id": 1, "quantity": 2}]}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books", timeout=TIMEOUT)
        data = response.json()
        assert response.status_code == 200
        assert "items" in data

def test_create_book_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        assert "id" in book

def test_create_book_with_invalid_data_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/books", json={"title": "Invalid Book", "isbn": "123"})
        r = response.json()
        assert response.status_code == 422
        assert "detail" in r

def test_update_book_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        new_title = f"UpdatedTitle_{uuid.uuid4().hex[:8]}"
        response = session.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title, "isbn": book["isbn"], "author_id": book["author_id"], "category_id": book["category_id"], "stock": book["stock"]})
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == new_title

def test_update_nonexistent_book_error():
    with requests.Session() as session:
        response = session.put(f"{BASE_URL}/books/9999", json={"title": "NonExistentTitle"})
        r = response.json()
        assert response.status_code == 404
        assert "detail" in r

def test_delete_book_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        response = session.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        assert response.status_code == 204
        get_response = session.get(f"{BASE_URL}/books/{book['id']}")
        assert get_response.status_code == 410

def test_delete_nonexistent_book_error():
    with requests.Session() as session:
        response = session.delete(f"{BASE_URL}/books/9999", timeout=TIMEOUT)
        assert response.status_code == 404

def test_get_all_authors():
    with requests.Session() as session:
        author = create_author(session)
        response = session.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
        data = response.json()
        assert response.status_code == 200
        assert isinstance(data, list)

def test_create_author_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        assert "id" in author

def test_create_author_with_invalid_data_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/authors", json={})
        r = response.json()
        assert response.status_code == 422
        assert "detail" in r

def test_get_all_categories():
    with requests.Session() as session:
        category = create_category(session)
        response = session.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
        data = response.json()
        assert response.status_code == 200
        assert isinstance(data, list)

def test_create_category_happy_path():
    with requests.Session() as session:
        category = create_category(session)
        assert "id" in category

def test_create_category_with_invalid_data_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/categories", json={})
        r = response.json()
        assert response.status_code == 422
        assert "detail" in r

def test_get_all_tags():
    with requests.Session() as session:
        tag = create_tag(session)
        response = session.get(f"{BASE_URL}/tags", timeout=TIMEOUT)
        data = response.json()
        assert response.status_code == 200
        assert isinstance(data, list)

def test_create_tag_happy_path():
    with requests.Session() as session:
        tag = create_tag(session)
        assert "id" in tag

def test_create_tag_with_invalid_data_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/tags", json={})
        r = response.json()
        assert response.status_code == 422
        assert "detail" in r

def test_get_all_orders():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
        data = response.json()
        assert response.status_code == 200
        assert "items" in data

def test_create_order_happy_path():
    with requests.Session() as session:
        order = create_order(session)
        assert "id" in order

def test_create_order_with_invalid_data_error():
    with requests.Session() as session:
        response = session.post(f"{BASE_URL}/orders", json={"items": []})
        r = response.json()
        assert response.status_code == 422
        assert "detail" in r

def test_update_order_status_happy_path():
    with requests.Session() as session:
        order = create_order(session)
        response = session.patch(f"{BASE_URL}/orders/{order['id']}", json={"status": "completed"})
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "completed"


def test_get_author_not_found():
    session = requests.Session()
    author_id = 999999
    response = session.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert response.status_code == 404

def test_update_nonexistent_author_error():
    session = requests.Session()
    author_id = 999999
    update_data = {"name": "Updated Author"}
    response = session.put(f"{BASE_URL}/authors/{author_id}", json=update_data, timeout=TIMEOUT)
    assert response.status_code == 404

def test_create_author_with_long_name_error():
    session = requests.Session()
    long_name = "a" * 256
    response = session.post(f"{BASE_URL}/authors", json={"name": long_name}, timeout=TIMEOUT)
    assert response.status_code == 422

def test_get_author_happy_path():
    session = requests.Session()
    author_response = create_author(session)
    author_id = author_response['id']
    response = session.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert response.status_code == 200
    assert response.json()['name'] == author_response['name']

def test_update_author_happy_path():
    session = requests.Session()
    author_response = create_author(session)
    author_id = author_response['id']
    update_data = {"name": "Updated Author"}
    response = session.put(f"{BASE_URL}/authors/{author_id}", json=update_data, timeout=TIMEOUT)
    assert response.status_code == 200
    assert response.json()['name'] == update_data['name']

def test_get_authors_with_skip_and_limit():
    session = requests.Session()
    for _ in range(3):
        create_author(session)
    skip = 1
    limit = 1
    response = session.get(f"{BASE_URL}/authors?skip={skip}&limit={limit}", timeout=TIMEOUT)
    assert response.status_code == 200
    assert len(response.json()) == limit

def test_create_category_with_long_name_error():
    session = requests.Session()
    long_name = "a" * 256
    response = session.post(f"{BASE_URL}/categories", json={"name": long_name}, timeout=TIMEOUT)
    assert response.status_code == 422

def test_get_all_authors_with_empty_database():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
        assert response.status_code == 200
        assert len(response.json()) == 0

def test_health_check_happy_path():
    session = requests.Session()
    response = session.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert response.status_code == 200

def test_method_not_allowed_error():
    session = requests.Session()
    response = session.post(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert response.status_code == 405