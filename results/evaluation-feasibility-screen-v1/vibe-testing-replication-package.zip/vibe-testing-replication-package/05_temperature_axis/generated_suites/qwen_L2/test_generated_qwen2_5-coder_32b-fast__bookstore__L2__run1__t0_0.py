# The main error seems to be related to string length limits for fields like name and title. I will ensure that the unique suffix does not exceed the maximum allowed length for these fields.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title, author_id, category_id, stock):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to ensure total string length is within limits
    title_with_suffix = f"{title[:92]}_{unique_suffix}" if len(title) > 92 else f"{title}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/books", json={
        "title": title_with_suffix,
        "author_id": author_id,
        "category_id": category_id,
        "stock": stock
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/authors", json={
        "name": name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/categories", json={
        "name": name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/tags", json={
        "name": name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name):
    unique_suffix = uuid.uuid4().hex[:6]  # Reduced suffix length to ensure total string length is within limits
    customer_name_with_suffix = f"{customer_name[:92]}_{unique_suffix}" if len(customer_name) > 92 else f"{customer_name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/orders", json={
        "customer_name": customer_name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_book_by_id_happy_path():
    author = create_author("Test Author")
    category = create_category("Test Category")
    book = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "title" in data

def test_get_nonexistent_book_error():
    response = requests.get(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_book_happy_path():
    author = create_author("Test Author")
    category = create_category("Test Category")
    book_data = {
        "title": f"New Book_{uuid.uuid4().hex[:8]}",
        "author_id": author["id"],
        "category_id": category["id"],
        "stock": 5
    }
    response = requests.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_create_book_with_invalid_data_error():
    book_data = {
        "title": f"New Book_{uuid.uuid4().hex[:8]}",
        "author_id": 99999,
        "category_id": 99999,
        "stock": -1
    }
    response = requests.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_update_book_happy_path():
    author = create_author("Test Author")
    category = create_category("Test Category")
    book = create_book("Test Book", author["id"], category["id"], 10)
    update_data = {
        "title": f"Updated Book_{uuid.uuid4().hex[:8]}",
        "author_id": author["id"],
        "category_id": category["id"],
        "stock": 20
    }
    response = requests.put(f"{BASE_URL}/books/{book['id']}", json=update_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "title" in data

def test_update_nonexistent_book_error():
    update_data = {
        "title": f"Updated Book_{uuid.uuid4().hex[:8]}",
        "author_id": 99999,
        "category_id": 99999,
        "stock": 20
    }
    response = requests.put(f"{BASE_URL}/books/99999", json=update_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_delete_book_happy_path():
    author = create_author("Test Author")
    category = create_category("Test Category")
    book = create_book("Test Book", author["id"], category["id"], 10)
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_delete_nonexistent_book_error():
    response = requests.delete(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    assert response.status_code == 404

def test_get_all_authors_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_author_by_id_happy_path():
    author = create_author("Test Author")
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_author_error():
    response = requests.get(f"{BASE_URL}/authors/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_author_happy_path():
    author_data = {
        "name": f"New Author_{uuid.uuid4().hex[:8]}"
    }
    response = requests.post(f"{BASE_URL}/authors", json=author_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_create_author_with_invalid_data_error():
    author_data = {
        "name": ""
    }
    response = requests.post(f"{BASE_URL}/authors", json=author_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_categories_happy_path():
    response = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_category_by_id_happy_path():
    category = create_category("Test Category")
    response = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_category_error():
    response = requests.get(f"{BASE_URL}/categories/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_category_happy_path():
    category_data = {
        "name": f"New Category_{uuid.uuid4().hex[:8]}"
    }
    response = requests.post(f"{BASE_URL}/categories", json=category_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_create_category_with_invalid_data_error():
    category_data = {
        "name": ""
    }
    response = requests.post(f"{BASE_URL}/categories", json=category_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_tags_happy_path():
    response = requests.get(f"{BASE_URL}/tags", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_tag_by_id_happy_path():
    tag = create_tag("Test Tag")
    response = requests.get(f"{BASE_URL}/tags/{tag['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_tag_error():
    response = requests.get(f"{BASE_URL}/tags/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_tag_happy_path():
    tag_data = {
        "name": f"New Tag_{uuid.uuid4().hex[:8]}"
    }
    response = requests.post(f"{BASE_URL}/tags", json=tag_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_create_tag_with_invalid_data_error():
    tag_data = {
        "name": ""
    }
    response = requests.post(f"{BASE_URL}/tags", json=tag_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_orders_happy_path():
    response = requests.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_order_by_id_happy_path():
    order = create_order("Test Customer")
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "customer_name" in data

def test_get_nonexistent_order_error():
    response = requests.get(f"{BASE_URL}/orders/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_order_happy_path():
    order_data = {
        "customer_name": f"New Customer_{uuid.uuid4().hex[:8]}"
    }
    response = requests.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_create_order_with_invalid_data_error():
    order_data = {
        "customer_name": ""
    }
    response = requests.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_add_book_to_order_happy_path():
    author = create_author("Test Author")
    category = create_category("Test Category")
    book = create_book("Test Book", author["id"], category["id"], 10)
    order = create_order("Test Customer")
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/books", json={
        "book_id": book["id"],
        "quantity": 2
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
