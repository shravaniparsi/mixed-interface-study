# Main errors are likely due to string length constraints on fields like name or isbn. I will ensure that the generated strings do not exceed typical limits by adjusting the unique function and ensuring all fields comply with expected lengths.

import requests
import uuid

BASE_URL = "http://localhost:8000"

def unique_name(prefix):
    return f'{prefix}_{uuid.uuid4().hex[:6]}'  # Adjusted to ensure the total length does not exceed typical limits

def create_author(name):
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=30)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    response = requests.post(f"{BASE_URL}/categories", json={"name": name}, timeout=30)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_book(title, author_id, category_id):
    isbn = unique_name("isbn")
    response = requests.post(f"{BASE_URL}/books", json={"title": title, "author_id": author_id, "category_id": category_id, "isbn": isbn}, timeout=30)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name):
    response = requests.post(f"{BASE_URL}/orders", json={"customer_name": customer_name}, timeout=30)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_authors_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data or isinstance(data, list)

def test_create_author_happy_path():
    name = unique_name("author")
    author = create_author(name)
    assert "id" in author

def test_get_author_by_id_happy_path():
    name = unique_name("author")
    author = create_author(name)
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "name" in data

def test_get_nonexistent_author_error():
    response = requests.get(f"{BASE_URL}/authors/99999", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_get_all_categories_happy_path():
    response = requests.get(f"{BASE_URL}/categories", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data or isinstance(data, list)

def test_create_category_happy_path():
    name = unique_name("category")
    category = create_category(name)
    assert "id" in category

def test_get_category_by_id_happy_path():
    name = unique_name("category")
    category = create_category(name)
    response = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "name" in data

def test_get_nonexistent_category_error():
    response = requests.get(f"{BASE_URL}/categories/99999", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_get_all_books_happy_path():
    response = requests.get(f"{BASE_URL}/books", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data or isinstance(data, list)

def test_create_book_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    assert "id" in book

def test_get_book_by_id_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "title" in data

def test_get_nonexistent_book_error():
    response = requests.get(f"{BASE_URL}/books/99999", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_delete_book_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert response.status_code == 204
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert response.status_code == 410

def test_delete_nonexistent_book_error():
    response = requests.delete(f"{BASE_URL}/books/99999", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_get_all_orders_happy_path():
    response = requests.get(f"{BASE_URL}/orders", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data or isinstance(data, list)

def test_create_order_happy_path():
    customer_name = unique_name("customer")
    order = create_order(customer_name)
    assert "id" in order

def test_get_order_by_id_happy_path():
    customer_name = unique_name("customer")
    order = create_order(customer_name)
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "customer_name" in data

def test_get_nonexistent_order_error():
    response = requests.get(f"{BASE_URL}/orders/99999", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_add_item_to_order_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    customer_name = unique_name("customer")
    order = create_order(customer_name)
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json={"book_id": book["id"], "quantity": 1}, timeout=30)
    assert response.status_code == 201
    data = response.json()
    assert "items" in data

def test_add_nonexistent_book_to_order_error():
    customer_name = unique_name("customer")
    order = create_order(customer_name)
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json={"book_id": 99999, "quantity": 1}, timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_get_statistics_happy_path():
    response = requests.get(f"{BASE_URL}/statistics", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "total_books" in data

def test_bulk_create_books_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    books_data = [
        {"title": unique_name("book"), "author_id": author["id"], "category_id": category["id"], "isbn": unique_name("isbn")},
        {"title": unique_name("book"), "author_id": author["id"], "category_id": category["id"], "isbn": unique_name("isbn")}
    ]
    response = requests.post(f"{BASE_URL}/books/bulk", json={"books": books_data}, timeout=30)
    assert response.status_code == 201
    data = response.json()
    assert isinstance(data, list)
    for book in data:
        assert "id" in book

def test_bulk_create_books_with_invalid_data_error():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    books_data = [
        {"title": "", "author_id": author["id"], "category_id": category["id"], "isbn": unique_name("isbn")},
        {"title": unique_name("book"), "author_id": 99999, "category_id": category["id"], "isbn": unique_name("isbn")}
    ]
    response = requests.post(f"{BASE_URL}/books/bulk", json={"books": books_data}, timeout=30)
    assert response.status_code == 422
    data = response.json()
    assert "detail" in data

def test_clone_book_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    response = requests.post(f"{BASE_URL}/books/{book['id']}/clone", timeout=30)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_clone_nonexistent_book_error():
    response = requests.post(f"{BASE_URL}/books/99999/clone", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data

def test_get_invoice_by_order_id_happy_path():
    author = create_author(unique_name("author"))
    category = create_category(unique_name("category"))
    title = unique_name("book")
    book = create_book(title, author["id"], category["id"])
    customer_name = unique_name("customer")
    order = create_order(customer_name)
    requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json={"book_id": book["id"], "quantity": 1}, timeout=30)
    response = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=30)
    assert response.status_code == 200
    data = response.json()
    assert "total" in data

def test_get_invoice_by_nonexistent_order_error():
    response = requests.get(f"{BASE_URL}/orders/99999/invoice", timeout=30)
    assert response.status_code == 404
    data = response.json()
    assert "detail" in data


def test_create_author_with_long_name():
    long_name = "a" * 2048
    response = requests.post(f"{BASE_URL}/authors", json={"name": long_name}, timeout=30)
    assert response.status_code == 422, f"Expected 422 but got {response.status_code}"
    detail = response.json().get("detail")
    assert any(d["type"] == "value_error.any_str.max_length" for d in detail), f"Incorrect validation error: {detail}"

def test_update_author_not_found():
    author_id = 999999
    new_name = unique_name("updated_author")
    response = requests.put(f"{BASE_URL}/authors/{author_id}", json={"name": new_name}, timeout=30)
    assert response.status_code == 404, f"Expected 404 but got {response.status_code}"
    error_message = response.json().get("detail")[0].get("msg")
    assert error_message == "Author not found", f"Incorrect error message: {error_message}"

def test_get_author_with_if_none_match():
    author_name = unique_name("test_author")
    author_data = create_author(author_name)
    author_id = author_data["id"]
    etag = author_data['etag']
    headers = {"If-None-Match": etag}
    response = requests.get(f"{BASE_URL}/authors/{author_id}", headers=headers, timeout=30)
    assert response.status_code == 304, f"Expected 304 but got {response.status_code}"