# The main error is likely due to string length exceeding limits for name or ISBN fields. I will ensure the generated strings are within acceptable lengths.
# Additionally, some endpoints might require headers like X-API-Key or ETag which are currently missing.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title_prefix="Book", isbn_prefix="978-3-16"):
    title = f"{title_prefix}_{uuid.uuid4().hex[:8]}"  # Reduced length to ensure it fits within limits
    isbn = f"{isbn_prefix}-{uuid.uuid4().hex[:5]}"   # Reduced length to ensure it fits within limits
    response = requests.post(f"{BASE_URL}/books", json={"title": title, "isbn": isbn}, timeout=TIMEOUT)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(customer_name="John Doe"):
    response = requests.post(f"{BASE_URL}/orders", json={"customer_name": customer_name}, timeout=TIMEOUT)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name_prefix="Author"):
    name = f"{name_prefix}_{uuid.uuid4().hex[:8]}"  # Reduced length to ensure it fits within limits
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_book_by_id_happy_path():
    book = create_book()
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data
    assert data["title"] == book["title"]

def test_get_non_existent_book_error():
    response = requests.get(f"{BASE_URL}/books/999999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_new_book_happy_path():
    book_data = create_book()
    assert "id" in book_data
    assert "title" in book_data

def test_create_order_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/orders", json={}, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_add_item_to_order_happy_path():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=TIMEOUT)
    assert response.status_code == 201

def test_add_item_to_non_existent_order_error():
    item_data = {"book_id": 999999, "quantity": 1}
    response = requests.post(f"{BASE_URL}/orders/999999/add_item", json=item_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_add_non_existent_book_to_order_error():
    order = create_order()
    item_data = {"book_id": 999999, "quantity": 1}
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_delete_order_item_happy_path():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    item_response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=TIMEOUT)
    item = item_response.json()
    response = requests.delete(f"{BASE_URL}/orders/{order['id']}/items/{item['id']}", timeout=TIMEOUT)
    assert response.status_code == 204

def test_delete_non_existent_order_item_error():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=TIMEOUT)
    response = requests.delete(f"{BASE_URL}/orders/{order['id']}/items/999999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_get_invoice_for_order_happy_path():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=TIMEOUT)
    response = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_invoice_for_non_existent_order_error():
    response = requests.get(f"{BASE_URL}/orders/999999/invoice", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_get_statistics_happy_path():
    response = requests.get(f"{BASE_URL}/statistics", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "total_books" in data

def test_get_all_authors_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_author_by_id_happy_path():
    author = create_author()
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data
    assert data["name"] == author["name"]

def test_get_non_existent_author_error():
    response = requests.get(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_new_author_happy_path():
    author_data = create_author()
    assert "id" in author_data
    assert "name" in author_data


def test_create_author_with_invalid_data_error():
    response = requests.post(f"{BASE_URL}/authors", json={"name": 123}, timeout=TIMEOUT)
    assert response.status_code == 422
    assert "name" in response.json()["detail"][0]["loc"]

def test_update_author_happy_path():
    author = create_author()
    new_name = f"Author_{uuid.uuid4().hex[:8]}"
    response = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=TIMEOUT)
    assert response.status_code == 200
    assert response.json()["name"] == new_name

def test_update_non_existent_author_error():
    non_existent_id = 999999
    response = requests.put(f"{BASE_URL}/authors/{non_existent_id}", json={"name": "New Name"}, timeout=TIMEOUT)
    assert response.status_code == 404

def test_list_authors_with_pagination_happy_path():
    for _ in range(3):
        create_author()
    response = requests.get(f"{BASE_URL}/authors?skip=1&limit=2", timeout=TIMEOUT)
    assert response.status_code == 200
    authors = response.json()
    assert len(authors) == 2

def test_list_authors_empty_response_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    assert response.status_code == 200
    assert response.json() == []

def test_get_author_with_if_none_match_header_not_modified():
    author = create_author()
    etag = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT).headers.get('ETag')
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", headers={"If-None-Match": etag}, timeout=TIMEOUT)
    assert response.status_code == 304

def test_get_author_with_if_match_header_precondition_failed():
    author = create_author()
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", headers={"If-Match": "wrong-etag"}, timeout=TIMEOUT)
    assert response.status_code == 412

def test_health_check_happy_path():
    response = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert response.status_code == 200
    assert response.json() == {}

def test_method_not_allowed_error():
    response = requests.put(f"{BASE_URL}/health", timeout=TIMEOUT)
    assert response.status_code == 405

def test_rate_limit_exceeded_bulk_books_endpoint():
    for _ in range(3):
        create_book()
    response = requests.post(f"{BASE_URL}/books/bulk", json=[{"title": "Book1", "isbn": "978-3-16-1234567"}, {"title": "Book2", "isbn": "978-3-16-7654321"}], timeout=TIMEOUT)
    assert response.status_code == 429

def test_rate_limit_exceeded_discount_endpoint():
    book = create_book()
    for _ in range(5):
        requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"percentage": 10}, timeout=TIMEOUT)
    response = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json={"percentage": 10}, timeout=TIMEOUT)
    assert response.status_code == 429

def test_maintenance_mode_error():
    response = requests.get(f"{BASE_URL}/authors", headers={"X-API-Key": "maintenance-key"}, timeout=TIMEOUT)
    assert response.status_code == 503

def test_create_author_with_long_name_happy_path():
    long_name = f"Author_{uuid.uuid4().hex[:8] * 10}"
    response = requests.post(f"{BASE_URL}/authors", json={"name": long_name}, timeout=TIMEOUT)
    assert response.status_code == 201
    assert response.json()["name"] == long_name