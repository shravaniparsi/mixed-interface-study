# The main error seems to be related to string length limits for fields like 'name' in authors, categories, tags, etc. I will ensure that the generated names do not exceed the expected length by truncating them if necessary.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title_prefix="book", author_id=None, category_id=None):
    title = f"{title_prefix}_{uuid.uuid4().hex[:8]}"[:100]  # Ensure the title does not exceed 100 characters
    data = {
        "title": title,
        "author_id": author_id,
        "category_id": category_id
    }
    response = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name_prefix="author"):
    name = f"{name_prefix}_{uuid.uuid4().hex[:8]}"[:50]  # Ensure the name does not exceed 50 characters
    data = {"name": name}
    response = requests.post(f"{BASE_URL}/authors", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name_prefix="category"):
    name = f"{name_prefix}_{uuid.uuid4().hex[:8]}"[:50]  # Ensure the name does not exceed 50 characters
    data = {"name": name}
    response = requests.post(f"{BASE_URL}/categories", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(name_prefix="tag"):
    name = f"{name_prefix}_{uuid.uuid4().hex[:8]}"[:50]  # Ensure the name does not exceed 50 characters
    data = {"name": name}
    response = requests.post(f"{BASE_URL}/tags", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order():
    data = {}
    response = requests.post(f"{BASE_URL}/orders", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, book_id):
    data = {"book_id": book_id}
    response = requests.post(f"{BASE_URL}/orders/{order_id}/add_item", json=data, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_book_by_id_happy_path():
    book = create_book()
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data

def test_get_nonexistent_book_error():
    response = requests.get(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_book_happy_path():
    book = create_book()
    assert "id" in book

def test_create_book_with_invalid_data_error():
    data = {"title": ""}
    response = requests.post(f"{BASE_URL}/books", json=data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_update_book_happy_path():
    book = create_book()
    new_title = f"updated_{uuid.uuid4().hex[:8]}"
    data = {"title": new_title}
    response = requests.put(f"{BASE_URL}/books/{book['id']}", json=data, timeout=TIMEOUT)
    updated_book = response.json()
    assert response.status_code == 200
    assert "id" in updated_book
    assert updated_book["title"] == new_title

def test_update_nonexistent_book_error():
    data = {"title": f"updated_{uuid.uuid4().hex[:8]}"}
    response = requests.put(f"{BASE_URL}/books/99999", json=data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_delete_book_happy_path():
    book = create_book()
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_delete_nonexistent_book_error():
    response = requests.delete(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    assert response.status_code == 404

def test_get_all_authors_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_author_by_id_happy_path():
    author = create_author()
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data

def test_get_nonexistent_author_error():
    response = requests.get(f"{BASE_URL}/authors/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_author_happy_path():
    author = create_author()
    assert "id" in author

def test_create_author_with_invalid_data_error():
    data = {"name": ""}
    response = requests.post(f"{BASE_URL}/authors", json=data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_categories_happy_path():
    response = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_category_by_id_happy_path():
    category = create_category()
    response = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data

def test_get_nonexistent_category_error():
    response = requests.get(f"{BASE_URL}/categories/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_category_happy_path():
    category = create_category()
    assert "id" in category

def test_create_category_with_invalid_data_error():
    data = {"name": ""}
    response = requests.post(f"{BASE_URL}/categories", json=data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_tags_happy_path():
    response = requests.get(f"{BASE_URL}/tags", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_tag_by_id_happy_path():
    tag = create_tag()
    response = requests.get(f"{BASE_URL}/tags/{tag['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data

def test_get_nonexistent_tag_error():
    response = requests.get(f"{BASE_URL}/tags/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_tag_happy_path():
    tag = create_tag()
    assert "id" in tag

def test_create_tag_with_invalid_data_error():
    data = {"name": ""}
    response = requests.post(f"{BASE_URL}/tags", json=data, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_all_orders_happy_path():
    response = requests.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_order_by_id_happy_path():
    order = create_order()
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data

def test_get_nonexistent_order_error():
    response = requests.get(f"{BASE_URL}/orders/99999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_create_order_happy_path():
    order = create_order()
    assert "id" in order

def test_add_item_to_order_happy_path():
    book = create_book()
    order = create_order()
    item = add_item_to_order(order['id'], book['id'])
    assert "id" in item
    assert item["book_id"] == book["id"]


def test_update_author_with_invalid_data_error():
    author = create_author()
    invalid_data = {"name": 123}  # Invalid data type for name
    response = requests.put(f"{BASE_URL}/authors/{author['id']}", json=invalid_data, timeout=TIMEOUT)
    assert response.status_code == 422
    error_response = response.json()
    assert "detail" in error_response
    assert len(error_response["detail"]) == 1
    assert error_response["detail"][0]["loc"] == ["body", "name"]
    assert error_response["detail"][0]["msg"] == "str type expected"
    assert error_response["detail"][0]["type"] == "type_error.integer"