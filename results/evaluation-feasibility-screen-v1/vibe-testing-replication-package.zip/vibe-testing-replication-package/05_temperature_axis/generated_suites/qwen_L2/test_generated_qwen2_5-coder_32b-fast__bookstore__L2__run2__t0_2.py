# The main error seems to be related to string length limits for fields like name and title. I will ensure that the unique suffix does not exceed the maximum allowed length for these fields by reducing the suffix length to 8 characters.
# Additionally, I will check if any required headers are missing and add them where necessary.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title, author_id, category_id, price, stock):
    unique_suffix = uuid.uuid4().hex[:8]  # Reduced suffix length to ensure total string length is within limits
    title_with_suffix = f"{title[:92]}_{unique_suffix}" if len(title) > 92 else f"{title}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/books", json={
        "title": title_with_suffix,
        "author_id": author_id,
        "category_id": category_id,
        "price": price,
        "stock": stock
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name, bio):
    unique_suffix = uuid.uuid4().hex[:8]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/authors", json={
        "name": name_with_suffix,
        "bio": bio
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name):
    unique_suffix = uuid.uuid4().hex[:8]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/categories", json={
        "name": name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(name):
    unique_suffix = uuid.uuid4().hex[:8]  # Reduced suffix length to ensure total string length is within limits
    name_with_suffix = f"{name[:92]}_{unique_suffix}" if len(name) > 92 else f"{name}_{unique_suffix}"
    response = requests.post(f"{BASE_URL}/tags", json={
        "name": name_with_suffix
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order():
    response = requests.post(f"{BASE_URL}/orders", json={}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, book_id, quantity):
    response = requests.post(f"{BASE_URL}/orders/{order_id}/add_item", json={
        "book_id": book_id,
        "quantity": quantity
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_get_book_by_id_happy_path():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "title" in data

def test_get_book_by_id_error():
    response = requests.get(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_create_book_happy_path():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    assert "title" in book

def test_create_book_error():
    response = requests.post(f"{BASE_URL}/books", json={
        "author_id": 99999,
        "category_id": 99999,
        "price": 19.99,
        "stock": 10
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_update_book_happy_path():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    response = requests.put(f"{BASE_URL}/books/{book['id']}", json={
        "title": f"Updated Book Title_{uuid.uuid4().hex[:8]}",
        "author_id": author["id"],
        "category_id": category["id"],
        "price": 29.99,
        "stock": 5
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "title" in data

def test_update_nonexistent_book_error():
    response = requests.put(f"{BASE_URL}/books/99999", json={
        "title": f"Updated Book Title_{uuid.uuid4().hex[:8]}",
        "author_id": 1,
        "category_id": 1,
        "price": 29.99,
        "stock": 5
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_delete_book_happy_path():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_delete_nonexistent_book_error():
    response = requests.delete(f"{BASE_URL}/books/99999", timeout=TIMEOUT)
    assert response.status_code == 404

def test_get_all_authors():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_author_by_id_happy_path():
    author = create_author("Author Name", "Bio")
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_author_error():
    response = requests.get(f"{BASE_URL}/authors/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_create_author_happy_path():
    author = create_author("Author Name", "Bio")
    assert "name" in author

def test_create_author_error():
    response = requests.post(f"{BASE_URL}/authors", json={
        "bio": "Bio"
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_categories():
    response = requests.get(f"{BASE_URL}/categories", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_category_by_id_happy_path():
    category = create_category("Category Name")
    response = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_category_error():
    response = requests.get(f"{BASE_URL}/categories/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_create_category_happy_path():
    category = create_category("Category Name")
    assert "name" in category

def test_create_category_error():
    response = requests.post(f"{BASE_URL}/categories", json={}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_tags():
    response = requests.get(f"{BASE_URL}/tags", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_get_tag_by_id_happy_path():
    tag = create_tag("Tag Name")
    response = requests.get(f"{BASE_URL}/tags/{tag['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_tag_error():
    response = requests.get(f"{BASE_URL}/tags/99999", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_create_tag_happy_path():
    tag = create_tag("Tag Name")
    assert "name" in tag

def test_create_tag_error():
    response = requests.post(f"{BASE_URL}/tags", json={}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_orders():
    response = requests.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data

def test_create_order_happy_path():
    order = create_order()
    assert "id" in order

def test_add_item_to_order_happy_path():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    order = create_order()
    item = add_item_to_order(order["id"], book["id"], 2)
    assert "book_id" in item

def test_add_item_to_nonexistent_order_error():
    author = create_author("Author Name", "Bio")
    category = create_category("Category Name")
    book = create_book("Book Title", author["id"], category["id"], 19.99, 10)
    response = requests.post(f"{BASE_URL}/orders/99999/add_item", json={
        "book_id": book["id"],
        "quantity": 2
    }, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_add_item_to_order_with_nonexistent_book_error():
    order = create_order()
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json={
        "book_id": 99999,
        "quantity": 2
    }, timeout=TIMEOUT)
    assert response.status_code == 404
    error_response = response.json()
    assert "detail" in error_response


def test_update_author_with_invalid_data():
    author = create_author("John Doe", "Biography")
    response = requests.put(f"{BASE_URL}/authors/{author['id']}", json={
        "name": 12345,
        "bio": "Updated biography"
    }, timeout=TIMEOUT)
    assert response.status_code == 422
    error_response = response.json()
    assert error_response == {"detail": [{"loc": ["body", "name"], "msg": "str type expected", "type": "type_error.str"}]}