import requests
import pytest
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def unique_name(prefix):
    return f'{prefix}_{uuid.uuid4().hex[:8]}'

def create_book(session, title, author_id, category_id, isbn, stock):
    response = session.post(f"{BASE_URL}/books/", json={
        "title": title,
        "author_id": author_id,
        "category_id": category_id,
        "isbn": isbn,
        "stock": stock
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(session, name, bio):
    response = session.post(f"{BASE_URL}/authors/", json={
        "name": name,
        "bio": bio
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(session, name, description):
    response = session.post(f"{BASE_URL}/categories/", json={
        "name": name,
        "description": description
    }, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

@pytest.fixture(scope="module")
def session():
    with requests.Session() as s:
        yield s

def test_get_all_books_happy_path(session):
    r = session.get(f"{BASE_URL}/books/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data or isinstance(data, list)

def test_get_all_books_edge_case_no_books(session):
    r = session.get(f"{BASE_URL}/books/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 0

def test_create_book_happy_path(session):
    author = create_author(session, unique_name("author"), "Bio")
    category = create_category(session, unique_name("category"), "Description")
    book_title = unique_name("book")
    book_isbn = f"978316{uuid.uuid4().hex[:5]}"
    response = session.post(f"{BASE_URL}/books/", json={
        "title": book_title,
        "author_id": author["id"],
        "category_id": category["id"],
        "isbn": book_isbn,
        "stock": 10
    }, timeout=TIMEOUT)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_create_book_error_invalid_data(session):
    r = session.post(f"{BASE_URL}/books/", json={
        "title": "",
        "author_id": -1,
        "category_id": -1,
        "isbn": "invalid_isbn",
        "stock": -1
    }, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_update_book_happy_path(session):
    author = create_author(session, unique_name("author"), "Bio")
    category = create_category(session, unique_name("category"), "Description")
    book_title = unique_name("book")
    book_isbn = f"978316{uuid.uuid4().hex[:5]}"
    book = create_book(session, book_title, author["id"], category["id"], book_isbn, 10)
    new_title = unique_name("new_book")
    response = session.put(f"{BASE_URL}/books/{book['id']}", json={
        "title": new_title,
        "author_id": author["id"],
        "category_id": category["id"],
        "isbn": book_isbn,
        "stock": 15
    }, timeout=TIMEOUT)
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == new_title

def test_update_book_error_invalid_id(session):
    r = session.put(f"{BASE_URL}/books/999999", json={
        "title": unique_name("book"),
        "author_id": 1,
        "category_id": 1,
        "isbn": f"978316{uuid.uuid4().hex[:5]}",
        "stock": 10
    }, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_book_happy_path(session):
    author = create_author(session, unique_name("author"), "Bio")
    category = create_category(session, unique_name("category"), "Description")
    book_title = unique_name("book")
    book_isbn = f"978316{uuid.uuid4().hex[:5]}"
    book = create_book(session, book_title, author["id"], category["id"], book_isbn, 10)
    response = session.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    r = session.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 410

def test_delete_book_error_invalid_id(session):
    r = session.delete(f"{BASE_URL}/books/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_get_all_authors_happy_path(session):
    r = session.get(f"{BASE_URL}/authors/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data or isinstance(data, list)

def test_get_all_authors_edge_case_no_authors(session):
    r = session.get(f"{BASE_URL}/authors/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 0

def test_create_author_happy_path(session):
    author_name = unique_name("author")
    response = session.post(f"{BASE_URL}/authors/", json={
        "name": author_name,
        "bio": "Bio"
    }, timeout=TIMEOUT)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_create_author_error_invalid_data(session):
    r = session.post(f"{BASE_URL}/authors/", json={
        "name": "",
        "bio": "Bio"
    }, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_update_author_happy_path(session):
    author_name = unique_name("author")
    author = create_author(session, author_name, "Bio")
    new_name = unique_name("new_author")
    response = session.put(f"{BASE_URL}/authors/{author['id']}", json={
        "name": new_name,
        "bio": "New Bio"
    }, timeout=TIMEOUT)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == new_name

def test_update_author_error_invalid_id(session):
    r = session.put(f"{BASE_URL}/authors/999999", json={
        "name": unique_name("author"),
        "bio": "Bio"
    }, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_author_happy_path(session):
    author_name = unique_name("author")
    author = create_author(session, author_name, "Bio")
    response = session.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    r = session.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert r.status_code == 404

def test_delete_author_error_invalid_id(session):
    r = session.delete(f"{BASE_URL}/authors/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_get_all_categories_happy_path(session):
    r = session.get(f"{BASE_URL}/categories/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data or isinstance(data, list)

def test_get_all_categories_edge_case_no_categories(session):
    r = session.get(f"{BASE_URL}/categories/", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 0

def test_create_category_happy_path(session):
    category_name = unique_name("category")
    response = session.post(f"{BASE_URL}/categories/", json={
        "name": category_name,
        "description": "Description"
    }, timeout=TIMEOUT)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_create_category_error_invalid_data(session):
    r = session.post(f"{BASE_URL}/categories/", json={
        "name": "",
        "description": "Description"
    }, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_update_category_happy_path(session):
    category_name = unique_name("category")
    category = create_category(session, category_name, "Description")
    new_name = unique_name("new_category")
    response = session.put(f"{BASE_URL}/categories/{category['id']}", json={
        "name": new_name,
        "description": "New Description"
    }, timeout=TIMEOUT)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == new_name

def test_update_category_error_invalid_id(session):
    r = session.put(f"{BASE_URL}/categories/999999", json={
        "name": unique_name("category"),
        "description": "Description"
    }, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_category_happy_path(session):
    category_name = unique_name("category")
    category = create_category(session, category_name, "Description")
    response = session.delete(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert response.status_code == 204
    r = session.get(f"{BASE_URL}/categories/{category['id']}", timeout=TIMEOUT)
    assert r.status_code == 404

def test_delete_category_error_invalid_id(session):
    r = session.delete(f"{BASE_URL}/categories/999999", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data


def test_create_author_with_long_bio(session):
    name = unique_name("Author")
    long_bio = "a" * 1024  # Assuming bio has a max length of 1024 characters
    author_response = create_author(session, name, long_bio)
    assert author_response["name"] == name
    assert author_response["bio"] == long_bio

def test_get_author_not_found(session):
    response = session.get(f"{BASE_URL}/authors/99999", timeout=TIMEOUT)
    assert response.status_code == 404
    assert response.json() == {"detail": "Author not found"}

def test_update_nonexistent_author(session):
    author_id = 99999
    update_data = {
        "name": unique_name("Updated Author"),
        "bio": "Updated bio"
    }
    response = session.put(f"{BASE_URL}/authors/{author_id}", json=update_data, timeout=TIMEOUT)
    assert response.status_code == 404
    assert response.json() == {"detail": "Author not found"}

def test_create_author_with_missing_name(session):
    response = session.post(f"{BASE_URL}/authors/", json={"bio": "Bio only"}, timeout=TIMEOUT)
    assert response.status_code == 422
    assert response.json()["detail"][0]["loc"] == ["body", "name"]
    assert response.json()["detail"][0]["msg"] == "Field required"

def test_create_author_with_missing_bio(session):
    response = session.post(f"{BASE_URL}/authors/", json={"name": unique_name("Author")}, timeout=TIMEOUT)
    assert response.status_code == 422
    assert response.json()["detail"][0]["loc"] == ["body", "bio"]
    assert response.json()["detail"][0]["msg"] == "Field required"

def test_create_author_with_invalid_data_types(session):
    response = session.post(f"{BASE_URL}/authors/", json={"name": 12345, "bio": True}, timeout=TIMEOUT)
    assert response.status_code == 422
    assert response.json()["detail"][0]["loc"] == ["body", "name"]
    assert response.json()["detail"][0]["msg"] == "str type expected"
    assert response.json()["detail"][1]["loc"] == ["body", "bio"]
    assert response.json()["detail"][1]["msg"] == "str type expected"