# Main error is due to string length limitations on fields like 'title' and 'isbn'. Fixed by shortening unique suffixes.
# Additionally, some helpers were missing required headers or incorrect status codes.

import requests
import uuid

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(session, title="Sample Book", isbn=None, author_id=1, category_id=1, stock=10):
    if isbn is None:
        isbn = f"978-3-16-{uuid.uuid4().hex[:5]}"
    response = session.post(
        f"{BASE_URL}/books",
        json={
            "title": title + "_" + uuid.uuid4().hex[:6],
            "isbn": isbn,
            "author_id": author_id,
            "category_id": category_id,
            "stock": stock
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(session, name="Sample Author"):
    response = session.post(
        f"{BASE_URL}/authors",
        json={
            "name": name + "_" + uuid.uuid4().hex[:6]
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(session, name="Sample Category"):
    response = session.post(
        f"{BASE_URL}/categories",
        json={
            "name": name + "_" + uuid.uuid4().hex[:6]
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_tag(session, name="Sample Tag"):
    response = session.post(
        f"{BASE_URL}/tags",
        json={
            "name": name + "_" + uuid.uuid4().hex[:6]
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_review(session, book_id, rating=5, comment="Great book!"):
    response = session.post(
        f"{BASE_URL}/books/{book_id}/reviews",
        json={
            "rating": rating,
            "comment": comment
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(session, items=None):
    if items is None:
        items = [{"book_id": 1, "quantity": 1}]
    response = session.post(
        f"{BASE_URL}/orders",
        json={"items": items},
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_tag_to_book(session, book_id, tag_id):
    response = session.post(
        f"{BASE_URL}/books/{book_id}/tags",
        json={"tag_id": tag_id},
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_book(session, book_id, title="Updated Book"):
    response = session.put(
        f"{BASE_URL}/books/{book_id}",
        json={"title": title + "_" + uuid.uuid4().hex[:6]},
        timeout=TIMEOUT
    )
    assert response.status_code in (200,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_order(session, order_id, status="shipped"):
    response = session.put(
        f"{BASE_URL}/orders/{order_id}",
        json={"status": status},
        timeout=TIMEOUT
    )
    assert response.status_code in (200,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_book(session, book_id):
    session.delete(
        f"{BASE_URL}/books/{book_id}",
        timeout=TIMEOUT
    )

def delete_order(session, order_id):
    session.delete(
        f"{BASE_URL}/orders/{order_id}",
        timeout=TIMEOUT
    )

def add_item_to_order(session, order_id, book_id, quantity=1):
    response = session.post(
        f"{BASE_URL}/orders/{order_id}/items",
        json={"book_id": book_id, "quantity": quantity},
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def bulk_create_books(session, books=None):
    if books is None:
        books = [
            {
                "title": "Bulk Book A_" + uuid.uuid4().hex[:6],
                "isbn": f"978-3-16-{uuid.uuid4().hex[:5]}",
                "author_id": 1,
                "category_id": 1,
                "stock": 5
            },
            {
                "title": "Bulk Book B_" + uuid.uuid4().hex[:6],
                "isbn": f"978-3-16-{uuid.uuid4().hex[:5]}",
                "author_id": 1,
                "category_id": 1,
                "stock": 5
            }
        ]
    response = session.post(
        f"{BASE_URL}/bulk/books",
        json={"books": books},
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def clone_book(session, book_id, title="Cloned Book", isbn=None):
    if isbn is None:
        isbn = f"978-3-16-{uuid.uuid4().hex[:5]}"
    response = session.post(
        f"{BASE_URL}/books/{book_id}/clone",
        json={
            "title": title + "_" + uuid.uuid4().hex[:6],
            "isbn": isbn,
            "stock": 5
        },
        timeout=TIMEOUT
    )
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_books_crud_operations():
    with requests.Session() as session:
        book = create_book(session)
        assert "id" in book

        updated_book = update_book(session, book["id"], title="Updated Book Title_" + uuid.uuid4().hex[:5])
        assert updated_book["title"] == f"Updated Book Title_{updated_book['title'].split('_')[-1]}"

        response = session.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        data = response.json()
        assert data["title"] == updated_book["title"]

        delete_book(session, book["id"])
        response = session.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_authors_crud_operations():
    with requests.Session() as session:
        author = create_author(session)
        assert "id" in author

        response = session.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        data = response.json()
        assert data["name"] == author["name"]

def test_categories_crud_operations():
    with requests.Session() as session:
        category = create_category(session)
        assert "id" in category

        duplicate_response = session.post(
            f"{BASE_URL}/categories",
            json={"name": category["name"] + "_duplicate"},
            timeout=TIMEOUT
        )
        assert duplicate_response.status_code == 201

def test_tags_crud_operations():
    with requests.Session() as session:
        tag = create_tag(session)
        assert "id" in tag

        duplicate_response = session.post(
            f"{BASE_URL}/tags",
            json={"name": tag["name"] + "_duplicate"},
            timeout=TIMEOUT
        )
        assert duplicate_response.status_code == 201

def test_reviews_crud_operations():
    with requests.Session() as session:
        book = create_book(session)
        review = create_review(session, book["id"])
        assert "id" in review

        response = session.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        data = response.json()
        assert len(data["reviews"]) == 1

def test_orders_crud_operations():
    with requests.Session() as session:
        order = create_order(session)
        assert "id" in order

        updated_order = update_order(session, order["id"], status="shipped")
        assert updated_order["status"] == "shipped"

        response = session.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        data = response.json()
        assert data["status"] == "shipped"

        delete_order(session, order["id"])
        response = session.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_add_tag_to_book():
    with requests.Session() as session:
        book = create_book(session)
        tag = create_tag(session)
        add_tag_to_book(session, book["id"], tag["id"])

        response = session.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
        data = response.json()
        assert len(data["tags"]) == 1

def test_add_item_to_order():
    with requests.Session() as session:
        book = create_book(session)
        order = create_order(session, items=[])
        add_item_to_order(session, order["id"], book["id"])

        response = session.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        data = response.json()
        assert len(data["items"]) == 1

def test_bulk_create_books():
    with requests.Session() as session:
        books = bulk_create_books(session)
        assert len(books) == 2
        for book in books:
            assert "id" in book

def test_clone_book():
    with requests.Session() as session:
        original_book = create_book(session)
        cloned_book = clone_book(session, original_book["id"])
        assert "id" in cloned_book
        assert cloned_book["title"] != original_book["title"]
        assert cloned_book["isbn"] != original_book["isbn"]

def test_statistics():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/statistics", timeout=TIMEOUT)
        data = response.json()
        assert "total_books" in data
        assert "total_categories" in data
        assert "total_authors" in data

def test_invalid_isbn():
    with requests.Session() as session:
        book_data = {
            "title": "Invalid ISBN Book_" + uuid.uuid4().hex[:8],
            "isbn": "invalid-isbn",
            "author_id": 1,
            "category_id": 1,
            "stock": 5
        }
        response = session.post(
            f"{BASE_URL}/books",
            json=book_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_book_id():
    with requests.Session() as session:
        non_existent_book_id = 999999
        response = session.get(f"{BASE_URL}/books/{non_existent_book_id}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_invalid_author_id():
    with requests.Session() as session:
        book_data = {
            "title": "Invalid Author Book_" + uuid.uuid4().hex[:8],
            "isbn": f"978-3-16-{uuid.uuid4().hex[:8]}",
            "author_id": 999999,
            "category_id": 1,
            "stock": 5
        }
        response = session.post(
            f"{BASE_URL}/books",
            json=book_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_category_id():
    with requests.Session() as session:
        book_data = {
            "title": "Invalid Category Book_" + uuid.uuid4().hex[:8],
            "isbn": f"978-3-16-{uuid.uuid4().hex[:8]}",
            "author_id": 1,
            "category_id": 999999,
            "stock": 5
        }
        response = session.post(
            f"{BASE_URL}/books",
            json=book_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_order_item():
    with requests.Session() as session:
        book_id = 999999
        order_data = {
            "items": [{"book_id": book_id, "quantity": 1}]
        }
        response = session.post(
            f"{BASE_URL}/orders",
            json=order_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_tag_id():
    with requests.Session() as session:
        book = create_book(session)
        tag_id = 999999
        tag_data = {"tag_id": tag_id}
        response = session.post(
            f"{BASE_URL}/books/{book['id']}/tags",
            json=tag_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_review():
    with requests.Session() as session:
        book_id = 999999
        review_data = {
            "rating": 5,
            "comment": "Invalid Review"
        }
        response = session.post(
            f"{BASE_URL}/books/{book_id}/reviews",
            json=review_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_invalid_update_book():
    with requests.Session() as session:
        book_id = 999999
        update_data = {"title": "Invalid Update"}
        response = session.put(
            f"{BASE_URL}/books/{book_id}",
            json=update_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_invalid_update_order():
    with requests.Session() as session:
        order_id = 999999
        update_data = {"status": "shipped"}
        response = session.put(
            f"{BASE_URL}/orders/{order_id}",
            json=update_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_invalid_delete_book():
    with requests.Session() as session:
        book_id = 999999
        response = session.delete(
            f"{BASE_URL}/books/{book_id}",
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_invalid_delete_order():
    with requests.Session() as session:
        order_id = 999999
        response = session.delete(
            f"{BASE_URL}/orders/{order_id}",
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_invalid_bulk_create_books():
    with requests.Session() as session:
        books_data = [
            {
                "title": "Invalid Bulk Book A_" + uuid.uuid4().hex[:8],
                "isbn": f"978-3-16-{uuid.uuid4().hex[:5]}",
                "author_id": 1,
                "category_id": 1,
                "stock": -5
            }
        ]
        response = session.post(
            f"{BASE_URL}/bulk/books",
            json={"books": books_data},
            timeout=TIMEOUT
        )
        assert response.status_code == 422
        assert "detail" in response.json()

def test_invalid_clone_book():
    with requests.Session() as session:
        book_id = 999999
        clone_data = {
            "title": "Invalid Clone Book_" + uuid.uuid4().hex[:8],
            "isbn": f"978-3-16-{uuid.uuid4().hex[:5]}",
            "stock": 5
        }
        response = session.post(
            f"{BASE_URL}/books/{book_id}/clone",
            json=clone_data,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

def test_search_books():
    with requests.Session() as session:
        book = create_book(session)
        search_response = session.get(f"{BASE_URL}/search?q={book['title']}", timeout=TIMEOUT)
        data = search_response.json()
        assert len(data) > 0
        assert any(b["id"] == book["id"] for b in data)

def test_search_authors():
    with requests.Session() as session:
        author = create_author(session)
        search_response = session.get(f"{BASE_URL}/search?q={author['name']}", timeout=TIMEOUT)
        data = search_response.json()
        assert len(data) > 0
        assert any(a["id"] == author["id"] for a in data)

def test_search_categories():
    with requests.Session() as session:
        category = create_category(session)
        search_response = session.get(f"{BASE_URL}/search?q={category['name']}", timeout=TIMEOUT)
        data = search_response.json()
        assert len(data) > 0
        assert any(c["id"] == category["id"] for c in data)

def test_search_invalid():
    with requests.Session() as session:
        search_response = session.get(f"{BASE_URL}/search?q=invalid-search", timeout=TIMEOUT)
        data = search_response.json()
        assert len(data) == 0

def test_health_check():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        data = response.json()
        assert "status" in data
        assert data["status"] == "ok"


def test_author_put_with_invalid_data():
    session = requests.Session()
    author = create_author(session)
    response = session.put(
        f"{BASE_URL}/authors/{author['id']}",
        json={"name": 123},
        timeout=TIMEOUT
    )
    assert response.status_code == 422, f"Expected 422 for invalid data but got {response.status_code}"
    error_detail = response.json()
    assert error_detail == {"detail": [{"loc": ["body", "name"], "msg": "str type expected", "type": "type_error.str"}]}