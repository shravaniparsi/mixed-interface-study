# The main issue is that some endpoints are returning 422 due to validation errors. This could be because of string length limits on fields like `name` and `isbn`. The unique name generator might produce strings that exceed the allowed character limit. I will adjust the unique name generation to ensure compliance with potential field length constraints.

import uuid
import requests

BASE_URL = "http://127.0.0.1:8000"

def create_unique_name(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:6]}"  # Shortened UUID part to ensure total string length does not exceed typical limits

def create_book(title=None, author_id=None, category_id=None, isbn=None):
    title = title or create_unique_name("Book")
    isbn = isbn or f"978-3-{create_unique_name('isbn')[:9]}"  # Ensure ISBN is exactly 13 characters
    data = {
        "title": title,
        "authorId": author_id,
        "categoryId": category_id,
        "isbn": isbn
    }
    response = requests.post(f"{BASE_URL}/books", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=None):
    name = name or create_unique_name("Author")[:50]  # Ensure name does not exceed a reasonable length
    data = {"name": name}
    response = requests.post(f"{BASE_URL}/authors", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_category(name=None):
    name = name or create_unique_name("Category")[:50]  # Ensure name does not exceed a reasonable length
    data = {"name": name}
    response = requests.post(f"{BASE_URL}/categories", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order():
    response = requests.post(f"{BASE_URL}/orders", timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    book = create_book()
    r = requests.get(f"{BASE_URL}/books", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_get_existing_book_happy_path():
    book = create_book()
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["id"] == book["id"]

def test_get_nonexistent_book_error():
    r = requests.get(f"{BASE_URL}/books/999999", timeout=30)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_create_new_book_happy_path():
    book = create_book()
    assert "id" in book

def test_update_existing_book_happy_path():
    book = create_book()
    new_title = create_unique_name("Updated Book")
    response = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title}, timeout=30)
    data = response.json()
    assert response.status_code == 200
    assert data["title"] == new_title

def test_delete_existing_book_happy_path():
    book = create_book()
    response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert response.status_code == 204
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 404

def test_clone_existing_book_happy_path():
    original_book = create_book(isbn="978-3-123456789")
    response = requests.post(f"{BASE_URL}/books/{original_book['id']}/clone", timeout=30)
    cloned_book = response.json()
    assert response.status_code == 201
    assert "id" in cloned_book

def test_clone_with_invalid_isbn_error():
    original_book = create_book(isbn="978-3-12345678X")
    response = requests.post(f"{BASE_URL}/books/{original_book['id']}/clone", timeout=30)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_upload_cover_happy_path():
    book = create_book()
    files = {'file': ('test.jpg', b'\xff\xd8\xff\xdb')}
    response = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=30)
    assert response.status_code == 201
    data = response.json()
    assert "url" in data

def test_upload_invalid_cover_error():
    book = create_book()
    files = {'file': ('test.txt', b'text')}
    response = requests.post(f"{BASE_URL}/books/{book['id']}/cover", files=files, timeout=30)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_all_authors_happy_path():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_get_existing_author_happy_path():
    author = create_author()
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["id"] == author["id"]

def test_get_nonexistent_author_error():
    r = requests.get(f"{BASE_URL}/authors/999999", timeout=30)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_create_new_author_happy_path():
    author = create_author()
    assert "id" in author

def test_get_all_categories_happy_path():
    category = create_category()
    r = requests.get(f"{BASE_URL}/categories", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_get_existing_category_happy_path():
    category = create_category()
    r = requests.get(f"{BASE_URL}/categories/{category['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["id"] == category["id"]

def test_get_nonexistent_category_error():
    r = requests.get(f"{BASE_URL}/categories/999999", timeout=30)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_create_new_category_happy_path():
    category = create_category()
    assert "id" in category

def test_get_all_orders_happy_path():
    order = create_order()
    r = requests.get(f"{BASE_URL}/orders", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_get_existing_order_happy_path():
    order = create_order()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["id"] == order["id"]

def test_get_nonexistent_order_error():
    r = requests.get(f"{BASE_URL}/orders/999999", timeout=30)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_update_existing_order_happy_path():
    order = create_order()
    new_status = "Shipped"
    response = requests.put(f"{BASE_URL}/orders/{order['id']}", json={"status": new_status}, timeout=30)
    data = response.json()
    assert response.status_code == 200
    assert data["status"] == new_status

def test_add_item_to_existing_order_happy_path():
    book = create_book()
    order = create_order()
    item_data = {"bookId": book["id"], "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=30)
    data = r.json()
    assert r.status_code == 201
    assert "itemId" in data

def test_add_item_with_invalid_book_id_error():
    order = create_order()
    item_data = {"bookId": 999999, "quantity": 1}
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/add_item", json=item_data, timeout=30)
    assert response.status_code == 400

def test_get_statistics_happy_path():
    r = requests.get(f"{BASE_URL}/statistics", timeout=30)
    data = r.json()
    assert r.status_code == 200
    expected_keys = {"numberOfBooks", "numberOfCategories", "numberOfAuthors", "totalOrders", "totalSales"}
    assert all(expected_key in data for expected_key in expected_keys)

def test_get_books_by_author_happy_path():
    author = create_author()
    book1 = create_book(author_id=author['id'])
    book2 = create_book(author_id=author['id'])
    r = requests.get(f"{BASE_URL}/authors/{author['id']}/books", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data
    books_ids = [book["id"] for book in data["items"]]
    assert book1["id"] in books_ids and book2["id"] in books_ids

def test_get_books_by_category_happy_path():
    category = create_category()
    book1 = create_book(category_id=category['id'])
    book2 = create_book(category_id=category['id'])
    r = requests.get(f"{BASE_URL}/categories/{category['id']}/books", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data
    books_ids = [book["id"] for book in data["items"]]
    assert book1["id"] in books_ids and book2["id"] in books_ids

def test_search_books_no_result():
    create_book(title="The Great Adventure")
    r = requests.get(f"{BASE_URL}/books?search=NonExistent", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data and len(data["items"]) == 0

def test_get_book_details_with_nonexistent_id():
    r = requests.get(f"{BASE_URL}/books/999999/details", timeout=30)
    data = r.json()
    assert r.status_code == 404
    assert "detail" in data

def test_search_books_by_title_happy_path():
    create_book(title="Book One")
    create_book(title="Book Two")
    create_book(title="Special Book Three")
    search_r = requests.get(f"{BASE_URL}/books?search=Special", timeout=30)
    search_data = search_r.json()
    assert search_r.status_code == 200
    assert all("special" in book["title"].lower() for book in search_data)
