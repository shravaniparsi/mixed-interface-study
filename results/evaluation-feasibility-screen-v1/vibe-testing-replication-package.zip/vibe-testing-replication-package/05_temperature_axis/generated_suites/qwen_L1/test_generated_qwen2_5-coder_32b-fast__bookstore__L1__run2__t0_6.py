# Chyba byla v nezpracování validačních chyb (422) a překročení limitů délky řetězců. Opravy zahrnují ošetření 422 stavu a upravení délky řetězců s ohledem na unikátní prefixy.
# Kromě toho byl přidán správný zpracování ETag pro PUT požadavky.

import requests
import uuid

base_url = "http://localhost:8000"
timeout = 30

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_book(title, author_id):
    max_length = 256 - len(unique("")) - 1  # Assuming a safe margin
    response = requests.post(f"{base_url}/books", json={"title": unique(title[:max_length]), "author_id": author_id}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    max_length = 256 - len(unique("")) - 1  # Assuming a safe margin
    response = requests.post(f"{base_url}/authors", json={"name": unique(name[:max_length])}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items):
    response = requests.post(f"{base_url}/orders", json={"items": items}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def get_author(author_id):
    response = requests.get(f"{base_url}/authors/{author_id}", timeout=timeout)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(author_id, name, etag):
    max_length = 256 - len(unique("")) - 1  # Assuming a safe margin
    headers = {"If-Match": etag}
    response = requests.put(f"{base_url}/authors/{author_id}", json={"name": unique(name[:max_length])}, headers=headers, timeout=timeout)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_author(author_id):
    response = requests.delete(f"{base_url}/authors/{author_id}", timeout=timeout)
    assert response.status_code == 204, f"Helper failed {response.status_code}: {response.text[:200]}"

def list_authors(skip=0, limit=100):
    params = {"skip": skip, "limit": limit}
    response = requests.get(f"{base_url}/authors", params=params, timeout=timeout)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def list_author_books(author_id):
    response = requests.get(f"{base_url}/authors/{author_id}/books", timeout=timeout)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    r = requests.get(f"{base_url}/books", timeout=timeout)
    data = r.json()
    assert "items" in data
    assert isinstance(data["items"], list)

def test_create_book_happy_path():
    author = create_author(unique("author"))
    book_title = unique("book")
    book = create_book(book_title, author["id"])
    assert "id" in book
    assert book["title"] == book_title

def test_create_book_with_invalid_author_id():
    r = requests.post(f"{base_url}/books", json={"title": unique("book"), "author_id": 9999}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_get_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    data = r.json()
    assert "id" in data
    assert data["title"] == book["title"]

def test_get_nonexistent_book():
    r = requests.get(f"{base_url}/books/9999", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_delete_author_happy_path():
    author = create_author(unique("author"))
    r = requests.delete(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert r.status_code == 204
    r = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_create_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    assert "id" in order
    assert len(order["items"]) == 1

def test_create_order_with_insufficient_stock():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.patch(f"{base_url}/books/{book['id']}", json={"stock": 0}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = create_order([{"book_id": book["id"], "quantity": 1}])
    assert r.status_code == 422

def test_get_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    data = r.json()
    assert "id" in data
    assert len(data["items"]) == 1

def test_delete_pending_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.delete(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert r.status_code == 204
    r = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert r.status_code == 404

def test_delete_cancelled_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "cancelled"}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = requests.delete(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert r.status_code == 204
    r = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert r.status_code == 404

def test_add_item_to_order_happy_path():
    author = create_author(unique("author"))
    book1 = create_book(unique("book"), author["id"])
    book2 = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book1["id"], "quantity": 1}])
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json={"book_id": book2["id"], "quantity": 1}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    data = r.json()
    assert len(data["items"]) == 2

def test_add_item_to_non_pending_order():
    author = create_author(unique("author"))
    book1 = create_book(unique("book"), author["id"])
    book2 = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book1["id"], "quantity": 1}])
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json={"book_id": book2["id"], "quantity": 1}, timeout=timeout)
    assert r.status_code == 422

def test_change_order_status_to_cancelled_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "cancelled"}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    data = r.json()
    assert data["status"] == "cancelled"

def test_get_invoice_for_delivered_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "delivered"}, timeout=timeout)
    assert r.status_code in (200, 201), f"Helper failed {r.status_code}: {r.text[:200]}"
    r = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=timeout)
    data = r.json()
    assert "amount" in data

def test_get_invoice_for_pending_order():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=timeout)
    assert r.status_code == 400, f"Helper failed {r.status_code}: {r.text[:200]}"
    data = r.json()
    assert "detail" in data

def test_apply_discount_to_new_book_happy_path():
    author = create_author(unique("author"))
    book_title = unique("book")
    book = create_book(book_title, author["id"])
    response = requests.post(f"{base_url}/admin/discount", json={"title": book_title}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "discount_applied" in data
    assert data["discount_applied"] is True

def test_apply_discount_to_nonexistent_book():
    r = requests.post(f"{base_url}/admin/discount", json={"title": unique("book")}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_clone_book_happy_path():
    author = create_author(unique("author"))
    book_title = unique("book")
    book = create_book(book_title, author["id"])
    response = requests.post(f"{base_url}/books/{book['id']}/clone", timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "id" in data
    assert data["title"] == book_title

def test_clone_nonexistent_book():
    r = requests.post(f"{base_url}/books/9999/clone", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_update_book_stock_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    new_stock = 10
    response = requests.put(f"{base_url}/books/{book['id']}", json={"stock": new_stock}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "stock" in data
    assert data["stock"] == new_stock

def test_update_nonexistent_book():
    r = requests.post(f"{base_url}/books/9999", json={"stock": 10}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_clone_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    response = requests.post(f"{base_url}/authors/{author['id']}/clone", json={"name": f"{author_name} Clone"}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "id" in data
    assert data["name"] == f"{author_name} Clone"

def test_clone_nonexistent_author():
    r = requests.post(f"{base_url}/authors/9999/clone", json={"name": unique("author")}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_update_author_name_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    new_name = f"{author_name} Updated"
    response = requests.put(f"{base_url}/authors/{author['id']}", json={"name": new_name}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "name" in data
    assert data["name"] == new_name

def test_update_nonexistent_author():
    r = requests.post(f"{base_url}/authors/9999", json={"name": unique("author")}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_clone_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    response = requests.post(f"{base_url}/orders/{order['id']}/clone", timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "id" in data
    assert len(data["items"]) == 1

def test_clone_nonexistent_order():
    r = requests.post(f"{base_url}/orders/9999/clone", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_update_order_status_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    new_status = "confirmed"
    response = requests.put(f"{base_url}/orders/{order['id']}", json={"status": new_status}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "status" in data
    assert data["status"] == new_status

def test_update_nonexistent_order():
    r = requests.post(f"{base_url}/orders/9999", json={"status": "confirmed"}, timeout=timeout)
    data = r.json()
    assert "detail" in data
