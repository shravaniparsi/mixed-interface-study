# The main issue seems to be related to the length of strings being sent in requests, particularly with the `title` and `name` fields. The unique function generates a string that might exceed the maximum allowed length for certain fields. I will ensure that all generated strings are within acceptable limits.

import requests
import uuid

base_url = "http://localhost:8000"
timeout = 30

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"  # Ensure the unique suffix fits within typical field length constraints

def create_book(title=None, author_id=None):
    title = title or unique("book")
    data = {"title": title[:100], "author_id": author_id}  # Ensure the title does not exceed 100 characters
    response = requests.post(f"{base_url}/books", json=data, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=None):
    name = name or unique("author")
    data = {"name": name[:50]}  # Ensure the name does not exceed 50 characters
    response = requests.post(f"{base_url}/authors", json=data, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items=None):
    items = items or []
    data = {"items": items}
    response = requests.post(f"{base_url}/orders", json=data, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_discount(percentage=None):
    percentage = percentage or 10
    data = {"percentage": percentage}
    response = requests.post(f"{base_url}/discounts", json=data, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    r = requests.get(f"{base_url}/books", timeout=timeout)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_book():
    book = create_book()
    assert "id" in book

def test_get_books_edge_case():
    r = requests.get(f"{base_url}/books?limit=1", timeout=timeout)
    data = r.json()
    assert r.status_code == 200
    assert len(data["items"]) <= 1

def test_create_book_invalid_title():
    title = ""
    data = {"title": title}
    r = requests.post(f"{base_url}/books", json=data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_update_book():
    book = create_book()
    new_title = unique("updated_book")
    data = {"title": new_title[:100]}  # Ensure the title does not exceed 100 characters
    response = requests.put(f"{base_url}/books/{book['id']}", json=data, timeout=timeout)
    assert response.status_code == 200
    updated_book = response.json()
    assert updated_book["title"] == new_title

def test_update_book_invalid_title():
    book = create_book()
    data = {"title": ""}
    r = requests.put(f"{base_url}/books/{book['id']}", json=data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_delete_book():
    book = create_book()
    response = requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response.status_code == 204
    r = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert r.status_code == 410

def test_clone_book():
    book = create_book()
    response = requests.post(f"{base_url}/books/{book['id']}/clone", timeout=timeout)
    assert response.status_code == 201
    cloned_book = response.json()
    assert "id" in cloned_book
    assert cloned_book["title"] == book["title"]

def test_bulk_create_books():
    books_data = [{"title": unique("book")[:100]} for _ in range(3)]  # Ensure the title does not exceed 100 characters
    r = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    data = r.json()
    assert r.status_code == 201
    assert len(data) == 3

def test_bulk_create_books_invalid_data():
    books_data = [{"title": ""}]
    r = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_create_order():
    book = create_book()
    items = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(items)
    assert "id" in order

def test_create_order_insufficient_stock():
    book = create_book()
    items = [{"book_id": book["id"], "quantity": 1000}]
    r = requests.post(f"{base_url}/orders", json={"items": items}, timeout=timeout)
    assert r.status_code == 400
    assert "detail" in r.json()

def test_add_item_to_order():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": 1}
    response = requests.post(f"{base_url}/orders/{order['id']}/items", json=item_data, timeout=timeout)
    assert response.status_code == 201
    added_item = response.json()
    assert added_item["book_id"] == book["id"]

def test_add_item_to_order_invalid_quantity():
    order = create_order()
    book = create_book()
    item_data = {"book_id": book["id"], "quantity": -1}
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json=item_data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_update_order_status():
    order = create_order()
    new_status = "completed"
    response = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": new_status}, timeout=timeout)
    updated_order = response.json()
    assert response.status_code == 200
    assert updated_order["status"] == new_status

def test_update_order_status_invalid():
    order = create_order()
    invalid_status = "invalid"
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": invalid_status}, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_order_invoice():
    order = create_order()
    response = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=timeout)
    assert response.status_code == 200

def test_get_order_invoice_invalid_status():
    order = create_order()
    new_status = "pending"
    requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": new_status}, timeout=timeout)
    r = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=timeout)
    assert r.status_code == 403
    assert "detail" in r.json()

def test_create_discount():
    discount = create_discount()
    assert "id" in discount

def test_create_discount_invalid_percentage():
    data = {"percentage": -1}
    r = requests.post(f"{base_url}/discounts", json=data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_add_tags_to_book():
    book = create_book()
    tag_data = {"tags": ["fiction", "novel"]}
    response = requests.post(f"{base_url}/books/{book['id']}/tags", json=tag_data, timeout=timeout)
    assert response.status_code == 201
    updated_book = response.json()
    assert set(updated_book["tags"]) == set(tag_data["tags"])

def test_add_tags_to_non_existent_book():
    non_existent_id = 9999
    tag_data = {"tags": ["fiction", "novel"]}
    r = requests.post(f"{base_url}/books/{non_existent_id}/tags", json=tag_data, timeout=timeout)
    assert r.status_code == 404
    assert "detail" in r.json()

def test_restore_deleted_book():
    book = create_book()
    requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    response = requests.post(f"{base_url}/books/{book['id']}/restore", timeout=timeout)
    restored_book = response.json()
    assert response.status_code == 201
    assert restored_book["title"] == book["title"]

def test_restore_non_deleted_book():
    book = create_book()
    r = requests.post(f"{base_url}/books/{book['id']}/restore", timeout=timeout)
    assert r.status_code == 409
    assert "detail" in r.json()

def test_create_author():
    author = create_author()
    assert "id" in author

def test_create_author_invalid_name():
    data = {"name": ""}
    r = requests.post(f"{base_url}/authors", json=data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_authors():
    r = requests.get(f"{base_url}/authors", timeout=timeout)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_update_author():
    author = create_author()
    new_name = unique("updated_author")
    data = {"name": new_name}
    response = requests.put(f"{base_url}/authors/{author['id']}", json=data, timeout=timeout)
    updated_author = response.json()
    assert response.status_code == 200
    assert updated_author["name"] == new_name

def test_update_author_invalid_name():
    author = create_author()
    data = {"name": ""}
    r = requests.put(f"{base_url}/authors/{author['id']}", json=data, timeout=timeout)
    assert r.status_code == 422
    assert "detail" in r.json()

def test_get_books_by_author():
    author = create_author()
    book_with_author = create_book(author_id=author["id"])
    other_book = create_book()
    response = requests.get(f"{base_url}/books?author_id={author['id']}", timeout=timeout)
    assert response.status_code == 200
    books = response.json()["items"]
    assert any(book["id"] == book_with_author["id"] for book in books)
    assert not any(book["id"] == other_book["id"] for book in books)
