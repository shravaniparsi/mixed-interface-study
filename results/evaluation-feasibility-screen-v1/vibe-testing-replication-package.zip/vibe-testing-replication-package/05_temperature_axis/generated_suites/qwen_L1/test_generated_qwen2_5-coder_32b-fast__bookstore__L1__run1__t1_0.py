# Chyba je kvůli tomu, že uživatelé a knihy mohou mít příliš dlouhé jména (přesáhající 50 znaků). Přidávám omezení na délku kódu.
# Kromě toho se zajistuje, že všechny požadované pole jsou vyplněna a že se používají unikátní názvy.

import uuid
import requests

PREFIX = "test"
TIMEOUT = 30

def unique(prefix=PREFIX):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

BASE_URL = "http://127.0.0.1:8000"

# Helper functions for creating entities
def create_book(title=None, author_id=None, stock=10):
    if title is None:
        title = unique("book")[:50]  # Ensure the book's title does not exceed the allowed length
    payload = {"title": title, "author_id": author_id, "stock": stock}
    response = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=None):
    if name is None:
        name = unique("author")[:50]  # Ensure the author's name does not exceed the allowed length
    payload = {"name": name}
    response = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(author_id=None):
    book = create_book(author_id=author_id)
    payload = {"books": [{"book_id": book["id"], "quantity": 1}], "email": unique("test")[:50] + "@example.com"}
    response = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books_happy_path():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list) or "items" in data

def test_create_book_happy_path():
    book_data = create_book()
    assert "id" in book_data
    assert "title" in book_data

def test_create_book_with_invalid_title():
    payload = {"title": "", "author_id": 1}
    response = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_create_book_with_nonexistent_author():
    payload = {"title": unique("book"), "author_id": 999}
    response = requests.post(f"{BASE_URL}/books", json=payload, timeout=TIMEOUT)
    assert response.status_code == 404
    r = response.json()
    assert "detail" in r

def test_get_authors_happy_path():
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list) or "items" in data

def test_create_author_happy_path():
    author_data = create_author()
    assert "id" in author_data
    assert "name" in author_data

def test_create_author_without_name():
    payload = {"name": ""}
    response = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_author_by_id_happy_path():
    author_data = create_author()
    response = requests.get(f"{BASE_URL}/authors/{author_data['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_nonexistent_author_by_id():
    response = requests.get(f"{BASE_URL}/authors/999", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_delete_author_happy_path():
    author_data = create_author()
    response = requests.delete(f"{BASE_URL}/authors/{author_data['id']}", timeout=TIMEOUT)
    assert response.status_code == 204

def test_delete_nonexistent_author():
    response = requests.delete(f"{BASE_URL}/authors/999", timeout=TIMEOUT)
    assert response.status_code == 404

def test_post_orders_happy_path():
    author_data = create_author()
    order_data = create_order(author_id=author_data['id'])
    assert "id" in order_data

def test_post_order_with_invalid_email():
    book_data = create_book()
    payload = {"books": [{"book_id": book_data["id"], "quantity": 1}], "email": "invalid-email"}
    response = requests.post(f"{BASE_URL}/orders", json=payload, timeout=TIMEOUT)
    assert response.status_code == 422
    r = response.json()
    assert "detail" in r

def test_upload_cover_image_happy_path():
    book_data = create_book()
    files = {"file": ("cover.png", open("cover.png", "rb"))}
    response = requests.patch(f"{BASE_URL}/books/{book_data['id']}/cover", files=files, timeout=TIMEOUT)
    assert response.status_code == 200

def test_upload_large_cover_image():
    book_data = create_book()
    files = {"file": ("large_cover.png", open("large_cover.png", "rb"))} # Ensure this file is larger than the size limit
    response = requests.patch(f"{BASE_URL}/books/{book_data['id']}/cover", files=files, timeout=TIMEOUT)
    assert response.status_code == 413
    r = response.json()
    assert "detail" in r

def test_patch_stock_happy_path():
    book_data = create_book(stock=5)
    payload = {"quantity": 5}
    response = requests.patch(f"{BASE_URL}/books/{book_data['id']}/stock", json=payload, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "stock" in data

def test_patch_negative_stock_quantity():
    book_data = create_book(stock=5)
    payload = {"quantity": -1}
    response = requests.patch(f"{BASE_URL}/books/{book_data['id']}/stock", json=payload, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_delete_tags_happy_path():
    book_data = create_book()
    tag_payload = {"tags": ["fiction"]}
    requests.post(f"{BASE_URL}/books/{book_data['id']}/tags", json=tag_payload, timeout=TIMEOUT)
    delete_payload = {"tag_ids": [1]} # Assuming the tag ID is 1
    response = requests.delete(f"{BASE_URL}/books/{book_data['id']}/tags", json=delete_payload, timeout=TIMEOUT)
    assert response.status_code == 204

def test_delete_nonexistent_tags():
    book_data = create_book()
    delete_payload = {"tag_ids": [999]}
    response = requests.delete(f"{BASE_URL}/books/{book_data['id']}/tags", json=delete_payload, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_post_restore_book_happy_path():
    book_data = create_book()
    requests.delete(f"{BASE_URL}/books/{book_data['id']}", timeout=TIMEOUT)
    response = requests.post(f"{BASE_URL}/books/{book_data['id']}/restore", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "is_deleted" in data and not data["is_deleted"]

def test_restore_undeleted_book():
    book_data = create_book()
    response = requests.post(f"{BASE_URL}/books/{book_data['id']}/restore", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 409
    assert "detail" in r

def test_post_clone_book_happy_path():
    book_data = create_book()
    author_id = book_data.get("author_id")
    response = requests.post(f"{BASE_URL}/books/{book_data['id']}/clone", timeout=TIMEOUT, json={"author_id": author_id})
    clone_data = response.json()
    assert response.status_code == 201
    assert "title" in clone_data

def test_clone_nonexistent_book():
    response = requests.post(f"{BASE_URL}/books/999/clone", timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 404
    assert "detail" in r

def test_post_bulk_books_happy_path():
    author_data = create_author()
    payload = [{"title": unique("book")[:50], "author_id": author_data["id"]} for _ in range(3)]
    response = requests.post(f"{BASE_URL}/books/bulk", json=payload, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert isinstance(data, list) and len(data) == 3

def test_post_bulk_with_invalid_data():
    title = unique("book")
    payload = [{"title": title}, {"title": ""}]
    books = [create_book(title=title)] + payload[1:]
    response = requests.post(f"{BASE_URL}/books/bulk", json=books, timeout=TIMEOUT)
    r = response.json()
    assert response.status_code == 422
    assert "detail" in r

def test_get_books_after_bulk():
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list) or "items" in data and len(data) >= 3


def test_update_author_happy_path():
    author = create_author()
    updated_name = unique("author_updated")
    payload = {"name": updated_name}
    response = requests.put(f"{BASE_URL}/authors/{author['id']}", json=payload, timeout=TIMEOUT)
    assert response.status_code == 200
    updated_author = response.json()
    assert updated_author["id"] == author["id"]
    assert updated_author["name"] == updated_name

def test_update_nonexistent_author():
    non_existent_id = 999999
    payload = {"name": unique("author")}
    response = requests.put(f"{BASE_URL}/authors/{non_existent_id}", json=payload, timeout=TIMEOUT)
    assert response.status_code == 404

def test_create_author_with_empty_string_name():
    payload = {"name": ""}
    response = requests.post(f"{BASE_URL}/authors", json=payload, timeout=TIMEOUT)
    assert response.status_code == 422
    error_details = response.json()
    assert error_details["detail"][0]["loc"][-1] == "name"
    assert error_details["detail"][0]["msg"].startswith("ensure this value has at least")

def test_get_authors_with_pagination():
    for _ in range(5):
        create_author()
    skip = 2
    limit = 2
    response = requests.get(f"{BASE_URL}/authors?skip={skip}&limit={limit}", timeout=TIMEOUT)
    assert response.status_code == 200
    authors = response.json()
    assert len(authors) == limit
    for i, author in enumerate(authors):
        paginated_response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert paginated_response.status_code == 200
        retrieved_author = paginated_response.json()
        assert retrieved_author["name"] == author["name"]