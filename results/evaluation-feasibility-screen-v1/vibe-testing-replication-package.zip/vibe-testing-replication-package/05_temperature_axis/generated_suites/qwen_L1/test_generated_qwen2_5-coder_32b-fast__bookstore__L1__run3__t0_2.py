# Hlavní problém je pravděpodobně překročení maximální délky povolené pro některá pole v API. Oprava spočívá v zkrácení délky generovaných unikátních stringů.
# Další možný problém je špatný formát dat posílaných do API, což vyžaduje opravu struktury JSON.

import uuid
import requests

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"  # Zkrácení délky unikátního stringu

BASE_URL = "http://localhost:8000"

def create_book(title, author_id):
    response = requests.post(f"{BASE_URL}/books", json={"title": title, "author_id": author_id}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    r = requests.get(f"{BASE_URL}/books", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_book_happy_path():
    author = create_author(unique("author"))
    book_title = unique("book")
    book = create_book(book_title, author["id"])
    assert "id" in book
    assert book["title"] == book_title

def test_create_book_with_invalid_data():
    r = requests.post(f"{BASE_URL}/books", json={"title": "", "author_id": 1}, timeout=30)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_books_with_filter():
    author = create_author(unique("author"))
    book_title = unique("book")
    create_book(book_title, author["id"])
    r = requests.get(f"{BASE_URL}/books?title={book_title}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data
    assert len(data["items"]) == 1

def test_get_book_by_id_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "title" in data

def test_get_nonexistent_book():
    r = requests.get(f"{BASE_URL}/books/9999", timeout=30)
    assert r.status_code == 404

def test_update_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    new_title = unique("new_book")
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title}, timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["title"] == new_title

def test_update_nonexistent_book():
    r = requests.put(f"{BASE_URL}/books/9999", json={"title": "new title"}, timeout=30)
    assert r.status_code == 404

def test_delete_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 410

def test_delete_nonexistent_book():
    r = requests.delete(f"{BASE_URL}/books/9999", timeout=30)
    assert r.status_code == 404

def test_get_authors_happy_path():
    r = requests.get(f"{BASE_URL}/authors", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert isinstance(data, list)

def test_create_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    assert "id" in author
    assert author["name"] == author_name

def test_create_author_with_invalid_data():
    r = requests.post(f"{BASE_URL}/authors", json={"name": ""}, timeout=30)
    data = r.json()
    assert r.status_code == 422
    assert "detail" in data

def test_get_author_by_id_happy_path():
    author = create_author(unique("author"))
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert "name" in data

def test_get_nonexistent_author():
    r = requests.get(f"{BASE_URL}/authors/9999", timeout=30)
    assert r.status_code == 404

def test_update_author_happy_path():
    author = create_author(unique("author"))
    new_name = unique("new_author")
    r = requests.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=30)
    data = r.json()
    assert r.status_code == 200
    assert data["name"] == new_name

def test_update_nonexistent_author():
    r = requests.put(f"{BASE_URL}/authors/9999", json={"name": "new name"}, timeout=30)
    assert r.status_code == 404

def test_delete_author_happy_path():
    author = create_author(unique("author"))
    r = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=30)
    assert r.status_code == 404

def test_delete_nonexistent_author():
    r = requests.delete(f"{BASE_URL}/authors/9999", timeout=30)
    assert r.status_code == 404

def test_create_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_data = {"items": [{"book_id": book["id"], "quantity": 1}]}
    r = requests.post(f"{BASE_URL}/orders", json=order_data, timeout=30)
    data = r.json()
    assert r.status_code == 201
    assert "id" in data

def test_create_order_with_insufficient_stock():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_data = {"items": [{"book_id": book["id"], "quantity": 100}]}
    r = requests.post(f"{BASE_URL}/orders", json=order_data, timeout=30)
    data = r.json()
    assert r.status_code == 400
    assert "detail" in data

def test_add_item_to_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{base_url}/orders", json={"items": []}).json()
    item_data = {"book_id": book["id"], "quantity": 1}
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json=item_data)
    data = r.json()
    assert r.status_code == 201
    assert "id" in data

def test_add_item_to_nonexistent_order():
    item_data = {"book_id": 9999, "quantity": 1}
    r = requests.post(f"{base_url}/orders/9999/items", json=item_data)
    assert r.status_code == 404

def test_update_order_status_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{base_url}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    status_data = {"status": "shipped"}
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json=status_data)
    data = r.json()
    assert r.status_code == 200
    assert data["status"] == "shipped"

def test_update_nonexistent_order_status():
    status_data = {"status": "shipped"}
    r = requests.patch(f"{base_url}/orders/9999/status", json=status_data)
    assert r.status_code == 404

def test_get_order_invoice_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{base_url}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    r = requests.get(f"{base_url}/orders/{order['id']}/invoice")
    assert r.status_code == 200

def test_get_invoice_for_nonexistent_order():
    r = requests.get(f"{base_url}/orders/9999/invoice")
    assert r.status_code == 403

def test_apply_discount_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    discount_data = {"book_id": book["id"], "percentage": 10}
    r = requests.post(f"{base_url}/discounts", json=discount_data)
    data = r.json()
    assert r.status_code == 200
    assert "discounted_price" in data

def test_apply_discount_to_old_book():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    discount_data = {"book_id": book["id"], "percentage": 10, "year": 2000}
    r = requests.post(f"{base_url}/discounts", json=discount_data)
    data = r.json()
    assert r.status_code == 400
    assert "detail" in data

def test_bulk_create_books_happy_path():
    author = create_author(unique("author"))
    books_data = [{"title": unique("book"), "author_id": author["id"]} for _ in range(3)]
    r = requests.post(f"{base_url}/books/bulk", json=books_data)
    data = r.json()
    assert r.status_code == 201
    assert len(data) == 3
