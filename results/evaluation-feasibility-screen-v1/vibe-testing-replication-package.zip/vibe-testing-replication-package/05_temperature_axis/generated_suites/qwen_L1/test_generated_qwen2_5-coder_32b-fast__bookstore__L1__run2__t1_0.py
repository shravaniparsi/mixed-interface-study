# Hlavní problémy byly s délkou názvů (title a name) vytvořených helpermi - unique funkce generovala příliš dlouhé řetězce. Omezil jsem délku názvů na 50 znaků, aby odpovídaly limitem API.
# Kromě toho bylo potřeba opravit klíče v datech podávaných do koncových bodů - např. "authorId" změnilo se na "author_id".

import requests
from uuid import uuid4
import time

base_url = "http://localhost:8000"

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_book(title=None, author_id=None):
    title = title or unique("book")[:50]  # Omezit délku názvu knihy na 50 znaků
    data = {"title": title, "author_id": author_id}  # Oprava klíče podle API specifikace
    response = requests.post(f"{base_url}/books", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=None):
    name = name or unique("author")[:50]  # Omezit délku názvu autora na 50 znaků
    data = {"name": name}
    response = requests.post(f"{base_url}/authors", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items=None):
    items = items or []
    data = {"items": items}
    response = requests.post(f"{base_url}/orders", json=data, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def wait_for_api():
    start_time = time.time()
    while True:
        try:
            requests.get(f"{base_url}/health", timeout=5)  # Použití správného koncového bodu pro health check
            break
        except(requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            if time.time() - start_time > 30:
                raise Exception("API did not respond in time")
            time.sleep(1)


def test_get_books():
    wait_for_api()
    r = requests.get(f"{base_url}/books")
    assert r.status_code == 200
    data = r.json()
    assert "items" in data

def test_create_book():
    author = create_author()
    book_data = {"title": unique("book"), "authorId": author["id"]}
    r = requests.post(f"{base_url}/books", json=book_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert "title" in data

def test_get_book_by_id():
    book = create_book()
    r = requests.get(f"{base_url}/books/{book['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert data["title"] == book["title"]

def test_get_nonexistent_book():
    r = requests.get(f"{base_url}/books/9999")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_create_author():
    author_data = {"name": unique("author")}
    r = requests.post(f"{base_url}/authors", json=author_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data
    assert "name" in data

def test_get_author_by_id():
    author = create_author()
    r = requests.get(f"{base_url}/authors/{author['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert data["name"] == author["name"]

def test_get_nonexistent_author():
    r = requests.get(f"{base_url}/authors/9999")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_author_happy_path():
    author = create_author()
    r = requests.delete(f"{base_url}/authors/{author['id']}", timeout=30)
    assert r.status_code == 204

def test_delete_author_with_books():
    author = create_author()
    book = create_book(author_id=author["id"])
    r = requests.delete(f"{base_url}/authors/{author['id']}", timeout=30)
    assert r.status_code == 409
    data = r.json()
    assert "detail" in data

def test_create_order_happy_path():
    book = create_book()
    order_data = {"items": [{"bookId": book["id"], "quantity": 1}]}
    r = requests.post(f"{base_url}/orders", json=order_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_create_order_insufficient_stock():
    book = create_book()
    update_book_stock(book["id"], 0)
    order_data = {"items": [{"bookId": book["id"], "quantity": 1}]}
    r = requests.post(f"{base_url}/orders", json=order_data, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def update_book_stock(book_id, stock):
    payload = {"stock": stock}
    response = requests.patch(f"{base_url}/books/{book_id}", json=payload)
    assert response.status_code == 200

def test_add_item_to_order_happy_path():
    order = create_order()
    book = create_book()
    item_data = {"bookId": book["id"], "quantity": 1}
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json=item_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_add_item_to_closed_order():
    order = create_order()
    update_order_status(order["id"], "closed")
    book = create_book()
    item_data = {"bookId": book["id"], "quantity": 1}
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json=item_data, timeout=30)
    assert r.status_code == 403
    data = r.json()
    assert "detail" in data

def update_order_status(order_id, status):
    payload = {"status": status}
    response = requests.patch(f"{base_url}/orders/{order_id}/status", json=payload)
    assert response.status_code == 200

def test_update_order_status_happy_path():
    order = create_order()
    status_data = {"status": "shipped"}
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json=status_data, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "status" in data
    assert data["status"] == status_data["status"]

def test_update_order_to_invalid_status():
    order = create_order()
    invalid_status_data = {"status": "invalid"}
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json=invalid_status_data, timeout=30)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_delete_order_happy_path():
    order = create_order()
    r = requests.delete(f"{base_url}/orders/{order['id']}", timeout=30)
    assert r.status_code == 204
    get_response = requests.get(f"{base_url}/orders/{order['id']}", timeout=30)
    assert get_response.status_code == 404

def test_delete_nonexistent_order():
    r = requests.delete(f"{base_url}/orders/9999")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_get_order_invoice_happy_path():
    order = create_order()
    update_status_data = {"status": "shipped"}
    requests.patch(f"{base_url}/orders/{order['id']}/status", json=update_status_data, timeout=30)
    invoice_response = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=30)
    assert invoice_response.status_code == 200
    data = invoice_response.json()
    assert "items" in data

def test_get_invoice_for_nonexistent_order():
    r = requests.get(f"{base_url}/orders/9999/invoice")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_bulk_create_books_happy_path():
    books_data = [
        {"title": unique("bulk_book1")[:50]},
        {"title": unique("bulk_book2")[:50]},
        {"title": unique("bulk_book3")[:50]}
    ]
    response = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=30)
    assert response.status_code == 201
    data = response.json()
    assert isinstance(data, list)
    for book in data:
        assert "id" in book

def test_bulk_create_with_invalid_data():
    books_data = [
        {"title": unique("bulk_book")},
        {"invalid_key": "value"}
    ]
    response = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=30)
    assert response.status_code == 422
    data = response.json()
    assert "detail" in data


def test_update_author_happy_path():
    author_data = create_author()
    new_name = unique("updated")[:50]
    response = requests.put(f"{base_url}/authors/{author_data['id']}", json={"name": new_name}, timeout=30)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    updated_author = response.json()
    assert updated_author["name"] == new_name

def test_update_nonexistent_author():
    response = requests.put(f"{base_url}/authors/9999", json={"name": "Nonexistent Author"}, timeout=30)
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_list_authors_with_pagination():
    create_author()
    create_author()
    response = requests.get(f"{base_url}/authors?skip=1&limit=1", timeout=30)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    authors = response.json()
    assert len(authors) == 1

def test_create_book_with_invalid_author():
    invalid_author_id = 9999
    response = requests.post(f"{base_url}/books", json={"title": unique("book"), "author_id": invalid_author_id}, timeout=30)
    assert response.status_code == 422
    data = response.json()
    assert "detail" in data and any(error for error in data["detail"] if "does not exist" in error["msg"]), f"Test failed {response}"

def test_get_books_by_category():
    category_name = unique("category")
    book_data_1 = create_book(title="Book 1", author_id=create_author()["id"])
    book_data_2 = create_book(title="Book 2", author_id=create_author()["id"])
    response = requests.get(f"{base_url}/books?category={category_name}", timeout=30)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    books = response.json()
    assert not any(book["title"] in ("Book 1", "Book 2") for book in books), "Books should be filtered by category"

def test_get_books_with_invalid_sort_param():
    response = requests.get(f"{base_url}/books?sort_by=invalid_field", timeout=30)
    assert response.status_code == 422, f"Test failed {response.status_code}: {response.text[:200]}"
    error_detail = response.json()
    assert "unexpected value; permitted: ['title', 'author']" in str(error_detail["detail"])

def test_create_order_with_empty_items():
    response = create_order(items=[])
    assert response["detail"] and any(error for error in response["detail"] if "ensure this value has at least 1 item" in error["msg"]), f"Test failed {response}"

def test_update_book_happy_path():
    book_data = create_book()
    new_title = unique("updated title")
    response = requests.put(f"{base_url}/books/{book_data['id']}", json={"title": new_title}, timeout=30)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    updated_book = response.json()
    assert updated_book["title"] == new_title

def test_get_author_books():
    author_data = create_author()
    book1_data = create_book(author_id=author_data["id"])
    response = requests.get(f"{base_url}/books?authorId={author_data['id']}", timeout=30)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    books = response.json()
    assert any(book["title"] == book1_data["title"] for book in books), "Book not found in author's book list"