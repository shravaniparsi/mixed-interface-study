# The main issue appears to be that the `create_book` function is sending an incorrect payload structure and possibly exceeding length limits with unique strings. Fixing the payload and ensuring string lengths are within acceptable limits.
# Additionally, some endpoints may require additional headers like API keys or ETags which need to be added to the requests.

import requests
import uuid
import json

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_book(title, author_id):
    # Ensure title length is within acceptable limits and correct payload structure
    unique_title = unique("book")[:50]  # Assuming a reasonable limit for book titles
    response = requests.post(f"{BASE_URL}/books", json={"title": unique_title, "author_id": author_id}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    # Ensure name length is within acceptable limits
    unique_name = unique("author")[:50]  # Assuming a reasonable limit for author names
    response = requests.post(f"{BASE_URL}/authors", json={"name": unique_name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items):
    response = requests.post(f"{BASE_URL}/orders", json={"items": items}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books_happy_path():
    author = create_author(unique("author"))
    book = create_book(author["id"])
    response = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert isinstance(data["items"], list)

def test_get_books_with_filter():
    author = create_author(unique("author"))
    book1 = create_book(author["id"])
    book2 = create_book(author["id"])
    response = requests.get(f"{BASE_URL}/books?title={book1['title']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert len(data["items"]) == 1
    assert data["items"][0]["id"] == book1["id"]

def test_get_books_with_nonexistent_filter():
    response = requests.get(f"{BASE_URL}/books?title={unique('non_existent')}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert len(data["items"]) == 0

def test_create_book_happy_path():
    author = create_author(unique("author"))
    book_data = {"title": unique("book"), "author_id": author["id"]}
    response = requests.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["title"] == book_data["title"]
    assert data["author_id"] == author["id"]

def test_create_book_with_invalid_author():
    book_data = {"title": unique("book"), "author_id": -1}
    response = requests.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 422
    assert "detail" in error_data

def test_get_book_by_id_happy_path():
    author = create_author(unique("author"))
    book = create_book(author["id"])
    response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert data["id"] == book["id"]
    assert data["title"] == book["title"]

def test_get_nonexistent_book():
    response = requests.get(f"{BASE_URL}/books/-1", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_delete_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(author["id"])
    delete_response = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert delete_response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_get_authors_happy_path():
    author1 = create_author(unique("author"))
    author2 = create_author(unique("another_author"))
    response = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert isinstance(data["items"], list)
    ids = [item['id'] for item in data['items']]
    assert author1['id'] in ids
    assert author2['id'] in ids

def test_get_author_by_id_happy_path():
    author = create_author(unique("author"))
    response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert data["id"] == author["id"]
    assert data["name"] == author["name"]

def test_get_nonexistent_author():
    response = requests.get(f"{BASE_URL}/authors/-1", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_delete_author_happy_path():
    author = create_author(unique("author"))
    delete_response = requests.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert delete_response.status_code == 204
    get_response = requests.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
    assert get_response.status_code == 410

def test_create_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_items = [{'book_id': book['id'], 'quantity': 1}]
    response = requests.post(f"{BASE_URL}/orders", json={'items': order_items}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert len(data["items"]) == 1
    assert data["items"][0]["book_id"] == book['id']
    assert data["items"][0]["quantity"] == order_items[0]['quantity']

def test_create_order_with_insufficient_stock():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    response = requests.post(f"{BASE_URL}/books/{book['id']}/stock", json={'quantity': 1}, timeout=TIMEOUT)
    assert response.status_code == 200
    order_items = [{'book_id': book['id'], 'quantity': 5}]
    response = requests.post(f"{BASE_URL}/orders", json={'items': order_items}, timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 400
    assert "detail" in error_data

def test_get_order_by_id_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_items = [{'book_id': book['id'], 'quantity': 1}]
    order = create_order(order_items)
    response = requests.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert data["id"] == order["id"]
    assert len(data["items"]) == 1
    assert data["items"][0]["book_id"] == book['id']

def test_get_nonexistent_order():
    response = requests.get(f"{BASE_URL}/orders/-1", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_add_item_to_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_items = [{'book_id': book['id'], 'quantity': 1}]
    order = create_order(order_items)
    new_book = create_book(unique("another_book"), author["id"])
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json={'book_id': new_book['id'], 'quantity': 2}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert len(data["items"]) == 2
    assert data["items"][1]["book_id"] == new_book['id']
    assert data["items"][1]["quantity"] == 2

def test_add_item_to_nonexistent_order():
    book = create_book(unique("book"), create_author(unique("author"))["id"])
    response = requests.post(f"{BASE_URL}/orders/-1/items", json={'book_id': book['id'], 'quantity': 1}, timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_generate_invoice_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_items = [{'book_id': book['id'], 'quantity': 2}]
    order = create_order(order_items)
    response = requests.post(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "id" in data
    assert data["total"] == 2 * book["price"]

def test_generate_invoice_nonexistent_order():
    response = requests.post(f"{BASE_URL}/orders/-1/invoice", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_get_authors_sorted_by_name():
    author1 = create_author(unique("author_z"))
    author2 = create_author(unique("author_a"))
    response = requests.get(f"{BASE_URL}/authors?sort=name", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert isinstance(data["items"], list)
    assert data["items"][0]["name"] < data["items"][1]["name"]

def test_get_books_sorted_by_title():
    author = create_author(unique("author"))
    book1 = create_book(unique("book_z"), author["id"])
    book2 = create_book(unique("book_a"), author["id"])
    response = requests.get(f"{BASE_URL}/books?sort=title", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert isinstance(data["items"], list)
    assert data["items"][0]["title"] < data["items"][1]["title"]

def test_update_book_stock_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    response = requests.post(f"{BASE_URL}/books/{book['id']}/stock", json={'quantity': 5}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "stock" in data
    assert data["stock"] == 5

def test_update_nonexistent_book_stock():
    response = requests.post(f"{BASE_URL}/books/-1/stock", json={'quantity': 3}, timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_create_bulk_orders_happy_path():
    author = create_author(unique("author"))
    book1 = create_book(unique("book_1"), author["id"])
    book2 = create_book(unique("book_2"), author["id"])
    order_items_list = [
        [{'book_id': book1['id'], 'quantity': 3}],
        [{'book_id': book2['id'], 'quantity': 2}]
    ]
    response = requests.post(f"{BASE_URL}/orders/bulk", json={'orders': order_items_list}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 201
    assert len(data) == 2

def test_create_bulk_orders_with_invalid_book():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order_items_list = [
        [{'book_id': book['id'], 'quantity': 3}],
        [{'book_id': -1, 'quantity': 2}]
    ]
    response = requests.post(f"{BASE_URL}/orders/bulk", json={'orders': order_items_list}, timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 400
    assert "detail" in error_data

def test_get_books_sorted_by_price_desc():
    author = create_author(unique("author"))
    book1 = create_book(unique("book_cheap"), author["id"])
    book2 = create_book(unique("book_expensive"), author["id"])
    response = requests.post(f"{BASE_URL}/books/{book1['id']}/price", json={'price': 10}, timeout=TIMEOUT)
    assert response.status_code == 200
    response = requests.post(f"{BASE_URL}/books/{book2['id']}/price", json={'price': 50}, timeout=TIMEOUT)
    assert response.status_code == 200
    response = requests.get(f"{BASE_URL}/books?sort=-price", timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "items" in data
    assert isinstance(data["items"], list)
    assert data["items"][0]["price"] > data["items"][1]["price"]

def test_update_book_price_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    response = requests.post(f"{BASE_URL}/books/{book['id']}/price", json={'price': 20}, timeout=TIMEOUT)
    data = response.json()
    assert response.status_code == 200
    assert "price" in data
    assert data["price"] == 20

def test_delete_nonexistent_author():
    response = requests.delete(f"{BASE_URL}/authors/-1", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

def test_delete_nonexistent_book():
    response = requests.delete(f"{BASE_URL}/books/-1", timeout=TIMEOUT)
    error_data = response.json()
    assert response.status_code == 404
    assert "detail" in error_data

# Helper functions
def unique(name):
    import uuid
    return f"{name}_{uuid.uuid4().hex[:8]}"

def create_author(name, bio=None):
    author_data = {"name": name}
    if bio:
        author_data["bio"] = bio
    response = requests.post(f"{BASE_URL}/authors", json=author_data, timeout=TIMEOUT)
    assert response.status_code == 201
    return response.json()

def create_book(title, author_id, price=None):
    book_data = {"title": title, "author_id": author_id}
    if price:
        book_data["price"] = price
    response = requests.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
    assert response.status_code == 201
    return response.json()

# Define the base URL for the API and a timeout value
BASE_URL = "http://localhost:5000/api"  # Adjust this to match your API's URL
TIMEOUT = 10

# Run the tests
if __name__ == "__main__":
    import doctest
    doctest.testmod()