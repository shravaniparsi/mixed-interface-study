# The main issue seems to be related to the length of strings being sent in requests, especially when using the unique function. We need to ensure that the generated names and titles do not exceed the maximum allowed length as per the API specification.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

base_url = "http://localhost:8000"
timeout = 30

def create_book(title, author_id):
    # Ensure title does not exceed the maximum allowed length (e.g., 255 characters) after adding unique prefix
    response = requests.post(f"{base_url}/books", json={"title": unique("book")[:247] + title[:8], "author_id": author_id}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    # Ensure name does not exceed the maximum allowed length (e.g., 100 characters) after adding unique prefix
    response = requests.post(f"{base_url}/authors", json={"name": unique("author")[:92] + name[:8]}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(book_id):
    response = requests.post(f"{base_url}/orders", json={"items": [{"book_id": book_id, "quantity": 1}]}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_discount(code, percentage):
    # Ensure code does not exceed the maximum allowed length (e.g., 50 characters) after adding unique prefix
    response = requests.post(f"{base_url}/discounts", json={"code": unique("discount")[:42] + code[:8], "percentage": percentage}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    r = requests.get(f"{base_url}/books", timeout=timeout)
    data = r.json()
    assert "items" in data or isinstance(data, list)

def test_create_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    assert "id" in book

def test_create_book_with_invalid_author_id():
    book_title = unique("book")
    r = requests.post(f"{base_url}/books", json={"title": book_title, "author_id": 9999}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_get_books_with_query_params():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    create_book(book_title, author["id"])
    r = requests.get(f"{base_url}/books?title={book_title}", timeout=timeout)
    data = r.json()
    assert "items" in data and len(data["items"]) == 1

def test_get_books_with_nonexistent_query_params():
    r = requests.get(f"{base_url}/books?title=nonexistent", timeout=timeout)
    data = r.json()
    assert "items" in data and len(data["items"]) == 0

def test_create_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    assert "id" in author

def test_create_author_with_empty_name():
    r = requests.post(f"{base_url}/authors", json={"name": ""}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_delete_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    r = requests.delete(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert r.status_code == 204
    r = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert r.status_code == 404

def test_delete_nonexistent_author():
    r = requests.delete(f"{base_url}/authors/9999", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_create_order_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order(book["id"])
    assert "id" in order

def test_create_order_insufficient_stock():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    r = requests.post(f"{base_url}/orders", json={"items": [{"book_id": book["id"], "quantity": 100}]}, timeout=timeout)
    assert r.status_code == 422

def test_add_item_to_order_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order(book["id"])
    r = requests.post(f"{base_url}/orders/{order['id']}/items", json={"book_id": book["id"], "quantity": 1}, timeout=timeout)
    data = r.json()
    assert "id" in data

def test_add_item_to_nonexistent_order():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    r = requests.post(f"{base_url}/orders/9999/items", json={"book_id": book["id"], "quantity": 1}, timeout=timeout)
    assert r.status_code == 404

def test_update_order_status_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order(book["id"])
    r = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "shipped"}, timeout=timeout)
    data = r.json()
    assert "status" in data and data["status"] == "shipped"

def test_update_nonexistent_order_status():
    r = requests.patch(f"{base_url}/orders/9999/status", json={"status": "shipped"}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_get_order_invoice_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order(book["id"])
    r = requests.get(f"{base_url}/orders/{order['id']}/invoice", timeout=timeout)
    data = r.json()
    assert "total" in data

def test_get_invoice_for_nonexistent_order():
    r = requests.get(f"{base_url}/orders/9999/invoice", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_create_discount_happy_path():
    discount_code = unique("discount")
    discount = create_discount(discount_code, 10)
    assert "id" in discount

def test_create_invalid_discount():
    r = requests.post(f"{base_url}/discounts", json={"code": "", "percentage": 10}, timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_bulk_create_books_happy_path():
    author_name = unique("author")
    book_title_1 = unique("book")
    book_title_2 = unique("book")
    author = create_author(author_name)
    books_data = [
        {"title": book_title_1, "author_id": author["id"]},
        {"title": book_title_2, "author_id": author["id"]}
    ]
    r = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    data = r.json()
    assert isinstance(data, list) and len(data) == 2

def test_bulk_create_books_with_errors():
    author_name = unique("author")
    book_title_1 = unique("book")
    book_title_2 = unique("book")
    author = create_author(author_name)
    books_data = [
        {"title": book_title_1[:247], "author_id": author["id"]},
        {"title": "", "author_id": author["id"]}
    ]
    r = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    data = r.json()
    assert isinstance(data, list) and len(data) == 2
    assert "detail" in data[1]

def test_restore_deleted_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title[:247], author["id"])
    requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    r = requests.post(f"{base_url}/books/{book['id']}/restore", timeout=timeout)
    assert r.status_code == 200

def test_restore_nonexistent_book():
    r = requests.post(f"{base_url}/books/9999/restore", timeout=timeout)
    data = r.json()
    assert "detail" in data

def test_clone_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title[:247], author["id"])
    r = requests.post(f"{base_url}/books/{book['id']}/clone", timeout=timeout)
    data = r.json()
    assert "id" in data

def test_clone_nonexistent_book():
    r = requests.post(f"{base_url}/books/9999/clone", timeout=timeout)
    data = r.json()
    assert "detail" in data


def test_update_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    updated_name = unique("updated_author")
    response = requests.put(f"{base_url}/authors/{author['id']}", json={"name": updated_name}, timeout=timeout)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    updated_author = response.json()
    assert updated_author["name"] == updated_name

def test_update_nonexistent_author():
    non_existent_id = 99999
    new_name = unique("new_name")
    response = requests.put(f"{base_url}/authors/{non_existent_id}", json={"name": new_name}, timeout=timeout)
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_get_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name[:92])
    response = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    retrieved_author = response.json()
    assert retrieved_author["name"] == author_name[:92]

def test_get_nonexistent_author():
    non_existent_id = 99999
    response = requests.get(f"{base_url}/authors/{non_existent_id}", timeout=timeout)
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_list_authors_with_query_params():
    author1_name = unique("author1")
    author2_name = unique("author2")
    create_author(author1_name[:92])
    create_author(author2_name[:92])
    response = requests.get(f"{base_url}/authors?skip=1&limit=1", timeout=timeout)
    assert response.status_code == 200, f"Test failed {response.status_code}: {response.text[:200]}"
    authors = response.json()
    assert len(authors) == 1
    assert authors[0]["name"] in [author1_name[:92], author2_name[:92]]