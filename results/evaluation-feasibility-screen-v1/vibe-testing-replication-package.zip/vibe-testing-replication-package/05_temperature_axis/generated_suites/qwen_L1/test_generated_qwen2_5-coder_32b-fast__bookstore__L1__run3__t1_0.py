# The main issue seems to be validation errors (422) due to incorrect data format or exceeding string length limits. Additionally, PUT requests are missing ETag headers.
# Fixing the data format and ensuring unique strings do not exceed maximum allowed lengths. Adding ETag handling for PUT requests.

import uuid
import requests

BASE_URL = "http://localhost:8000"  # Update with actual base URL if different
TIMEOUT = 30

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

def create_book(session, **params):
    default_params = {
        "title": unique("book"),
        "description": "A great book.",
        "author_id": 1,  # Assuming there's always an author with id 1 or this should be created first
        "price": 19.99,
        "isbn": unique("isbn")
    }
    final_params = {**default_params, **params}
    response = session.post(f"{BASE_URL}/books", json=final_params, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(session, **params):
    default_params = {
        "name": unique("author")
    }
    final_params = {**default_params, **params}
    response = session.post(f"{BASE_URL}/authors", json=final_params, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(session, author_id, **params):
    # Fetch the current ETag
    get_response = session.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert get_response.status_code == 200, f"Helper failed {get_response.status_code}: {get_response.text[:200]}"
    etag = get_response.headers.get('ETag')

    update_response = session.put(f"{BASE_URL}/authors/{author_id}", json=params, headers={"If-Match": etag}, timeout=TIMEOUT)
    assert update_response.status_code == 200, f"Helper failed {update_response.status_code}: {update_response.text[:200]}"
    return update_response.json()

def create_order(session, **params):
    default_params = {
        "book_id": 1,  # Assuming there's always a book with id 1 or this should be created first
        "quantity": 2,
        "customer_name": unique("customer"),
        "customer_email": f"{unique('customer')}@example.com"
    }
    final_params = {**default_params, **params}
    response = session.post(f"{BASE_URL}/orders", json=final_params, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_create_book_happy_path():
    with requests.Session() as session:
        book_data = {
            "title": unique("book"),
            "author_id": create_author(session, name=unique("author"))["id"],
            "price": 19.99,
            "stock": 5
        }
        response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data

def test_create_book_invalid_author():
    with requests.Session() as session:
        book_data = {
            "title": unique("book"),
            "author_id": 999,  # Invalid author ID
            "price": 19.99,
            "stock": 5
        }
        response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert response.status_code == 422 or response.status_code == 400
        data = response.json()
        assert "detail" in data

def test_get_single_book():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)["id"]
        response = session.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "title" in data and data["id"] == book_id

def test_update_book_happy_path():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)["id"]
        update_data = {"price": 24.99}
        get_response = session.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
        assert get_response.status_code == 200
        etag = get_response.headers.get('ETag')
        response = session.put(f"{BASE_URL}/books/{book_id}", json=update_data, headers={"If-Match": etag}, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "price" in data and data["price"] == update_data["price"]

def test_delete_book():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)["id"]
        response = session.delete(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
        assert response.status_code == 204
        response = session.get(f"{BASE_URL}/books/{book_id}", timeout=TIMEOUT)
        assert response.status_code == 410

def test_upload_cover_image():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)["id"]
        files = {"cover": ("dummy.jpg", open("dummy.jpg", "rb"), "image/jpeg")}
        response = session.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
        assert response.status_code == 201

def test_get_cover_image():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)["id"]
        files = {"cover": ("dummy.jpg", open("dummy.jpg", "rb"), "image/jpeg")}
        session.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
        response = session.get(f"{BASE_URL}/books/{book_id}/cover", timeout=TIMEOUT)
        assert response.status_code == 200

def test_create_author_happy_path():
    with requests.Session() as session:
        author_data = {
            "name": unique("author")
        }
        response = session.post(f"{BASE_URL}/authors", json=author_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data

def test_get_single_author():
    with requests.Session() as session:
        author_id = create_author(session, name=unique("author"))["id"]
        response = session.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "name" in data and data["id"] == author_id

def test_update_author_happy_path():
    with requests.Session() as session:
        author_id = create_author(session, name=unique("author"))["id"]
        update_data = {"bio": "Updated bio"}
        response = session.put(f"{BASE_URL}/authors/{author_id}", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "bio" in data and data["bio"] == update_data["bio"]

def test_delete_author():
    with requests.Session() as session:
        author_id = create_author(session, name=unique("author"))["id"]
        response = session.delete(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
        assert response.status_code == 204
        response = session.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_create_order_happy_path():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)
        order_data = {
            "items": [{"book_id": book["id"], "quantity": 2}]
        }
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data

def test_create_order_insufficient_stock():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=0)
        order_data = {
            "items": [{"book_id": book["id"], "quantity": 2}]
        }
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert response.status_code == 400
        data = response.json()
        assert "detail" in data

def test_add_order_item_order_status_pending():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)
        order = create_order(session, items=[{"book_id": book["id"], "quantity": 2}])
        item_data = {"book_id": book["id"], "quantity": 1}
        response = session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "quantity" in data and data["quantity"] == item_data["quantity"]

def test_add_order_item_invalid_status():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99, stock=5)
        order = create_order(session, items=[{"book_id": book["id"], "quantity": 2}])
        response = session.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "completed"}, timeout=TIMEOUT)
        assert response.status_code == 200
        item_data = {"book_id": book["id"], "quantity": 1}
        response = session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        assert response.status_code == 400 or response.status_code == 422
        data = response.json()
        assert "detail" in data

def test_change_order_status():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)
        order = create_order(session, items=[{"book_id": book["id"], "quantity": 2}])
        response = session.patch(f"{BASE_URL}/orders/{order['id']}", json={"status": "completed"}, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "status" in data and data["status"] == "completed"

def test_get_discounted_books():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books?discounted=true", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_get_discounted_books_with_min_price():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books?discounted=true&min_price=19.99", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_create_discount():
    with requests.Session() as session:
        discount_data = {
            "book_id": create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)["id"],
            "percentage": 0.2,
            "start_date": "2023-01-01",
            "end_date": "2024-01-01"
        }
        response = session.post(f"{BASE_URL}/discounts", json=discount_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data

def test_get_discount():
    with requests.Session() as session:
        discount_id = create_discount(session)["id"]
        response = session.get(f"{BASE_URL}/discounts/{discount_id}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "book_id" in data and data["id"] == discount_id

def test_update_discount():
    with requests.Session() as session:
        discount_id = create_discount(session)["id"]
        update_data = {"percentage": 0.3}
        response = session.put(f"{BASE_URL}/discounts/{discount_id}", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "percentage" in data and data["percentage"] == update_data["percentage"]

def test_delete_discount():
    with requests.Session() as session:
        discount_id = create_discount(session)["id"]
        response = session.delete(f"{BASE_URL}/discounts/{discount_id}", timeout=TIMEOUT)
        assert response.status_code == 204
        response = session.get(f"{BASE_URL}/discounts/{discount_id}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_place_order():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)
        order_data = {
            "items": [{"book_id": book["id"], "quantity": 2}]
        }
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "status" in data and data["status"] == "pending"

def test_cancel_order():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)
        order = create_order(session, items=[{"book_id": book["id"], "quantity": 2}])
        response = session.delete(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        assert response.status_code == 204
        response = session.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        assert response.status_code == 404

def test_get_order_history():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/orders", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_apply_coupon():
    with requests.Session() as session:
        book = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)
        order_data = {
            "items": [{"book_id": book["id"], "quantity": 2}],
            "coupon_code": unique("coupon")
        }
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert (response.status_code == 201 or
                response.status_code == 404)  # Assuming code checks existance of coupon

def test_get_authors():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_create_discount_invalid_book():
    with requests.Session() as session:
        discount_data = {
            "book_id": 999,  # Invalid book ID
            "percentage": 0.2,
            "start_date": "2023-01-01",
            "end_date": "2024-01-01"
        }
        response = session.post(f"{BASE_URL}/discounts", json=discount_data, timeout=TIMEOUT)
        assert response.status_code == 422 or response.status_code == 400
        data = response.json()
        assert "detail" in data

def test_upload_large_cover_image():
    with requests.Session() as session:
        book_id = create_book(session, title=unique("book"), author_id=create_author(session, name=unique("author"))["id"], price=19.99)["id"]
        files = {"cover": ("large_dummy.jpg", open("large_dummy.jpg", "rb"), "image/jpeg")}
        response = session.post(f"{BASE_URL}/books/{book_id}/cover", files=files, timeout=TIMEOUT)
        assert response.status_code == 413 or response.status_code == 400  # Assuming server checks file size
