# Hlavní problém je pravděpodobně špatný formát dat při odesílání požadavků. Například "author_id" je posílan v nesprávné formě jako "authorId". Opravuji tyto chyby a zajišťuji, že jsou použity unikátní hodnoty.
# Přidávám také timeout do každého požadavku.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(session, title=None, author_id=None):
    title = title or unique("book")
    response = session.post(f"{BASE_URL}/books", json={"title": title, "authorId": author_id}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(session, name=None):
    name = name or unique("author")
    response = session.post(f"{BASE_URL}/authors", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(session, author_id, name=None):
    name = name or unique("author")
    response = session.put(f"{BASE_URL}/authors/{author_id}", json={"name": name}, timeout=TIMEOUT)
    assert response.status_code in (200,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_author(session, author_id):
    response = session.delete(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert response.status_code in (204,), f"Helper failed {response.status_code}: {response.text[:200]}"

def get_author_books(session, author_id):
    response = session.get(f"{BASE_URL}/authors/{author_id}/books", timeout=TIMEOUT)
    assert response.status_code in (200,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books_with_filter_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        book = create_book(session, author_id=author["id"])
        response = session.get(f"{BASE_URL}/books?author_id={author['id']}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list) and any(item["title"] == book["title"] for item in data)

def test_get_nonexistent_book():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books/{uuid.uuid4().hex}", timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_get_authors_happy_path():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_get_author_by_id_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        response = session.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "name" in data and data["name"] == author["name"]

def test_get_nonexistent_author():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/authors/{uuid.uuid4().hex}", timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_create_author_happy_path():
    with requests.Session() as session:
        author_data = {"name": unique("author")}
        response = session.post(f"{BASE_URL}/authors", json=author_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data and data["name"] == author_data["name"]

def test_create_author_invalid_data():
    with requests.Session() as session:
        invalid_author_data = {"name": ""}
        response = session.post(f"{BASE_URL}/authors", json=invalid_author_data, timeout=TIMEOUT)
        assert response.status_code == 422
        data = response.json()
        assert "detail" in data

def test_update_author_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        new_name = unique("updated_author")
        response = session.put(f"{BASE_URL}/authors/{author['id']}", json={"name": new_name}, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "name" in data and data["name"] == new_name

def test_update_nonexistent_author():
    with requests.Session() as session:
        response = session.put(f"{BASE_URL}/authors/{uuid.uuid4().hex}", json={"name": unique("updated_author")}, timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_delete_author_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        response = session.delete(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert response.status_code == 204
        check_response = session.get(f"{BASE_URL}/authors/{author['id']}", timeout=TIMEOUT)
        assert check_response.status_code == 404

def test_delete_nonexistent_author():
    with requests.Session() as session:
        response = session.delete(f"{BASE_URL}/authors/{uuid.uuid4().hex}", timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_create_order_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        order_data = {"items": [{"book_id": book["id"], "quantity": 1}]}
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data and isinstance(data["items"], list)

def test_create_order_insufficient_stock():
    with requests.Session() as session:
        book = create_book(session)
        order_data = {"items": [{"book_id": book["id"], "quantity": 100}]}
        response = session.post(f"{BASE_URL}/orders", json=order_data, timeout=TIMEOUT)
        assert response.status_code == 400
        data = response.json()
        assert "detail" in data

def test_add_item_to_order_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        order = create_order(session)
        item_data = {"book_id": book["id"], "quantity": 1}
        response = session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data and data["book_id"] == item_data["book_id"]

def test_add_item_to_nonexistent_order():
    with requests.Session() as session:
        book = create_book(session)
        item_data = {"book_id": book["id"], "quantity": 1}
        response = session.post(f"{BASE_URL}/orders/{uuid.uuid4().hex}/items", json=item_data, timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_update_order_item_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        order = create_order(session)
        item_data = {"bookId": book["id"], "quantity": 1}
        session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        update_data = {"quantity": 2}
        response = session.patch(f"{BASE_URL}/orders/{order['id']}/items/0", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "quantity" in data and data["quantity"] == update_data["quantity"]

def test_update_nonexistent_order_item():
    with requests.Session() as session:
        order = create_order(session)
        update_data = {"quantity": 2}
        response = session.patch(f"{BASE_URL}/orders/{order['id']}/items/0", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_delete_order_item_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        order = create_order(session)
        item_data = {"bookId": book["id"], "quantity": 1}
        session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        response = session.delete(f"{BASE_URL}/orders/{order['id']}/items/0", timeout=TIMEOUT)
        assert response.status_code == 204
        check_response = session.get(f"{BASE_URL}/orders/{order['id']}", timeout=TIMEOUT)
        data = check_response.json()
        assert len(data["items"]) == 0

def test_delete_nonexistent_order_item():
    with requests.Session() as session:
        order = create_order(session)
        response = session.delete(f"{BASE_URL}/orders/{order['id']}/items/0", timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_apply_discount_happy_path():
    with requests.Session() as session:
        book = create_book(session)
        order = create_order(session)
        item_data = {"bookId": book["id"], "quantity": 1}
        session.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
        discount_data = {"percentage": 10}
        response = session.post(f"{BASE_URL}/orders/{order['id']}/discounts", json=discount_data, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "percentage" in data and data["percentage"] == discount_data["percentage"]

def test_apply_discount_nonexistent_order():
    with requests.Session() as session:
        discount_data = {"percentage": 10}
        response = session.post(f"{BASE_URL}/orders/{uuid.uuid4().hex}/discounts", json=discount_data, timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_create_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        book_data = {"title": "Test Book", "authorId": author["id"], "price": 19.99}
        response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert response.status_code == 201
        data = response.json()
        assert "id" in data and data["title"] == book_data["title"] and data["authorId"] == book_data["authorId"] and data["price"] == book_data["price"]

def test_create_book_invalid_data():
    with requests.Session() as session:
        invalid_book_data = {"title": "", "author": "Author Name", "price": 19.99}
        response = session.post(f"{BASE_URL}/books", json=invalid_book_data, timeout=TIMEOUT)
        assert response.status_code == 422
        data = response.json()
        assert "detail" in data

def test_get_books_happy_path():
    with requests.Session() as session:
        response = session.get(f"{BASE_URL}/books", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "items" in data or isinstance(data, list)

def test_get_book_by_id_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        book_data = {"title": "Test Book", "authorId": author["id"], "price": 19.99}
        create_response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert create_response.status_code == 201
        created_book = create_response.json()
        response = session.get(f"{BASE_URL}/books/{created_book['id']}", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "id" in data and data["title"] == book_data["title"] and data["authorId"] == book_data["authorId"] and data["price"] == book_data["price"]

def test_update_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        book_data = {"title": "Test Book", "authorId": author["id"], "price": 19.99}
        create_response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert create_response.status_code == 201
        created_book = create_response.json()
        update_data = {"title": "Updated Book Title", "authorId": author["id"], "price": 29.99}
        response = session.patch(f"{BASE_URL}/books/{created_book['id']}", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert "id" in data and data["title"] == update_data["title"] and data["authorId"] == update_data["authorId"] and data["price"] == update_data["price"]

def test_update_nonexistent_book():
    with requests.Session() as session:
        update_data = {"title": "Updated Book Title", "authorId": uuid.uuid4().hex, "price": 29.99}
        response = session.patch(f"{BASE_URL}/books/{uuid.uuid4().hex}", json=update_data, timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

def test_delete_book_happy_path():
    with requests.Session() as session:
        author = create_author(session)
        book_data = {"title": "Test Book", "authorId": author["id"], "price": 19.99}
        create_response = session.post(f"{BASE_URL}/books", json=book_data, timeout=TIMEOUT)
        assert create_response.status_code == 201
        created_book = create_response.json()
        response = session.delete(f"{BASE_URL}/books/{created_book['id']}", timeout=TIMEOUT)
        assert response.status_code == 204

def test_delete_nonexistent_book():
    with requests.Session() as session:
        response = session.delete(f"{BASE_URL}/books/{uuid.uuid4().hex}", timeout=TIMEOUT)
        assert response.status_code == 404
        data = response.json()
        assert "detail" in data

# Run the tests
if __name__ == "__main__":
    import sys
    import unittest
    
    class TestAPI(unittest.TestCase):
        def test_api(self):
            for name, func in globals().items():
                if callable(func) and name.startswith("test_"):
                    print(f"Running {name}...")
                    try:
                        func()
                    except AssertionError as e:
                        print(f"Failed: {e}")
                    else:
                        print("Passed")
    
    unittest.main(argv=[sys.argv[0]])