# Hlavní problém byl v nepoužití unikátních názvů pro knihy a autoře, což vedlo k kolizím při validaci. Fix je implementace funkce unique pro každý název.
# Kromě toho byly přidány nutné hlavičky a kontroly délky stringů.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

BASE_URL = "http://localhost:8000"
headers = {"Content-Type": "application/json"}

def create_author(name, surname):
    unique_name = unique("name")
    unique_surname = unique("surname")
    response = requests.post(f"{BASE_URL}/authors", headers=headers, json={"name": unique_name[:50], "surname": unique_surname[:50]}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_book(title, author_id):
    unique_title = unique("title")
    response = requests.post(f"{BASE_URL}/books", headers=headers, json={"title": unique_title[:255], "author_id": author_id}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items):
    response = requests.post(f"{BASE_URL}/orders", headers=headers, json={"items": items}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def get_author(author_id):
    response = requests.get(f"{BASE_URL}/authors/{author_id}", headers=headers, timeout=30)
    assert response.status_code in (200, 304), f"Helper failed {response.status_code}: {response.text[:200]}"
    if response.status_code == 200:
        return response.json()

def update_author(author_id, name=None, surname=None):
    data = {}
    if name is not None:
        data['name'] = unique("updated_name")[:50]
    if surname is not None:
        data['surname'] = unique("updated_surname")[:50]
    response = requests.put(f"{BASE_URL}/authors/{author_id}", headers=headers, json=data, timeout=30)
    assert response.status_code in (200, 412), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_author(author_id):
    response = requests.delete(f"{BASE_URL}/authors/{author_id}", headers=headers, timeout=30)
    assert response.status_code == 204, f"Helper failed {response.status_code}: {response.text[:200]}"

def get_book(book_id):
    response = requests.get(f"{BASE_URL}/books/{book_id}", headers=headers, timeout=30)
    assert response.status_code in (200, 304), f"Helper failed {response.status_code}: {response.text[:200]}"
    if response.status_code == 200:
        return response.json()

def update_book(book_id, title=None):
    data = {}
    if title is not None:
        data['title'] = unique("updated_title")[:255]
    response = requests.put(f"{BASE_URL}/books/{book_id}", headers=headers, json=data, timeout=30)
    assert response.status_code in (200, 412), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_book(book_id):
    response = requests.delete(f"{BASE_URL}/books/{book_id}", headers=headers, timeout=30)
    assert response.status_code == 204, f"Helper failed {response.status_code}: {response.text[:200]}"

def list_authors(skip=0, limit=100):
    response = requests.get(f"{BASE_URL}/authors", headers=headers, params={"skip": skip, "limit": limit}, timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def list_author_books(author_id):
    response = requests.get(f"{BASE_URL}/authors/{author_id}/books", headers=headers, timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def list_books():
    response = requests.get(f"{BASE_URL}/books", headers=headers, timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    r = requests.get(f"{BASE_URL}/books", headers=headers, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data

def test_create_book_happy_path():
    title = unique("book")
    author = create_author(unique("name"), unique("surname"))
    book = create_book(title, author["id"])
    assert "id" in book
    assert "title" in book and book["title"] == title
    assert "author_id" in book and book["author_id"] == author["id"]

def test_create_book_with_invalid_data_error_case():
    r = requests.post(f"{BASE_URL}/books", headers=headers, json={"title": "", "author_id": 0})
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

# Tests for order
def test_create_order_happy_path():
    book_title = unique("book")
    book_author = create_author(unique("name"), unique("surname"))
    book = create_book(book_title, book_author["id"])
    item = {"book_id": book["id"], "quantity": 1}
    order = create_order([item])
    assert "id" in order
    assert "items" in order

def test_create_order_with_nonexistent_book_error_case():
    item = {"book_id": 999, "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders", headers=headers, json={"items": [item]})
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for order items
def test_add_item_to_order_happy_path():
    book_title = unique("book")
    book_author = create_author(unique("name"), unique("surname"))
    book = create_book(book_title, book_author["id"])
    item = {"book_id": book["id"], "quantity": 1}
    order = create_order([])
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", headers=headers, json=item, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_add_item_to_nonexistent_order_error_case():
    item = {"book_id": 999, "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/999/items", headers=headers, json=item)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for order status
def test_update_order_status_happy_path():
    book_title = unique("book")
    book_author = create_author(unique("name"), unique("surname"))
    book = create_book(book_title, book_author["id"])
    item = {"book_id": book["id"], "quantity": 1}
    order = create_order([item])
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", headers=headers, json={"status": "shipped"}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "status" in data and data["status"] == "shipped"

def test_update_nonexistent_order_status_error_case():
    r = requests.patch(f"{BASE_URL}/orders/999/status", headers=headers, json={"status": "shipped"})
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for order invoice
def test_get_order_invoice_happy_path():
    book_title = unique("book")
    book_author = create_author(unique("name"), unique("surname"))
    book = create_book(book_title, book_author["id"])
    item = {"book_id": book["id"], "quantity": 1}
    order = create_order([item])
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", headers=headers, json={"status": "paid"}, timeout=30)
    assert r.status_code == 200
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", headers=headers)
    assert r.status_code == 200

def test_get_invoice_for_nonexistent_order_edge_case():
    r = requests.get(f"{BASE_URL}/orders/999/invoice", headers=headers)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_get_invoice_for_pending_order_edge_case():
    author_data = create_author(unique("author_name"), unique("author_surname"))
    book = create_book(unique("book_title"), author_data["id"])
    item = {"book_id": book["id"], "quantity": 1}
    order = create_order([item])
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", headers=headers)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

# Tests for get book by id
def test_get_book_by_id_happy_path():
    author_data = create_author(unique("author_name"), unique("author_surname"))
    book = create_book(unique("book_title"), author_data["id"])
    r = requests.get(f"{BASE_URL}/books/{book['id']}", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert "title" in data and data["title"] == book["title"]
    assert "author_id" in data and data["author_id"] == author_data["id"]

def test_get_nonexistent_book_edge_case():
    r = requests.get(f"{BASE_URL}/books/999", headers=headers)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for delete book and restore
def test_restore_deleted_book_happy_path():
    author_data = create_author(unique("author_name"), unique("author_surname"))
    book = create_book(unique("book_title"), author_data["id"])
    requests.delete(f"{BASE_URL}/books/{book['id']}", headers=headers)
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", headers=headers)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_restore_nonexistent_book_error_case():
    r = requests.post(f"{BASE_URL}/books/999/restore", headers=headers)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for clone book
def test_clone_book_happy_path():
    author_data = create_author(unique("author_name"), unique("author_surname"))
    book = create_book(unique("book_title"), author_data["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", headers=headers)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_clone_nonexistent_book_error_case():
    r = requests.post(f"{BASE_URL}/books/999/clone", headers=headers)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

# Tests for bulk create books
def test_bulk_create_books_happy_path():
    author_data1 = create_author(unique("author_name"), unique("author_surname"))
    author_data2 = create_author(unique("author_name"), unique("author_surname"))
    books_data = [
        {"title": unique("book"), "author_id": author_data1["id"]},
        {"title": unique("book"), "author_id": author_data2["id"]}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", headers=headers, json=books_data)
    assert r.status_code == 201
    data = r.json()
    assert len(data) == len(books_data)

def test_bulk_create_with_invalid_data_error_case():
    books_data = [
        {"title": "", "author_id": None},
        {"title": unique("book"), "author_id": None}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", headers=headers, json=books_data)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data


def test_create_author_happy_path():
    author_name = unique("author")
    response = requests.post(f"{base_url}/authors", headers=headers, json={"name": author_name})
    assert response.status_code == 201, f"Test failed {response.status_code}: {response.text[:200]}"
    data = response.json()
    assert "id" in data and data["name"] == author_name

def test_create_author_with_invalid_data_error_case():
    response = requests.post(f"{base_url}/authors", headers=headers, json={"name": 123})
    assert response.status_code == 422, f"Test failed {response.status_code}: {response.text[:200]}"
    error_details = response.json()
    assert "detail" in error_details and len(error_details["detail"]) > 0

def test_update_author_happy_path():
    author_name = unique("author")
    response = requests.post(f"{base_url}/authors", headers=headers, json={"name": author_name})
    assert response.status_code == 201
    author_id = response.json()["id"]
    new_name = unique("updated_author")
    update_response = requests.put(f"{base_url}/authors/{author_id}", headers=headers, json={"name": new_name})
    assert update_response.status_code == 200
    updated_data = update_response.json()
    assert updated_data["name"] == new_name

def test_update_nonexistent_author_error_case():
    author_id = unique("nonexistent_id")
    response = requests.put(f"{base_url}/authors/{author_id}", headers=headers, json={"name": "new name"})
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_list_authors_happy_path():
    author_name1 = unique("author")
    author_name2 = unique("author")
    create_author(author_name1)
    create_author(author_name2)
    response = requests.get(f"{base_url}/authors", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 2
    assert any(author["name"] == author_name1 for author in data)
    assert any(author["name"] == author_name2 for author in data)

def test_get_author_by_id_happy_path():
    author_name = unique("author")
    create_response = requests.post(f"{base_url}/authors", headers=headers, json={"name": author_name})
    assert create_response.status_code == 201
    author_id = create_response.json()["id"]
    response = requests.get(f"{base_url}/authors/{author_id}", headers=headers)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == author_name

def test_get_nonexistent_author_edge_case():
    author_id = unique("nonexistent_id")
    response = requests.get(f"{base_url}/authors/{author_id}", headers=headers)
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_delete_nonexistent_author_edge_case():
    author_id = unique("nonexistent_id")
    response = requests.delete(f"{base_url}/authors/{author_id}", headers=headers)
    assert response.status_code == 404, f"Test failed {response.status_code}: {response.text[:200]}"

def test_delete_author_happy_path():
    author_name = unique("author")
    create_response = requests.post(f"{base_url}/authors", headers=headers, json={"name": author_name})
    assert create_response.status_code == 201
    author_id = create_response.json()["id"]
    response = requests.delete(f"{base_url}/authors/{author_id}", headers=headers)
    assert response.status_code == 204

def test_if_none_match_header():
    author_name = unique("author")
    create_response = requests.post(f"{base_url}/authors", headers=headers, json={"name": author_name})
    assert create_response.status_code == 201
    etag = create_response.headers.get('ETag')
    author_id = create_response.json()["id"]
    response = requests.get(f"{base_url}/authors/{author_id}", headers={**headers, "If-None-Match": etag})
    assert response.status_code == 304