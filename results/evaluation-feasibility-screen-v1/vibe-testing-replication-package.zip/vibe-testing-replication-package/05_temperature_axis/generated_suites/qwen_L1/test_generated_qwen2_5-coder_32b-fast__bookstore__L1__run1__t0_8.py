# Hlavní problémy byly související s délkou stringů a nekorektním posíláním dat. Fix: Omezil jsem délku prefixů a zajistil, aby data odpovídala API specifikaci.
# Doplnil jsem také kontrolu ETag pro PUT requesty.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

base_url = "http://localhost:8000/api"
timeout=30

def create_book(title):
    response = requests.post(f"{base_url}/books/", json={"title": title[:92], "author_id": create_author()["id"]}, timeout=timeout)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name=unique("auth")):
    response = requests.post(f"{base_url}/authors/", json={"name": name[:142]}, timeout=timeout)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order():
    book_id = create_book(unique("book"))["id"]
    response = requests.post(f"{base_url}/orders/", json={"items": [{"book_id": book_id, "quantity": 1}]}, timeout=timeout)
    assert response.status_code in (201,), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(author_id, name):
    get_response = requests.get(f"{base_url}/authors/{author_id}", timeout=timeout)
    assert get_response.status_code == 200, f"Helper failed to fetch author {response.status_code}: {response.text[:200]}"
    
    etag = get_response.headers.get('ETag')
    headers = {'If-Match': etag} if etag else {}
    
    response = requests.put(f"{base_url}/authors/{author_id}", json={"name": name[:142]}, headers=headers, timeout=timeout)
    assert response.status_code == 200, f"Helper failed to update author {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_books():
    response = requests.get(f"{base_url}/books/", timeout=timeout)
    data = response.json()
    assert response.status_code == 200
    assert isinstance(data, list)

def test_create_book_happy_path():
    title = unique("book")[:100]
    response = requests.post(f"{base_url}/books/", json={"title": title, "author_id": create_author().get("id")}, timeout=timeout)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["title"] == title

def test_create_book_error_no_data():
    response = requests.post(f"{base_url}/books/", json={}, timeout=timeout)
    data = response.json()
    assert response.status_code == 422
    assert "detail" in data

def test_get_books_by_id_happy_path():
    book = create_book(unique("book"))
    response = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    data = response.json()
    assert response.status_code == 200
    assert "title" in data

def test_get_books_by_id_error_not_found():
    response = requests.get(f"{base_url}/books/9999", timeout=timeout)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_delete_book_happy_path():
    book = create_book(unique("book"))
    response = requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response.status_code == 204
    response_get = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response_get.status_code == 410

def test_create_author_happy_path():
    name = unique("author")[:150]
    response = requests.post(f"{base_url}/authors/", json={"name": name}, timeout=timeout)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data
    assert data["name"] == name

def test_get_author_by_id_happy_path():
    author = create_author(unique("author"))
    response = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    data = response.json()
    assert response.status_code == 200
    assert "name" in data

def test_get_author_by_id_error_not_found():
    response = requests.get(f"{base_url}/authors/9999", timeout=timeout)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_delete_author_happy_path():
    author = create_author(unique("author"))
    response = requests.delete(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert response.status_code == 204
    response_get = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert response_get.status_code == 404

def test_create_order_happy_path():
    response = create_order()
    assert response["status"] == "pending"

def test_add_item_to_order_happy_path():
    order = create_order()
    book_id = create_book(unique("book")).get("id")
    response = requests.post(f"{base_url}/orders/{order['id']}/items", json={"book_id": book_id, "quantity": 2}, timeout=timeout)
    data = response.json()
    assert response.status_code == 201
    assert len(data["items"]) == 1

def test_add_item_to_nonexistent_order_error():
    book_id = create_book(unique("book")).get("id")
    response = requests.post(f"{base_url}/orders/9999/items", json={"book_id": book_id, "quantity": 1}, timeout=timeout)
    data = response.json()
    assert response.status_code == 404
    assert "detail" in data

def test_update_order_status_happy_path():
    order = create_order()
    response = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "shipped"}, timeout=timeout)
    data = response.json()
    assert response.status_code == 200
    assert data["status"] == "shipped"

def test_update_order_status_to_cancelled_happy_path():
    order = create_order()
    response = requests.patch(f"{base_url}/orders/{order['id']}/status", json={"status": "cancelled"}, timeout=timeout)
    data = response.json()
    assert response.status_code == 200
    assert data["status"] == "cancelled"

def test_delete_item_from_order_happy_path():
    order = create_order()
    item_id = order["items"][0]["id"]
    response = requests.delete(f"{base_url}/orders/{order['id']}/items/{item_id}", timeout=timeout)
    assert response.status_code == 204
    response_get = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    data = response_get.json()
    assert len(data["items"]) == 0

def test_delete_order_happy_path():
    order = create_order()
    response = requests.delete(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert response.status_code == 204
    response_get = requests.get(f"{base_url}/orders/{order['id']}", timeout=timeout)
    assert response_get.status_code == 404

def test_apply_discount_happy_path():
    response = requests.post(f"{base_url}/discounts/", json={"code": unique("discount"), "percentage": 10}, timeout=timeout)
    data = response.json()
    assert response.status_code == 201
    assert "id" in data

def test_delete_discount_happy_path():
    discount = requests.post(f"{base_url}/discounts/", json={"code": unique("discount"), "percentage": 10}, timeout=timeout).json()
    response = requests.delete(f"{base_url}/discounts/{discount['id']}", timeout=timeout)
    assert response.status_code == 204
    response_get = requests.get(f"{base_url}/discounts/{discount['id']}", timeout=timeout)
    assert response_get.status_code == 404


def test_create_author_with_long_name():
    long_name = "a" * 143  # Adjusted to the maximum allowed length
    response = requests.post(f"{base_url}/authors/", json={"name": long_name}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "ensure this value has at most 142 characters" in response.json()['detail'][0]['msg']

def test_create_author_with_empty_name():
    response = requests.post(f"{base_url}/authors/", json={"name": ""}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "ensure this value has at least 1 characters" in response.json()['detail'][0]['msg']

def test_update_author_with_nonexistent_id():
    response = requests.put(f"{base_url}/authors/99999", json={"name": "New Name"}, timeout=timeout)
    assert response.status_code == 404, f"Unexpected status code: {response.status_code}"
    assert "Author not found" in response.json()['detail'][0]['msg']

def test_update_author_happy_path():
    author = create_author()
    new_name = unique("updated_author")
    response = requests.put(f"{base_url}/authors/{author['id']}", json={"name": new_name}, timeout=timeout)
    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert response.json()['name'] == new_name

def test_list_authors_with_paging():
    for _ in range(3):
        create_author()
    response = requests.get(f"{base_url}/authors/", params={"limit": 1}, timeout=timeout)
    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert len(response.json()) == 1

def test_create_order_with_invalid_book_id():
    invalid_book_id = 99999
    response = requests.post(f"{base_url}/orders/", json={"items": [{"book_id": invalid_book_id, "quantity": 1}]}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "Book not found" in response.json()['detail'][0]['msg']

def test_create_order_with_zero_quantity():
    book = create_book(unique("book"))
    response = requests.post(f"{base_url}/orders/", json={"items": [{"book_id": book["id"], "quantity": 0}]}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "ensure this value is greater than 0" in response.json()['detail'][0]['msg']

def test_get_health_check():
    response = requests.get(f"{base_url}/health", timeout=timeout)
    assert response.status_code == 200, f"Unexpected status code: {response.status_code}"
    assert response.text == "{}"

def test_get_health_check_with_unsupported_method():
    response = requests.put(f"{base_url}/health", timeout=timeout)
    assert response.status_code == 405, f"Unexpected status code: {response.status_code}"

def test_create_book_without_author_id():
    response = requests.post(f"{base_url}/books/", json={"title": unique("book")}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "field required" in response.json()['detail'][0]['msg']

def test_create_book_with_invalid_author_id():
    invalid_author_id = 99999
    response = requests.post(f"{base_url}/books/", json={"title": unique("book"), "author_id": invalid_author_id}, timeout=timeout)
    assert response.status_code == 422, f"Unexpected status code: {response.status_code}"
    assert "Author not found" in response.json()['detail'][0]['msg']