# Hlavní problém byl v délce stringů při generování unikátních názvů. Omezil jsem délku prefixu a UUID pro splnění očekávaných limitů API.
# Kromě toho byly opraveny formáty dat, které posílají helper funkce.

import uuid
import requests

BASE_URL = "http://localhost:8000"

def unique(prefix="test"):
    return f"{prefix[:4]}_{uuid.uuid4().hex[:8]}"

def create_book(title, author_id):
    response = requests.post(f"{BASE_URL}/books", json={"title": title, "author_id": author_id}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    response = requests.post(f"{BASE_URL}/authors", json={"name": name}, timeout=30)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def get_author(author_id):
    response = requests.get(f"{BASE_URL}/authors/{author_id}", timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(author_id, name):
    author_data = get_author(author_id)  # Get current ETag
    etag = author_data['etag']
    headers = {'If-Match': etag}
    response = requests.put(f"{BASE_URL}/authors/{author_id}", json={"name": name}, headers=headers, timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def delete_author(author_id):
    author_data = get_author(author_id)  # Get current ETag
    etag = author_data['etag']
    headers = {'If-Match': etag}
    response = requests.delete(f"{BASE_URL}/authors/{author_id}", headers=headers, timeout=30)
    assert response.status_code == 204, f"Helper failed {response.status_code}: {response.text[:200]}"

def list_authors(skip=0, limit=100):
    params = {'skip': skip, 'limit': limit}
    response = requests.get(f"{BASE_URL}/authors", params=params, timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def list_author_books(author_id):
    response = requests.get(f"{BASE_URL}/authors/{author_id}/books", timeout=30)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_get_all_books_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.get(f"{BASE_URL}/books", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert any(item["title"] == book["title"] for item in data)

def test_create_book_happy_path():
    author = create_author(unique("author"))
    book_title = unique("book")
    book = create_book(book_title, author["id"])
    assert "id" in book
    assert book["title"] == book_title

def test_create_book_insufficient_stock_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 100}]}, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_get_book_by_id_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "title" in data
    assert data["title"] == book["title"]

def test_get_nonexistent_book_error():
    r = requests.get(f"{BASE_URL}/books/99999")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_update_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    new_title = unique("updated_book")
    r = requests.put(f"{BASE_URL}/books/{book['id']}", json={"title": new_title}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "title" in data
    assert data["title"] == new_title

def test_delete_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/books/{book['id']}", timeout=30)
    assert r.status_code == 410

def test_create_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_create_order_insufficient_stock_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 100}]}, timeout=30)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_add_item_to_order_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}, timeout=30).json()
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json={"book_id": book["id"], "quantity": 1}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_add_item_to_nonexistent_order_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/orders/99999/items", json={"book_id": book["id"], "quantity": 1}, timeout=30)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_update_order_status_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=30)
    assert r.status_code == 200
    data = r.json()
    assert "status" in data
    assert data["status"] == "confirmed"

def test_update_order_status_invalid_state_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "invalid_status"}, timeout=30)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_get_order_invoice_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "confirmed"}, timeout=30)
    assert r.status_code == 200
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=30)
    assert r.status_code == 200

def test_get_invoice_for_non_finalized_order_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    order = requests.post(f"{BASE_URL}/orders", json={"items": [{"book_id": book["id"], "quantity": 1}]}).json()
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=30)
    assert r.status_code == 403
    data = r.json()
    assert "detail" in data

def test_apply_discount_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/discounts", json={"book_id": book["id"], "percentage": 10}, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_apply_discount_invalid_percentage_error():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/discounts", json={"book_id": book["id"], "percentage": 105}, timeout=30)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_bulk_create_books_happy_path():
    author = create_author(unique("author"))
    books_data = [{"title": unique("book"), "author_id": author["id"]} for _ in range(3)]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert len(data) == 3

def test_bulk_create_books_invalid_author_error():
    books_data = [{"title": unique("book"), "author_id": 99999} for _ in range(3)]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=30)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_clone_book_happy_path():
    author = create_author(unique("author"))
    book = create_book(unique("book"), author["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", timeout=30)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_clone_nonexistent_book_error():
    r = requests.post(f"{BASE_URL}/books/99999/clone", timeout=30)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_bulk_delete_books_happy_path():
    author = create_author(unique("author"))
    books = [create_book(unique("book"), author["id"]) for _ in range(3)]
    book_ids = [book["id"] for book in books]
    r = requests.delete(f"{BASE_URL}/books/bulk", json={"ids": book_ids})
    assert r.status_code == 204
    for book_id in book_ids:
        r = requests.get(f"{BASE_URL}/books/{book_id}")
        assert r.status_code == 404

def test_bulk_delete_nonexistent_books_error():
    r = requests.delete(f"{BASE_URL}/books/bulk", json={"ids": [99999, 88888]})
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_bulk_update_books_happy_path():
    author = create_author(unique("author"))
    books = [create_book(unique("book"), author["id"]) for _ in range(3)]
    updates_data = [{"id": book["id"], "title": unique("updated_book")} for book in books]
    r = requests.put(f"{BASE_URL}/books/bulk", json=updates_data)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 3

def test_create_author_happy_path():
    author_data = {"name": unique("author")}
    r = requests.post(f"{BASE_URL}/authors", json=author_data)
    assert r.status_code == 201
    data = r.json()
    assert "id" in data

def test_get_all_authors_happy_path():
    authors_data = [{"name": unique("author")} for _ in range(3)]
    for author_data in authors_data:
        requests.post(f"{BASE_URL}/authors", json=author_data)
    r = requests.get(f"{BASE_URL}/authors")
    assert r.status_code == 200
    data = r.json()
    assert "items" in data or isinstance(data, list)
    assert len(data) >= 3

def test_get_author_by_id_happy_path():
    author_data = {"name": unique("author")}
    created_author = requests.post(f"{BASE_URL}/authors", json=author_data).json()
    r = requests.get(f"{BASE_URL}/authors/{created_author['id']}")
    assert r.status_code == 200
    data = r.json()
    assert "id" in data
    assert data["id"] == created_author["id"]

def test_get_nonexistent_author_error():
    r = requests.get(f"{BASE_URL}/authors/99999")
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_update_author_happy_path():
    author_data = {"name": unique("author")}
    created_author = requests.post(f"{BASE_URL}/authors", json=author_data).json()
    update_data = {"name": unique("updated_author")}
    r = requests.put(f"{BASE_URL}/authors/{created_author['id']}", json=update_data)
    assert r.status_code == 200
    data = r.json()
    assert "name" in data
    assert data["name"] == update_data["name"]

def test_delete_author_happy_path():
    author_data = {"name": unique("author")}
    created_author = requests.post(f"{BASE_URL}/authors", json=author_data).json()
    r = requests.delete(f"{BASE_URL}/authors/{created_author['id']}")
    assert r.status_code == 204
    r = requests.get(f"{BASE_URL}/authors/{created_author['id']}")
    assert r.status_code == 404
