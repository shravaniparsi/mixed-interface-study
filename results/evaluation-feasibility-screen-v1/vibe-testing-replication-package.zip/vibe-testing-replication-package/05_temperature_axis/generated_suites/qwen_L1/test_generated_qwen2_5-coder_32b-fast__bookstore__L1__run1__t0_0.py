# Hlavní problém je pravděpodobně překročení maximální délky povoleného pole pro jméno autora nebo název knihy. Omezím délku stringů oproti unikátnímu prefixu.
# Kromě toho, pokud je potřeba posílat ETag hlavičku, musím ji zahrnout do PUT požadavků.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}"

BASE_URL = "http://localhost:8000"
TIMEOUT = 30

def create_book(title, author_id):
    response = requests.post(f"{BASE_URL}/books", json={"title": title[:92], "author_id": author_id}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    response = requests.post(f"{BASE_URL}/authors", json={"name": name[:42]}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items):
    response = requests.post(f"{BASE_URL}/orders", json={"items": items}, timeout=TIMEOUT)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def update_author(author_id, name, etag):
    headers = {"If-Match": etag}
    response = requests.put(f"{BASE_URL}/authors/{author_id}", json={"name": name[:42]}, headers=headers, timeout=TIMEOUT)
    assert response.status_code == 200, f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def get_author(author_id):
    response = requests.get(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert response.status_code in (200, 304), f"Helper failed {response.status_code}: {response.text[:200]}"
    if response.status_code == 200:
        return response.json(), response.headers.get("ETag")
    return None, None

def delete_author(author_id):
    response = requests.delete(f"{BASE_URL}/authors/{author_id}", timeout=TIMEOUT)
    assert response.status_code == 204, f"Helper failed {response.status_code}: {response.text[:200]}"
# Hlavní problém je pravděpodobně překročení maximální délky povoleného pole pro jméno autora nebo název knihy. Omezím délku stringů oproti unikátnímu prefixu.
# Kromě toho, pokud je potřeba posílat ETag hlavičku, musím ji zahrnout do PUT požadavků.


def test_get_books_happy_path():
    r = requests.get(f"{BASE_URL}/books", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    assert "id" in book
    assert book["title"] == book_title
    assert book["author_id"] == author["id"]

def test_create_book_with_insufficient_stock():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_items = [{"book_id": book["id"], "quantity": 10}]
    r = requests.post(f"{BASE_URL}/orders", json={"items": order_items}, timeout=TIMEOUT)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_get_authors_happy_path():
    r = requests.get(f"{BASE_URL}/authors", timeout=TIMEOUT)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)

def test_create_author_happy_path():
    author_name = unique("author")
    author = create_author(author_name)
    assert "id" in author
    assert author["name"] == author_name

def test_bulk_create_books_happy_path():
    books_data = [
        {"title": unique("book1"), "author_id": create_author(unique("author1"))["id"]},
        {"title": unique("book2"), "author_id": create_author(unique("author2"))["id"]}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 201
    assert len(data) == 2

def test_bulk_create_books_with_errors():
    books_data = [
        {"title": unique("book1"), "author_id": create_author(unique("author1"))["id"]},
        {"title": unique("book2")},
        {"title": unique("book3"), "author_id": create_author(unique("author3"))["id"]}
    ]
    r = requests.post(f"{BASE_URL}/books/bulk", json=books_data, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 207
    assert len(data) == 3

def test_create_order_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_items = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(order_items)
    assert "id" in order
    assert len(order["items"]) == 1

def test_add_item_to_order_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([])
    item_data = {"book_id": book["id"], "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json=item_data, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 201
    assert len(data["items"]) == 1

def test_update_order_status_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "shipped"}, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert data["status"] == "shipped"

def test_get_order_invoice_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json={"status": "shipped"}, timeout=TIMEOUT)
    assert r.status_code == 200
    r = requests.get(f"{BASE_URL}/orders/{order['id']}/invoice", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "total" in data

def test_apply_discount_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    discount_data = {"book_id": book["id"], "percentage": 10}
    r = requests.post(f"{BASE_URL}/discounts", json=discount_data, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "discounted_price" in data

def test_apply_discount_to_old_book():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    discount_data = {"book_id": book["id"], "percentage": 10}
    r = requests.post(f"{BASE_URL}/books/{book['id']}/discount", json=discount_data, timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "discounted_price" in data

def test_restore_deleted_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    r = requests.delete(f"{BASE_URL}/books/{book['id']}", timeout=TIMEOUT)
    assert r.status_code == 204
    r = requests.post(f"{BASE_URL}/books/{book['id']}/restore", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "id" in data

def test_clone_book_happy_path():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    r = requests.post(f"{BASE_URL}/books/{book['id']}/clone", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 201
    assert "id" in data

def test_get_books_with_query_params():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    r = requests.get(f"{BASE_URL}/books?title={book['title']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_get_authors_with_query_params():
    author_name = unique("author")
    author = create_author(author_name)
    r = requests.get(f"{BASE_URL}/authors?name={author['name']}", timeout=TIMEOUT)
    data = r.json()
    assert r.status_code == 200
    assert "items" in data

def test_create_order_with_insufficient_stock():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_items = [{"book_id": book["id"], "quantity": 10}]
    r = requests.post(f"{BASE_URL}/orders", json={"items": order_items}, timeout=TIMEOUT)
    assert r.status_code == 400
    data = r.json()
    assert "detail" in data

def test_add_item_to_nonexistent_order():
    item_data = {"book_id": 999, "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/999/items", json=item_data, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_update_nonexistent_order_status():
    r = requests.patch(f"{BASE_URL}/orders/999/status", json={"status": "shipped"}, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_get_invoice_for_nonexistent_order():
    r = requests.get(f"{BASE_URL}/orders/999/invoice", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_apply_discount_to_nonexistent_book():
    discount_data = {"book_id": 999, "percentage": 10}
    r = requests.post(f"{BASE_URL}/discounts", json=discount_data, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_restore_nonexistent_book():
    r = requests.post(f"{BASE_URL}/books/999/restore", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_clone_nonexistent_book():
    r = requests.post(f"{BASE_URL}/books/999/clone", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_delete_nonexistent_book():
    r = requests.delete(f"{BASE_URL}/books/999", timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_create_order_with_invalid_item_data():
    invalid_items = [{"book_id": 999, "quantity": 1}]
    r = requests.post(f"{BASE_URL}/orders", json={"items": invalid_items}, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_create_order_with_empty_items():
    empty_items = []
    r = requests.post(f"{BASE_URL}/orders", json={"items": empty_items}, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_add_item_to_order_with_invalid_book_id():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([])
    invalid_item_data = {"book_id": 999, "quantity": 1}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json=invalid_item_data, timeout=TIMEOUT)
    assert r.status_code == 404
    data = r.json()
    assert "detail" in data

def test_add_item_to_order_with_zero_quantity():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([])
    zero_quantity_item_data = {"book_id": book["id"], "quantity": 0}
    r = requests.post(f"{BASE_URL}/orders/{order['id']}/items", json=zero_quantity_item_data, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data

def test_update_order_status_with_invalid_status():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order = create_order([{"book_id": book["id"], "quantity": 1}])
    invalid_status_data = {"status": "invalid"}
    r = requests.patch(f"{BASE_URL}/orders/{order['id']}/status", json=invalid_status_data, timeout=TIMEOUT)
    assert r.status_code == 422
    data = r.json()
    assert "detail" in data
