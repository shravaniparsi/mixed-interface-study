# Chyby byly hlavně v překročení povolené délky řetězců pro názvy autorů a knih. Omezil jsem délku unikátního prefixu na 5 znaků, aby celkový řetězec odpovídal očekávanému formátu API.
# Další problém byl v tom, že některé endpointy vyžadují specifické hlavičky, které nebyly poskytovány. Přidal jsem příslušné hlavičky do požadavků.

import requests
import uuid

def unique(prefix="test"):
    return f"{prefix[:5]}_{uuid.uuid4().hex[:8]}"

base_url = "http://localhost:8000"
timeout = 30
api_key_header = {"X-API-Key": "your_api_key_here"}  # Replace with actual API key if needed

def create_book(title, author_id):
    response = requests.post(f"{base_url}/books", headers=api_key_header, json={"title": unique(title)[:95], "author_id": author_id}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_author(name):
    response = requests.post(f"{base_url}/authors", headers=api_key_header, json={"name": unique(name)[:45]}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def create_order(items):
    response = requests.post(f"{base_url}/orders", headers=api_key_header, json={"items": items}, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()

def add_item_to_order(order_id, item):
    response = requests.post(f"{base_url}/orders/{order_id}/items", headers=api_key_header, json=item, timeout=timeout)
    assert response.status_code in (200, 201), f"Helper failed {response.status_code}: {response.text[:200]}"
    return response.json()


def test_books_get():
    response = requests.get(f"{base_url}/books", timeout=timeout)
    data = response.json()
    assert "items" in data

def test_books_get_filtered():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.get(f"{base_url}/books?title={book['title']}", timeout=timeout)
    data = response.json()
    assert "items" in data
    assert len(data["items"]) == 1

def test_books_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    assert "id" in book

def test_books_get_by_id():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    data = response.json()
    assert "id" in data

def test_books_put():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    new_title = unique("new_book")
    response = requests.put(f"{base_url}/books/{book['id']}", json={"title": new_title}, timeout=timeout)
    data = response.json()
    assert "id" in data
    assert data["title"] == new_title

def test_books_delete():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response.status_code == 204
    response = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response.status_code == 410

def test_books_bulk_post():
    author_name = unique("author")
    author = create_author(author_name)
    books_data = [
        {"title": unique("bulk_book1"), "author_id": author["id"]},
        {"title": unique("bulk_book2"), "author_id": author["id"]}
    ]
    response = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    data = response.json()
    assert response.status_code == 201
    assert len(data) == 2

def test_books_bulk_post_invalid():
    books_data = [
        {"title": unique("bulk_book1")},
        {"author_id": "invalid"}
    ]
    response = requests.post(f"{base_url}/books/bulk", json=books_data, timeout=timeout)
    data = response.json()
    assert response.status_code == 422

def test_books_clone_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.post(f"{base_url}/books/{book['id']}/clone", timeout=timeout)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_books_clone_post_nonexistent():
    response = requests.post(f"{base_url}/books/99999/clone", timeout=timeout)
    assert response.status_code == 404

def test_books_restore_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    requests.delete(f"{base_url}/books/{book['id']}", timeout=timeout)
    response = requests.post(f"{base_url}/books/{book['id']}/restore", timeout=timeout)
    assert response.status_code == 204
    response = requests.get(f"{base_url}/books/{book['id']}", timeout=timeout)
    assert response.status_code == 200

def test_books_restore_post_nonexistent():
    response = requests.post(f"{base_url}/books/99999/restore", timeout=timeout)
    assert response.status_code == 404

def test_authors_get():
    response = requests.get(f"{base_url}/authors", headers=api_key_header, timeout=timeout)
    data = response.json()
    assert "items" in data

def test_authors_post():
    author_name = unique("author")
    author = create_author(author_name)
    assert "id" in author

def test_authors_get_by_id():
    author_name = unique("author")
    author = create_author(author_name)
    response = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    data = response.json()
    assert "id" in data

def test_authors_put():
    author_name = unique("author")
    author = create_author(author_name)
    new_name = unique("new_author")
    response = requests.put(f"{base_url}/authors/{author['id']}", json={"name": new_name}, timeout=timeout)
    data = response.json()
    assert "id" in data
    assert data["name"] == new_name

def test_authors_delete():
    author_name = unique("author")
    author = create_author(author_name)
    response = requests.delete(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert response.status_code == 204
    response = requests.get(f"{base_url}/authors/{author['id']}", timeout=timeout)
    assert response.status_code == 404

def test_orders_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_data = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(order_data)
    assert "id" in order

def test_orders_post_insufficient_stock():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.post(f"{base_url}/orders", headers=api_key_header, json={"items": [{"book_id": book["id"], "quantity": 100}]}, timeout=timeout)
    data = response.json()
    assert response.status_code == 400
    assert "detail" in data

def test_orders_items_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_data = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(order_data)
    item_data = {"book_id": book["id"], "quantity": 1}
    response = add_item_to_order(order["id"], item_data)
    assert "id" in response

def test_orders_items_post_nonexistent_order():
    item_data = {"book_id": 99999, "quantity": 1}
    response = requests.post(f"{base_url}/orders/99999/items", json=item_data, timeout=timeout)
    assert response.status_code == 404

def test_orders_status_patch():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_data = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(order_data)
    response = requests.patch(f"{base_url}/orders/{order['id']}/status", headers=api_key_header, json={"status": "SHIPPED"}, timeout=timeout)
    assert response.status_code == 204
    response = requests.get(f"{base_url}/orders/{order['id']}", headers=api_key_header, timeout=timeout)
    data = response.json()
    assert data["status"] == "SHIPPED"

def test_orders_status_patch_nonexistent_order():
    response = requests.patch(f"{base_url}/orders/99999/status", headers=api_key_header, json={"status": "SHIPPED"}, timeout=timeout)
    assert response.status_code == 404

def test_orders_invoice_get():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    order_data = [{"book_id": book["id"], "quantity": 1}]
    order = create_order(order_data)
    response = requests.get(f"{base_url}/orders/{order['id']}/invoice", headers=api_key_header, timeout=timeout)
    assert response.status_code == 200
    data = response.json()
    assert "items" in data

def test_orders_invoice_get_nonexistent_order():
    response = requests.get(f"{base_url}/orders/99999/invoice", timeout=timeout)
    assert response.status_code == 404

def test_books_tags_post():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    tag_data = {"name": "fiction"}
    response = requests.post(f"{base_url}/books/{book['id']}/tags", headers=api_key_header, json=tag_data, timeout=timeout)
    assert response.status_code == 201
    data = response.json()
    assert "id" in data

def test_books_tags_post_nonexistent_book():
    tag_data = {"name": "fiction"}
    response = requests.post(f"{base_url}/books/99999/tags", headers=api_key_header, json=tag_data, timeout=timeout)
    assert response.status_code == 404

def test_books_tags_get():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    tag_data = {"name": "fiction"}
    requests.post(f"{base_url}/books/{book['id']}/tags", headers=api_key_header, json=tag_data, timeout=timeout)
    response = requests.get(f"{base_url}/books/{book['id']}/tags", headers=api_key_header, timeout=timeout)
    data = response.json()
    assert "items" in data
    assert len(data["items"]) == 1

def test_books_tags_get_nonexistent_book():
    response = requests.get(f"{base_url}/books/99999/tags", timeout=timeout)
    assert response.status_code == 404

def test_authors_books_get():
    author_name = unique("author")
    book_title = unique("book")
    author = create_author(author_name)
    book = create_book(book_title, author["id"])
    response = requests.get(f"{base_url}/authors/{author['id']}/books", timeout=timeout)
    data = response.json()
    assert "items" in data
    assert len(data["items"]) == 1
