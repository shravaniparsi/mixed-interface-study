# Context axis — balanced experiment

5 cloud LLMs x 5 context levels (L0-L4) x 5 independent runs, t = 0.4,
30 planned tests per run, max 5 repair iterations -> 125 runs.

## Results files

| File | Model | Scope |
|---|---|---|
| `experiment_v12_20260415_165515.json` | deepseek-chat | 25 runs (L0-L4 x 5) |
| `experiment_v12_20260415_220449.json` | mistral-large-2512 | 25 runs (L0-L4 x 5) |
| `experiment_v12_20260416_073106.json` | gemini-3.1-flash-lite-preview | 25 runs (L0-L4 x 5) |
| `experiment_v12_20260424_160040.json` | claude-haiku-4-5-20251001 | 25 runs (L0-L4 x 5) |
| `experiment_v12_20260426_220445.json` | deepseek-v4-flash | 25 runs (L0-L4 x 5) |
| `v12_metrics_aggregate.json` | all | per (model, level) aggregate used by figures/stats |
| `v12_metrics_summary.json` | all | compact summary |
| `code_coverage_summary.json` | all | line-coverage extraction |

## Generated suites

Each model folder contains 25 generated pytest suites (`test_generated_*.py`),
25 pipeline logs (`*_log.txt`) and 25 test plans (`test_plan_*.txt`):

| Folder | Files |
|---|---|
| `generated_suites/outputs_v12_claude/` | 75 files |
| `generated_suites/outputs_v12_deepseek-chat/` | 75 files |
| `generated_suites/outputs_v12_deepseek-v4/` | 75 files |
| `generated_suites/outputs_v12_gemini/` | 75 files |
| `generated_suites/outputs_v12_mistral/` | 75 files |
