"""Extract line-level code-coverage figures for the generated suites."""
import json
import re
from collections import defaultdict
from pathlib import Path
import numpy as np

STUDENT = Path(r"<REPO_ROOT>\v_temp\student_zip\vibe-testing-framework-main\v12")
OUT = Path(r"<REPO_ROOT>\v_temp\code_coverage_summary.json")

MODELS = ["claude", "deepseek-chat", "deepseek-v4", "gemini", "mistral"]
LABEL = {
    "claude":        "Claude Haiku 4.5",
    "deepseek-chat": "DeepSeek-Chat",
    "deepseek-v4":   "DeepSeek-V4-Flash",
    "gemini":        "Gemini 3.1 Flash Lite",
    "mistral":       "Mistral Large 3",
}

cells = defaultdict(list)
per_file_data = []

for slug in MODELS:
    cov_dir = STUDENT / f"outputs_v12_{slug}" / "coverage_results"
    if not cov_dir.exists():
        print(f"  [SKIP] {cov_dir}")
        continue
    for jf in sorted(cov_dir.glob("coverage_*.json")):
        try:
            data = json.load(open(jf, encoding="utf-8"))
        except Exception:
            continue
        m = re.search(r"__L(\d)__run(\d)", jf.name)
        if not m: continue
        level = "L" + m.group(1)
        run = int(m.group(2))

        files = data.get("files", {})
        total_stmts = 0
        total_cov = 0
        crud_pct = None
        for fname, st in files.items():
            total_stmts += st.get("num_statements", 0)
            total_cov += st.get("covered_lines", 0)
            if "crud" in fname:
                crud_pct = st.get("percent_covered", 0)
        pct = 100.0 * total_cov / total_stmts if total_stmts else 0
        label = LABEL[slug]
        cells[(label, level)].append({"total_cc": pct, "crud_cc": crud_pct, "run": run})
        per_file_data.append({"model": label, "level": level, "run": run,
                              "total_cc": pct, "crud_cc": crud_pct,
                              "file": jf.name})

agg = {}
print(f"{'Model':<24}{'L0':<14}{'L1':<14}{'L2':<14}{'L3':<14}{'L4':<14}")
for label in LABEL.values():
    row_total = []
    row_crud = []
    cell_strs = []
    for L in ["L0", "L1", "L2", "L3", "L4"]:
        vals = cells.get((label, L), [])
        tot = [v["total_cc"] for v in vals if v["total_cc"] is not None]
        crud = [v["crud_cc"] for v in vals if v["crud_cc"] is not None]
        m_tot = np.mean(tot) if tot else None
        s_tot = np.std(tot, ddof=1) if len(tot) > 1 else 0.0
        m_crd = np.mean(crud) if crud else None
        if m_tot is not None:
            cell_strs.append(f"{m_tot:5.1f}±{s_tot:4.1f}")
            agg[(label, L)] = {"total": m_tot, "total_sd": s_tot,
                               "crud": m_crd, "n": len(tot)}
        else:
            cell_strs.append("    -     ")
    print(f"{label:<24}" + "".join(f"{c:<14}" for c in cell_strs))

print(f"\n=== crud.py coverage only ===")
print(f"{'Model':<24}{'L0':<10}{'L1':<10}{'L2':<10}{'L3':<10}{'L4':<10}")
for label in LABEL.values():
    cells_str = []
    for L in ["L0", "L1", "L2", "L3", "L4"]:
        vals = cells.get((label, L), [])
        crd = [v["crud_cc"] for v in vals if v["crud_cc"] is not None]
        if crd:
            cells_str.append(f"{np.mean(crd):5.1f}")
        else:
            cells_str.append("  -  ")
    print(f"{label:<24}" + "".join(f"{c:<10}" for c in cells_str))

print(f"\n=== Cross-model mean CC per level ===")
for L in ["L0", "L1", "L2", "L3", "L4"]:
    all_tot = []
    all_crd = []
    for label in LABEL.values():
        vals = cells.get((label, L), [])
        all_tot.extend([v["total_cc"] for v in vals if v["total_cc"] is not None])
        all_crd.extend([v["crud_cc"] for v in vals if v["crud_cc"] is not None])
    if all_tot:
        print(f"  {L}: total {np.mean(all_tot):.2f}% ± {np.std(all_tot, ddof=1):.2f}% (N={len(all_tot)});  crud {np.mean(all_crd):.2f}%")

summary = {
    "per_cell": {f"{m}::{L}": v for (m, L), v in agg.items()},
    "n_files": len(per_file_data),
}
OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(f"\nSaved -> {OUT}")
