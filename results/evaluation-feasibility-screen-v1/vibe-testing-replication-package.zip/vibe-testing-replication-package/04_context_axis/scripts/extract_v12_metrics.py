"""Aggregate the per-run balanced-experiment JSONs into per (model, level) metric summaries."""
import json
import glob
import statistics as stats
from collections import defaultdict
from pathlib import Path

REPO = Path("<RUN_HOST>")
OUT = REPO / "results" / "v12_metrics_aggregate.json"


def gget(d, *keys, default=0):
    for k in keys:
        if not isinstance(d, dict):
            return default
        d = d.get(k, {})
    return d if d not in ({}, None) else default


dirs = ["claude", "deepseek-chat", "deepseek-v4", "mistral", "gemini"]
out = {}
for d in dirs:
    pattern = str(REPO / "v12" / f"outputs_v12_{d}" / "results" / "*.json")
    files = glob.glob(pattern)
    if not files:
        continue
    runs = json.load(open(files[0]))
    by_lvl = defaultdict(list)
    model_name = None
    for r in runs:
        if "metrics" not in r:
            continue
        by_lvl[r.get("level", "?")].append(r)
        model_name = r.get("llm", "?")
    cells = {}
    for lvl, rs in by_lvl.items():
        if not rs:
            continue
        cells[lvl] = {
            "tvr_mean": stats.mean([gget(r, "metrics", "test_validity", "validity_rate_pct") for r in rs]),
            "tvr_std": stats.pstdev([gget(r, "metrics", "test_validity", "validity_rate_pct") for r in rs]) if len(rs) > 1 else 0,
            "ep": stats.mean([gget(r, "metrics", "endpoint_coverage", "endpoint_coverage_pct") for r in rs]),
            "ad": stats.mean([gget(r, "metrics", "assertion_depth", "assertion_depth") for r in rs]),
            "rv": stats.mean([gget(r, "metrics", "response_validation", "response_validation_pct") for r in rs]),
            "it": stats.mean([r.get("iterations_used", 0) for r in rs]),
            "sec": stats.mean([r.get("elapsed_seconds", 0) for r in rs]),
            "cost": stats.mean([gget(r, "token_usage_slim", "cost_total_usd") for r in rs]),
            "tokens": stats.mean([gget(r, "token_usage_slim", "total_tokens") for r in rs]),
            "n_runs": len(rs),
            "all_passed": sum(1 for r in rs if r.get("all_tests_passed")),
        }
    out[d] = {"model": model_name, "cells": cells}

OUT.parent.mkdir(exist_ok=True)
OUT.write_text(json.dumps(out, indent=2), encoding="utf-8")
print(f"Saved: {OUT}")
print()

print(f"{'Model':<30} {'Lvl':<4} {'TVR%':>7} {'EP%':>5} {'AD':>5} {'RV%':>5} {'Iter':>5} {'Sec':>5} {'Cost$':>7} {'Pass':>4}")
print("-" * 90)
for d in dirs:
    if d not in out:
        continue
    model_name = out[d]["model"]
    print(f"{model_name:<30}")
    for lvl in ["L0", "L1", "L2", "L3", "L4"]:
        if lvl in out[d]["cells"]:
            m = out[d]["cells"][lvl]
            ap = f"{m['all_passed']}/{m['n_runs']}"
            print(f"{'':<30} {lvl:<4} {m['tvr_mean']:>6.2f}% {m['ep']:>5.1f} {m['ad']:>5.2f} {m['rv']:>5.1f} {m['it']:>5.1f} {m['sec']:>5.0f} {m['cost']:>7.4f} {ap:>4}")
