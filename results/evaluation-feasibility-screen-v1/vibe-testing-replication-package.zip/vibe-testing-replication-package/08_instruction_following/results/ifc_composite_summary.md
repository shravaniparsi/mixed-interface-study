# Composite IFC probe results — Bookstore API

Static instruction-following probes applied to LLM-generated pytest files. Each cell shows `passed/applicable (pct)`. Files where the probe is not applicable (no relevant endpoint exercised) are excluded from the denominator.

## Aggregate by model (all files)

| Model | P1 ISBN | P2 PATCH-QS | P3 DEL-204 | P4 API-Key | P5 Order-FSM | P6 410 |
|---|---|---|---|---|---|---|
| DeepSeek-Chat | 43/43 (100%) | 38/38 (100%) | 30/43 (70%) | — | 38/38 (100%) | — |
| Gemini 3.1 Flash Lite | 38/38 (100%) | 29/34 (85%) | 38/38 (100%) | — | 32/32 (100%) | — |
| Mistral Large 3 | 25/25 (100%) | 15/15 (100%) | 15/25 (60%) | — | — | — |
| Qwen 2.5-Coder 32B | 11/36 (31%) | 0/3 (0%) | 35/35 (100%) | — | 15/15 (100%) | — |

## v12 main experiment (L0–L4 × 5 cloud models — DeepSeek-Chat, Gemini, Mistral subset)

### P1_ISBN

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| Gemini 3.1 Flash Lite | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| Mistral Large 3 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |

### P2_PATCH_QS

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | — | 5/5 | 5/5 | 5/5 | 5/5 |
| Gemini 3.1 Flash Lite | 1/1 | 5/5 | 5/5 | 3/5 | 3/5 |
| Mistral Large 3 | — | 1/1 | 5/5 | 5/5 | 4/4 |

### P3_DELETE_204

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | 5/5 | 5/5 | 5/5 | 5/5 | 3/5 |
| Gemini 3.1 Flash Lite | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| Mistral Large 3 | 5/5 | 4/5 | 1/5 | 1/5 | 4/5 |

### P4_API_KEY

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | — | — | — | — | — |
| Gemini 3.1 Flash Lite | — | — | — | — | — |
| Mistral Large 3 | — | — | — | — | — |

### P5_ORDER_FSM

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| Gemini 3.1 Flash Lite | 1/1 | 5/5 | 5/5 | 4/4 | 5/5 |
| Mistral Large 3 | — | — | — | — | — |

### P6_410_GONE

| Model | L0 | L1 | L2 | L3 | L4 |
|---|---|---|---|---|---|
| DeepSeek-Chat | — | — | — | — | — |
| Gemini 3.1 Flash Lite | — | — | — | — | — |
| Mistral Large 3 | — | — | — | — | — |

## Composite IFC (mean of 6 probe pass-rates per file)

| Model | Composite IFC | Files |
|---|---|---|
| DeepSeek-Chat | 92.4% (mean of 4 applicable probes) | 43 |
| Gemini 3.1 Flash Lite | 96.3% (mean of 4 applicable probes) | 38 |
| Mistral Large 3 | 86.7% (mean of 3 applicable probes) | 25 |
| Qwen 2.5-Coder 32B | 57.6% (mean of 4 applicable probes) | 36 |
