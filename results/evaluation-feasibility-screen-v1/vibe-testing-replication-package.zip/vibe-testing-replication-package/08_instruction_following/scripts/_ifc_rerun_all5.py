"""Recompute the IFC composite across all five cloud cohorts."""
import re
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import _ifc_composite_probes as ifc

ROOT = Path(__file__).parent.parent
ZIP12 = ROOT / "v_temp/student_zip/vibe-testing-framework-main/v12"
DIRS = {
    "outputs_v12_claude": "Claude Haiku 4.5",
    "outputs_v12_deepseek-chat": "DeepSeek-Chat",
    "outputs_v12_deepseek-v4": "DeepSeek-V4-Flash",
    "outputs_v12_gemini": "Gemini 3.1 Flash Lite",
    "outputs_v12_mistral": "Mistral Large 3",
}
files = []
for d, label in DIRS.items():
    for f in sorted((ZIP12 / d).glob("test_generated_*__bookstore__L*__run*__t0_4.py")):
        m = re.search(r"__(L\d)__run(\d)__", f.name)
        files.append((label, m.group(1), int(m.group(2)), str(f.relative_to(ROOT)), "local"))

local = ifc.list_local_outputs(ROOT / "outputs")
rows = ifc.evaluate(files, "v12-zip") + ifc.evaluate(local, "temp-sweep-L1")
print("evaluated files:", len(rows))
(ROOT / "v_temp/ifc_composite_results.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

PR = ["P1_ISBN", "P2_PATCH_QS", "P3_DELETE_204", "P4_API_KEY", "P5_ORDER_FSM", "P6_410_GONE"]
agg = defaultdict(lambda: {p: [0, 0] for p in PR})
for r in rows:
    for p in PR:
        v = r[p]
        if v is None:
            continue
        agg[r["model"]][p][1] += 1
        if v:
            agg[r["model"]][p][0] += 1

print(f"{'Model':<24}" + "".join(f"{p:<14}" for p in PR) + "Composite")
comp = {}
detail = {}
for m in sorted(agg):
    cells, pcts = [], []
    for p in PR:
        k, n = agg[m][p]
        if n == 0:
            cells.append("-")
        else:
            cells.append(f"{k}/{n}")
            pcts.append(100 * k / n)
    comp[m] = round(sum(pcts) / len(pcts), 1) if pcts else None
    detail[m] = {p: f"{agg[m][p][0]}/{agg[m][p][1]}" if agg[m][p][1] else "n/a" for p in PR}
    print(f"{m:<24}" + "".join(f"{c:<14}" for c in cells) + f"{comp[m]}%")

json.dump({"composite": comp, "detail": detail},
          open(ROOT / "v_temp/ifc_composite_by_model.json", "w"), indent=2)
print("saved ifc_composite_by_model.json")
