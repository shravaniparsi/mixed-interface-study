"""Static instruction-following-compliance probes (P1-P6) over generated test files."""
import json
import re
import subprocess
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).parent.parent
OUT_JSON = ROOT / "v_temp" / "ifc_composite_results.json"
OUT_MD = ROOT / "v_temp" / "ifc_composite_summary.md"


def list_v12_files():
    res = subprocess.run(
        ["git", "ls-tree", "-r", "origin/main", "--name-only"],
        capture_output=True, text=True, cwd=str(ROOT))
    items = []
    for line in res.stdout.splitlines():
        if not line.startswith("v12/outputs_v12_"):
            continue
        if not line.endswith(".py"):
            continue
        m = re.search(r"test_generated_(.+?)__bookstore__(L[0-4])__run(\d+)__t([\d_]+)", line)
        if not m:
            continue
        raw_model, level, run, _ = m.group(1, 2, 3, 4)
        label = {
            "claude-haiku-4-5-20251001": "Claude Haiku 4.5",
            "deepseek-v4-flash": "DeepSeek-V4-Flash",
            "deepseek-chat": "DeepSeek-Chat",
            "mistral-large-2512": "Mistral Large 3",
            "mistral-large-2411": "Mistral Large 3",
            "gemini-3.1-flash-lite-preview": "Gemini 3.1 Flash Lite",
            "gemini-3_1-flash-lite-preview": "Gemini 3.1 Flash Lite",
        }.get(raw_model, raw_model)
        items.append((label, level, int(run), line, "git"))
    return items


def list_local_outputs(dir_path):
    out = []
    for p in dir_path.glob("test_generated_*.py"):
        m = re.search(r"test_generated_([\w\.\-]+?)__bookstore__(L\d)__run(\d+)__t([\d_]+)\.py", p.name)
        if not m:
            continue
        raw_model = m.group(1)
        level = m.group(2)
        run = int(m.group(3))
        temp_str = m.group(4)
        label = {
            "deepseek-chat":                       "DeepSeek-Chat",
            "gemini-3_1-flash-lite-preview":       "Gemini 3.1 Flash Lite",
            "gemini-3.1-flash-lite-preview":       "Gemini 3.1 Flash Lite",
            "qwen2_5-coder":                       "Qwen 2.5-Coder 32B",
            "qwen2_5-coder_32b-fast":              "Qwen 2.5-Coder 32B",
        }.get(raw_model, raw_model)
        out.append((label, level, run, str(p.relative_to(ROOT)), "local", temp_str))
    return out


def get_file_text(rec):
    label, level, run, path, kind = rec[:5]
    if kind == "git":
        res = subprocess.run(["git", "show", f"origin/main:{path}"],
                             capture_output=True, text=True, cwd=str(ROOT))
        return res.stdout if res.returncode == 0 else ""
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def probe_isbn(text):
    if "create_book" not in text and "/books" not in text:
        return None
    has_post_books = bool(re.search(r"(post|requests\.post|client\.post)\s*\(.*?[\"']/books[\"']", text, re.S))
    if not has_post_books and "create_book" not in text:
        return None
    has_isbn = bool(re.search(r"[\"']isbn[\"']\s*:", text, re.I))
    return has_isbn


def probe_patch_stock_qs(text):
    matches = list(re.finditer(
        r"(patch|requests\.patch|client\.patch)\s*\(([^)]*?stock[^)]*)\)",
        text, re.S | re.I))
    if not matches:
        return None
    ok = True
    for m in matches:
        call_args = m.group(2)
        has_qs = bool(re.search(r"\?\w+=", call_args)) or "params" in call_args
        has_json_body = "json=" in call_args
        if has_json_body and not has_qs:
            ok = False
    return ok


def probe_delete_204(text):
    blocks = re.findall(
        r"(?:delete|requests\.delete|client\.delete)\s*\([^)]*?\)\s*\n(?:.*?)(?:def\s+test_|\Z)",
        text, re.S | re.I)
    if not blocks:
        return None
    ok_count = 0
    bad_count = 0
    for b in blocks:
        b_short = b[:600]
        sees_204 = "204" in b_short
        parses_json = bool(re.search(r"\.json\s*\(", b_short))
        if sees_204 or not parses_json:
            ok_count += 1
        else:
            bad_count += 1
    return ok_count >= bad_count if (ok_count + bad_count) else None


def probe_apikey(text):
    sensitive_paths = re.findall(
        r"[\"'](/admin/[^\"']*|/exports/[^\"']*|/statistics/[^\"']*|/reset)[\"']", text)
    if not sensitive_paths:
        return None
    return bool(re.search(r"[\"']X-API-Key[\"']", text, re.I))


def probe_order_state(text):
    if "/orders" not in text:
        return None
    mentions_transitions = bool(re.search(r"\b(confirmed|shipped|delivered)\b", text, re.I))
    if not mentions_transitions:
        return None
    has_create = bool(re.search(r"(?:requests|client)\.post\s*\([^)]*?/orders", text, re.S | re.I)) \
                 or "create_order" in text \
                 or bool(re.search(r"post\s*\(\s*[\"'][^\"']*?/orders", text, re.S | re.I))
    return has_create


def probe_410(text):
    if "/books" not in text:
        return None
    deletes = bool(re.search(r"(delete|client\.delete)\s*\([^)]*?[\"']/books/[^\"']+[\"']",
                             text, re.S | re.I))
    if not deletes:
        return None
    return "410" in text


PROBES = {
    "P1_ISBN":      probe_isbn,
    "P2_PATCH_QS":  probe_patch_stock_qs,
    "P3_DELETE_204": probe_delete_204,
    "P4_API_KEY":   probe_apikey,
    "P5_ORDER_FSM": probe_order_state,
    "P6_410_GONE":  probe_410,
}


def evaluate(files, source_tag):
    rows = []
    for rec in files:
        label, level, run = rec[0], rec[1], rec[2]
        try:
            text = get_file_text(rec)
        except Exception as e:
            print(f"  err {rec[3]}: {e}")
            continue
        if not text:
            continue
        verdicts = {name: fn(text) for name, fn in PROBES.items()}
        rows.append({
            "source": source_tag,
            "file": rec[3],
            "model": label, "level": level, "run": run,
            **verdicts,
        })
    return rows


v12_files = list_v12_files()
print(f"v12 files (from origin/main): {len(v12_files)}")

local_files = list_local_outputs(ROOT / "outputs")
print(f"local outputs files: {len(local_files)}")

all_rows = evaluate(v12_files, "v12-L0-L4") + evaluate(local_files, "temp-sweep-L1")
print(f"Total evaluated: {len(all_rows)}")

OUT_JSON.write_text(json.dumps(all_rows, indent=2), encoding="utf-8")
print(f"Wrote {OUT_JSON}")


def summarize(rows, key_fn):
    summary = defaultdict(lambda: {p: [0, 0] for p in PROBES})
    for r in rows:
        k = key_fn(r)
        if k is None: continue
        for p in PROBES:
            v = r[p]
            if v is None: continue
            summary[k][p][1] += 1
            if v: summary[k][p][0] += 1
    return summary


lines = []
lines.append("# Composite IFC probe results - Bookstore API")
lines.append("")
lines.append("Static instruction-following probes applied to LLM-generated pytest files. "
             "Each cell shows `passed/applicable (pct)`. Files where the probe is not applicable "
             "(no relevant endpoint exercised) are excluded from the denominator.")
lines.append("")

lines.append("## Aggregate by model (all files)")
lines.append("")
lines.append("| Model | P1 ISBN | P2 PATCH-QS | P3 DEL-204 | P4 API-Key | P5 Order-FSM | P6 410 |")
lines.append("|---|---|---|---|---|---|---|")
agg_model = summarize(all_rows, lambda r: r["model"])
for m in sorted(agg_model.keys()):
    cells = []
    for p in PROBES:
        passed, total = agg_model[m][p]
        if total == 0:
            cells.append("-")
        else:
            pct = 100.0 * passed / total
            cells.append(f"{passed}/{total} ({pct:.0f}%)")
    lines.append(f"| {m} | " + " | ".join(cells) + " |")
lines.append("")

lines.append("## v12 main experiment (L0–L4 × 5 cloud models - DeepSeek-Chat, Gemini, Mistral subset)")
lines.append("")
v12_rows = [r for r in all_rows if r["source"] == "v12-L0-L4"]
for probe in PROBES:
    lines.append(f"### {probe}")
    lines.append("")
    lines.append("| Model | L0 | L1 | L2 | L3 | L4 |")
    lines.append("|---|---|---|---|---|---|")
    by_ml = summarize(v12_rows, lambda r: (r["model"], r["level"]))
    for m in sorted({r["model"] for r in v12_rows}):
        cells = []
        for L in ["L0", "L1", "L2", "L3", "L4"]:
            passed, total = by_ml.get((m, L), {probe: [0, 0]})[probe]
            cells.append(f"{passed}/{total}" if total else "-")
        lines.append(f"| {m} | " + " | ".join(cells) + " |")
    lines.append("")

lines.append("## Composite IFC (mean of 6 probe pass-rates per file)")
lines.append("")
lines.append("| Model | Composite IFC | Files |")
lines.append("|---|---|---|")
for m in sorted(agg_model.keys()):
    probe_pcts = []
    n_files = len({r["file"] for r in all_rows if r["model"] == m})
    for p in PROBES:
        passed, total = agg_model[m][p]
        if total > 0:
            probe_pcts.append(100.0 * passed / total)
    if probe_pcts:
        composite = sum(probe_pcts) / len(probe_pcts)
        lines.append(f"| {m} | {composite:.1f}% (mean of {len(probe_pcts)} applicable probes) | {n_files} |")
    else:
        lines.append(f"| {m} | - | {n_files} |")
lines.append("")

OUT_MD.write_text("\n".join(lines), encoding="utf-8")
print(f"Wrote {OUT_MD}")
print()
print("=" * 70)
print("\n".join(lines[: 50]))
