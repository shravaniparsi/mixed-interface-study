"""Split the Qwen IFC results by context level (L1 versus L2)."""
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).parent.parent
rows = json.load(open(ROOT / "v_temp" / "ifc_composite_results.json", encoding="utf-8"))

PROBES = ["P1_ISBN", "P2_PATCH_QS", "P3_DELETE_204", "P4_API_KEY", "P5_ORDER_FSM", "P6_410_GONE"]

agg = defaultdict(lambda: {p: [0, 0] for p in PROBES})
for r in rows:
    key = (r["model"], r["level"])
    for p in PROBES:
        v = r[p]
        if v is None: continue
        agg[key][p][1] += 1
        if v: agg[key][p][0] += 1

print(f"{'Model':<28}{'Lev':<6}" + "".join(f"{p:<16}" for p in PROBES) + "Composite")
for key in sorted(agg.keys()):
    m, L = key
    cells = []
    pcts = []
    for p in PROBES:
        passed, total = agg[key][p]
        if total == 0:
            cells.append("-")
        else:
            pct = 100.0 * passed / total
            cells.append(f"{passed}/{total} ({pct:.0f}%)")
            pcts.append(pct)
    comp = sum(pcts) / len(pcts) if pcts else 0
    print(f"{m:<28}{L:<6}" + "".join(f"{c:<16}" for c in cells) + f" {comp:.1f}%")
