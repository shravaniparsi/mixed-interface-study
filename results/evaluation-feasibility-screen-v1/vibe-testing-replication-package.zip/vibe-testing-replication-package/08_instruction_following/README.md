# Instruction-following compliance (IFC) probes

Static probes that check whether generated suites obey explicitly stated
constraints of the task prompt (ISBN format constraint adherence, helper
construction, forbidden patterns). `scripts/_ifc_composite_probes.py` defines
the probe set; `results/ifc_composite_by_model.json` holds the composite
score per model; `results/ifc_composite_results.json` the per-probe detail.
